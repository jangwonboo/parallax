---
name: pdf-ko-translate
description: Turn an English PDF into a Korean working file for the Parallax reader. Recovers document structure from the PDF (headings, paragraphs, running heads, paragraphs broken across page breaks), optionally cross-checks every page with a vision model, then translates into Korean with a selectable register (직역 / 소설 / 에세이 / 비즈니스), de-slops the Korean and verifies nothing was dropped. Emits `.parallax`; it does not render a reading copy — the Parallax desktop app does that. Trigger on "PDF 번역해줘", "이 책 한글로", "영문 PDF 추출", "translate this PDF to Korean", or any request to turn an English document into a Korean reading copy. Runs as a resumable batch pipeline, not inside the chat session.
license: MIT
---

# PDF → 한국어 작업 파일

영문 PDF 한 권을 Parallax 리더가 여는 `.parallax` 작업 파일로 바꾸는 7단계 파이프라인. 각 단계는 `book.json` 하나를 읽고 고쳐 쓴다. 모든 단계는 청크 단위 캐시를 쓰므로 중단 후 재개해도 이미 끝난 부분은 다시 호출하지 않는다.

```
extract → pagecheck → glossary → translate → deslop → verify → export
  ①          ②           ③          ④          ⑤        ⑥        ⑦
```

**읽는 화면은 여기 없다.** 예전에는 마지막 단계가 `book.md`와 자체 툴바·목차·사전 팝업을 가진 단일 파일 `book.html`을 냈다. 그 조판이 전부 Parallax 데스크톱 앱으로 옮겨갔고, 같은 조판을 두 벌 유지하면 반드시 어긋난다. 이 스킬은 문서를 뽑아 번역해 `.parallax`로 넘기는 데까지만 한다.

## 핵심 계약: 단락 단위 앵커

**pagecheck 이후 블록 ID는 불변이다.** 추출이 문서를 블록(제목·단락·인용·각주)으로 쪼개 `b0001`부터 ID를 매기고, pagecheck가 페이지 이미지와 대조해 구조를 고친다. 구조를 바꿀 수 있는 건 여기까지다. 이후 어떤 단계도 블록을 만들거나 없애거나 합치거나 순서를 바꾸지 않는다. 채워 넣기만 한다.

문장 분할은 자유다. 영어 장문 하나를 한국어 세 문장으로 쪼개도 되고, 짧은 두 문장을 붙여도 된다. 단 그 결과가 **같은 블록 안에** 머물러야 한다. 이 계약이 지켜지는 한 앱의 좌우 대역은 항상 같은 줄에 정렬된다.

이걸 어기면 나머지가 전부 무너진다. 프롬프트에서 반복해 강조하고, `verify`가 기계적으로 검사한다.

## 설치

```bash
unzip pdf-ko-translate.zip -d ~/.claude/skills/
pip install -r ~/.claude/skills/pdf-ko-translate/requirements.txt
```

`~/.claude/skills/` 에 두면 이후 어떤 세션에서든 자동으로 잡힌다. 프로젝트 단위로 쓰려면 저장소의 `.claude/skills/` 에 넣고 커밋한다.

## 실행

```bash
pip install -r requirements.txt
export ANTHROPIC_API_KEY=...

python scripts/extract.py   book.pdf --out work/book.json
python scripts/pagecheck.py work/book.json --pdf book.pdf     # 페이지별 판독 대조·구조 교정
python scripts/glossary.py  work/book.json                    # 인명·용어·인물관계 확정
python scripts/translate.py work/book.json --register essay   # 직역 literal / 소설 fiction / 에세이 essay / 비즈니스 business
python scripts/deslop.py    work/book.json
python scripts/verify.py    work/book.json                    # 누락·숫자·고유명사 검사
python scripts/export.py    work/book.json --out out/         # -> out/book.parallax
```

또는 `bash scripts/run.sh book.pdf essay` 로 한 번에.

각 단계는 독립적으로 다시 돌릴 수 있다. 문체가 마음에 안 들면 `translate.py --register fiction --force` 로 4단계부터 다시.

## 단계별 요점

### ① extract — PDF에서 구조 복원
PDF에는 장·절·단락 개념이 없다. 폰트 크기·굵기와 PDF outline(북마크)으로 heading을 추론하고, 하이픈 줄바꿈을 복원하고, 머리글·꼬리글·쪽번호를 걷어낸다. 자세한 규칙과 흔한 실패는 [`references/structure.md`](references/structure.md).

**머리글 판정은 규칙이지 비전이 아니다.** 페이지 높이의 위·아래 8% 안에 온전히 들어가는 줄만 후보로 본다. "첫 두 줄"로 잡으면 드롭캡이나 제사(題詞)가 밀어낸 머리글을 놓치고, 짧은 페이지에서는 본문 첫 줄을 머리글로 몬다. 후보 중 숫자를 `#`으로 지운 텍스트가 **서로 다른 3쪽 이상(또는 전체의 5% 이상)** 에서 반복되면 머리글이다. 책은 짝수쪽에만 머리글을 넣거나 장 시작·전면 도판에서는 빼므로, 전체의 20% 남짓에만 나타나는 게 정상이다 — 임계값을 25%로 잡았더니 191쪽 중 37쪽에 있던 머리글이 살아남아 `classify()`가 전부 heading으로 읽었고 목차가 책 제목 37개로 도배됐다. PDF outline에 있는 제목은 절대 지우지 않는다. 장 제목은 원래 첫 페이지 맨 위에 있다.

**페이지를 넘나드는 단락은 여기서 붙인다.** `merge_paragraphs()`는 한 페이지씩 보므로 페이지 경계를 넘는 단락은 항상 두 블록으로 갈린다. 예전에는 `pagecheck.py`가 이걸 붙였는데, pagecheck는 쪽당 비전 호출이라 대개 돌리지 않고 넘어간다. 규칙은 결정론적이라 모델이 필요 없다 — 자세한 근거는 `stitch_blocks()` 주석과 [`references/decisions.md`](references/decisions.md) C.

OCR로 만든 텍스트 레이어는 분철 하이픈을 `¬`(U+00AC)나 soft hyphen으로 쓴다. `am¬ bitious`가 그대로 남으면 번역기에 조각난 단어가 들어가므로 함께 복원한다.

**제목 레벨은 문서 전체에서 다시 고른다.** 폰트 크기 추론은 쪽마다 조판이 조금씩 달라 흔들리고, `pagecheck --trust vision`은 한 페이지씩 따로 읽으므로 같은 장 제목이 어느 쪽에 실렸느냐에 따라 다른 레벨을 받는다 — 실제로 한 책에서 `CHAPTER 1`이 h3, `CHAPTER 2`가 h2, `CHAPTER 3`이 h3으로 나왔고 목차에서 장이 그 장에 속한 절보다 아래에 놓였다. `normalize_headings()`가 두 단계로 눌러 준다:

- **h1** — `CHAPTER|PART|BOOK|SECTION` + 숫자·로마숫자로 시작하는 제목, 그리고 `CONTENTS`·`INTRODUCTION`·`EPILOGUE`·`INDEX` 같은 앞뒤 부속물 표제
- **h2** — 나머지 전부

단행본에는 두 단계면 충분하다. 더 잘게 나누려면 추측해야 하는데 틀린 추측은 평평한 목록보다 나쁘다. 원본 레벨이 필요하면 `--keep-heading-levels`.

추출은 좌표와 폰트만 보는 추론이라 반드시 틀린다. 그래서 다음 단계가 있다.

### ② pagecheck — 페이지마다 판독해 대조
페이지를 이미지로 렌더링해 **싼 비전 모델(Haiku)로 전 페이지를 읽고**, 텍스트 레이어에서 뽑은 것과 대조한다. 휴리스틱만으로는 못 잡는 것들이 여기서 걸린다.

- **본문 누락** — PDF 텍스트 레이어는 이미지 안의 글자, 드롭캡, 사이드바, 회전된 캡션을 통째로 빠뜨린다. 토큰 일치율이 기준(기본 90%) 아래면 표시한다.
- **단 읽기 순서** — 2단 조판에서 좌우가 교차돼 문장이 뒤섞이는 사고.
- **제목이 본문에 파묻힘** — 폰트 크기 추론이 실패한 경우.
- **이미지 페이지** — 텍스트 레이어가 아예 없는 쪽.

**역할 분담이 핵심이다. 글자는 텍스트 레이어가 정답, 구조는 비전이 정답.** 텍스트 레이어는 문자 단위로 정확하지만 구조를 모르고, 비전 모델은 구조를 알지만 문자 단위로 정확하지 않다 — 고어 철자를 조용히 현대식으로 고치고, 저자가 의도한 오기를 바로잡고, 한 줄을 건너뛰고도 매끄러운 문장을 만든다.

그래서 판독 텍스트가 블록 내용이 되는 경로는 딱 두 가지로 제한된다. **누락 삽입**(레이어가 아예 못 본 텍스트)과 **페이지 재구성**(뒤 참조)뿐이고, 둘 다 `from_ocr: true`가 붙는다. 페이지 전문 판독은 일치율 계산에만 쓰이고 어떤 블록에도 기록되지 않는다.

재구성은 유일하게 레이어 내용을 밀어내는 경로다. 밀려난 원문은 버리지 않고 `book.json`의 `superseded`에 페이지별로 보관한다 — 그게 그 페이지의 유일한 문자 정확 기록이기 때문이다.

```bash
python scripts/pagecheck.py work/book.json --pdf book.pdf                   # 기본: vision
python scripts/pagecheck.py work/book.json --pdf book.pdf --pages 1-40      # 비용 시험
python scripts/pagecheck.py work/book.json --pdf book.pdf --engine tesseract  # 로컬 OCR
python scripts/pagecheck.py work/book.json --pdf book.pdf --trust vision    # 레이어가 OCR 산출물일 때
```

**`--trust vision` — 권한을 뒤집는 모드.** 위의 역할 분담은 텍스트 레이어가 문자 단위로 정확하다는 전제 위에 서 있다. 레이어 자체가 OCR 산출물이면(스캔본, 또는 전자책 리더 화면 캡처를 OCR한 PDF) 그 전제가 무너진다. 그런 문서에서는 레이어도 부정확한데, 하류가 고칠 수 없는 방식으로 부정확하다 — `bom`(born), `beSeattle`(be Seattle), `1temporarily`(I temporarily), 분철 하이픈이 `¬`로. 이때는 비전 판독이 그냥 더 낫다.

`--trust vision`은 전 페이지를 이미지에서 다시 받아쓴다. 밀려난 레이어 텍스트는 버리지 않고 `superseded`에 보관하고, 새 블록에는 `from_ocr`가 붙는다. 191쪽 실측:

| | 레이어 | `--trust vision` |
|---|---|---|
| `¬`로 쪼개진 단어 | 612 | 0 |
| 공백 누락(`beSeattle`) 추정 | 21 / 20쪽 | 3 |
| `I`를 `1`로 읽음 | 9 / 20쪽 | 0 |
| 표지·속표지의 가짜 제목 | 14 | 4 (진짜 제목만) |

**레이어가 멀쩡한 책에는 쓰지 마라.** 비전 모델은 고어 철자를 현대식으로 고치고, 저자의 의도적 오기를 바로잡고, 한 줄을 건너뛰고도 매끄러운 문장을 만든다. 곧은 따옴표로 바뀌는 등 사소한 손실도 있다. 먼저 `--pages 1-20`으로 $0.15어치만 돌려 실제로 나아지는지 확인하고 결정하라.

**비용.** 페이지 이미지는 긴 변 1568px로 줄여 보내므로 입력 약 2,500 토큰, 출력 900 안팎 — Haiku 기준 페이지당 약 $0.0075다. 300쪽이면 $2.3, 배치로는 절반. 같은 책 번역이 deslop까지 $7 안팎이니 30% 수준이다. 병목은 돈이 아니라 지연이라 기본 8워커로 동시 호출한다(`--workers`).

`--engine tesseract`는 로컬 OCR을 전 페이지에 돌리고 표시된 페이지만 비전으로 교정한다. 무료·오프라인이지만 **탐지만 하고 교정은 못 한다** — OCR은 글자를 다 읽어도 그게 제목인지 캡션인지 모르고, 읽기 순서도 좌표 추정에 불과하다. `pip install pytesseract pillow` + 바이너리가 필요하다.

**교정 세 종류.**
1. 유형·순서·제외 — 블록 단위 수정
2. 누락 삽입 — 레이어가 못 본 텍스트를 새 블록으로. ID는 **접미사(`b0042a`)**라 전체 번호를 다시 매기지 않으므로 기존 번역 캐시가 유효하다
3. **페이지 재구성** — 2단이 블록 *내부에서* 뒤섞여 블록 단위 교정으로는 못 고치는 경우, 그 페이지만 판독 텍스트로 다시 만든다. 최후 수단이라 모델이 명시적으로 요청할 때만 발동한다

2·3으로 생긴 블록은 `from_ocr: true`가 붙는다. 판독 텍스트는 레이어보다 부정확하니 리포트에서 따로 확인하라.

스캔본은 `extract.py --allow-scanned` 로 껍데기를 만든 뒤 pagecheck로 채울 수 있다. 다만 `ocrmypdf`로 텍스트 레이어를 제대로 만들어 다시 넣는 쪽이 낫다.

**끝나면 `work/pagecheck-report.md`와 `work/blocks.txt`를 훑어라.** blocks.txt는 교정 결과가 반영돼 다시 쓰인다. 구조를 고칠 수 있는 마지막 지점이다.

### ③ glossary — 일관성 자산 만들기
본 번역 전에 전체를 훑어 인명·지명·반복 개념어를 뽑고 역어를 **미리 확정**한다. 이걸 건너뛰면 3장의 "the Commission"이 5장에서 다른 말로 바뀐다.

소설이면 여기서 **인물 관계표**도 만든다. 영어에 없는 존대·반말·호칭을 한국어는 매번 정해야 하는데, 고정해두지 않으면 인물 말투가 챕터마다 흔들린다. 자세히는 [`references/consistency.md`](references/consistency.md).

생성된 `work/glossary.json`은 **사람이 고치라고 만든 파일이다.** 번역 시작 전에 반드시 열어보고 어색한 역어를 손봐라. 여기 5분이 뒤의 한 시간을 아낀다.

### ④ translate — 문체 축에 따라 번역
"소설체로 번역해줘" 같은 형용사 지시는 결과가 흔들린다. 네 가지 register를 종결어미·문장분할·어휘·대명사·고유명사·존대 여섯 축의 조합으로 명세해 뒀다. 전문은 [`references/registers.md`](references/registers.md).

| register | 종결 | 문장 분할 | 어휘 | 대명사 | 쓰임 |
|---|---|---|---|---|---|
| `literal` 직역 | -다 | 원문 유지 | 원어 근접 | 명시 | 대조 확인, 학술 |
| `fiction` 소설 | -다 (평서) | 적극 분할 | 고유어 우선 | 대폭 생략 | 소설, 서사 논픽션 |
| `essay` 에세이 | -다 | 중간 | 균형 | 생략 | 에세이, 교양서 |
| `business` 비즈니스 | -습니다/-다 | 적극 분할 | 한자어 | 생략 | 보고서, 실용서 |

### ⑤ deslop — 번역투 제거
번역과 동시에 하지 않는다. 번역은 정확성, deslop은 문체라 섞으면 둘 다 나빠진다. 별도 패스로 돌린다.

기존 `deslop` 스킬의 Korean sub-track(번역투 A~J 분류, S1~S3 심각도)을 그대로 쓴다. 여기 있는 [`references/deslop-translation.md`](references/deslop-translation.md)는 **번역 문맥에만 해당하는 추가 규칙과 예외**만 담는다. 특히 소설에서 작가 고유 문체(의도적 반복, 파편문, 거친 리듬)를 슬롭으로 오인해 지우는 사고를 막는 예외 규칙이 중요하다.

### ⑥ verify — 조용한 누락 잡기
LLM이 문단을 통째로 빠뜨리는 일은 흔하고, 읽어서는 못 잡는다. `verify.py`가 기계적으로 본다:

- 블록 ID 집합 일치, 빈 번역
- 숫자·연도·통화·퍼센트 대조
- glossary 역어 준수 여부
- 길이 비율 이상치 (한국어/영어 문자 비율이 정상 범위 밖인 블록)

리포트는 `work/verify-report.md`. **경고가 남은 채로 내보내지 마라.**

### ⑦ export — `.parallax` 로 넘기기
`out/book.parallax`를 낸다. 이게 이 파이프라인의 끝이다.

`.parallax`는 렌더링이 아니라 **작업 파일**이다. 블록 ID, 양쪽 언어, deslop 이전 텍스트, 용어집, pagecheck 이력이 전부 살아 있어서 이 파이프라인이 밤새 번역한 책을 앱에서 이어 읽을 수 있고, 앱에서 시작한 책을 `parallax_import.py`로 되받아 CLI에서 끝낼 수 있다. SQLite이며 스키마는 `_parallax.py`에 있다.

읽는 화면 — 좌우 대역 조판, 목차, 서체·폭·줄간격 조절, 사전 팝업, 가상 스크롤 — 은 전부 **Parallax 데스크톱 앱**에 있다. 여기서 HTML을 또 만들지 않는다.

```bash
python scripts/export.py work/book.json --out out/
open out/book.parallax
```

## 주의

- **비용과 시간.** 300쪽이면 10만 단어 안팎이다. 대략 pagecheck $2 + translate·deslop $7. 먼저 `pagecheck --pages 1-40`, `translate --limit 30` 으로 앞부분만 돌려 확인하고 전체를 태워라.
- **저작권.** 개인 학습·소장용 번역본을 만드는 도구다. 산출 `.parallax`에는 원문 전체가 그대로 들어간다. 배포·공유·게시는 하지 마라.
- **스캔본.** 텍스트 레이어가 없으면 `extract.py`가 멈춘다. `ocrmypdf --skip-text` 로 레이어를 만들어 다시 넣는 게 정석이고, 급하면 `extract.py --allow-scanned` + `pagecheck.py --trust vision`.
- **TLS 검사 장비.** 사내망이 TLS를 중간에서 끊고 자체 루트로 다시 서명하면, 그 루트가 OpenSSL 기준으로 형식이 어긋난 경우 브라우저는 되는데 파이썬만 전 호출이 `CERTIFICATE_VERIFY_FAILED`로 죽는다. `requirements.txt`의 `truststore`가 검증을 OS에 맡겨 해결한다 — 검증을 끄는 게 아니라 이 PC의 나머지 프로그램과 같은 판단을 하는 것이다.
- **앞뒤 부속물.** 색인·참고문헌은 기본적으로 원문 유지(`--keep-original index,bibliography`). 번역해 봐야 쓸모가 없고 토큰만 먹는다.

## 파일

```
references/
  decisions.md            설계 결정과 실제로 밟은 지뢰 — 손보기 전에 먼저 읽을 것
  structure.md            PDF 구조 복원 규칙, 흔한 실패
  registers.md            문체 4종의 축 명세 + 프롬프트 조각
  consistency.md          용어집·인물관계표 포맷과 운영
  deslop-translation.md   번역 문맥 전용 deslop 규칙과 보존 예외
scripts/
  _llm.py                 API 호출(텍스트·비전), 청킹, 캐시, 재개
  extract.py    PDF → 블록
  pagecheck.py  페이지별 비전 판독 대조 + 구조 교정 (또는 tesseract 엔진)
  glossary.py  translate.py  deslop.py  verify.py
  export.py          book.json → `.parallax`
  _parallax.py       `.parallax` 스키마
  parallax_import.py `.parallax` → book.json (역방향)
  run.sh
```

`templates/`(이북 HTML 셸·테마 CSS)와 `render.py`는 제거했다. 읽는 화면은 Parallax 앱이다.
