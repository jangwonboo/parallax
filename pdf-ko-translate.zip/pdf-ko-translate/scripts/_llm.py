"""Shared helpers: block I/O, chunking, ID-preserving LLM calls, cache/resume."""
from __future__ import annotations

import hashlib
import json
import os
import re
import sys
import time
from pathlib import Path

# Corporate networks routinely terminate TLS at an inspection appliance whose root is
# installed in the OS trust store. Some of those roots are malformed by OpenSSL's
# rules — a CA certificate whose basicConstraints extension is not marked critical,
# for instance — and OpenSSL 3 then refuses a connection that the browser, and every
# other application on the machine, makes without complaint. The symptom is
# `CERTIFICATE_VERIFY_FAILED` on every API call while `curl` works.
#
# `truststore` hands verification to the operating system, so we make the same trust
# decision the rest of the machine already makes. It does not disable verification.
# If it is not installed we simply carry on with OpenSSL's own store.
try:
    import truststore
    truststore.inject_into_ssl()
except Exception:
    pass

# A Windows console is cp949/cp1252, not UTF-8, and `print` raises on the first
# character the codepage cannot hold. Progress text must never be able to fail a job
# that has already done its work — an em dash in one line used to do exactly that.
for _s in (sys.stdout, sys.stderr):
    try:
        _s.reconfigure(errors="replace")
    except Exception:
        pass

MODEL = os.environ.get("PKT_MODEL", "claude-sonnet-4-6")
MAX_RETRY = 3

# pagecheck 가 삽입·재구성한 블록은 접미사 ID 를 갖는다(b0052a). 한 페이지에 여러
# 개가 들어가면 직전 ID 에 다시 글자를 붙여 b0052aa, b0052aaa 로 자란다. 접미사를
# 허용하지 않으면 그 블록들의 번역이 응답에서 조용히 버려진다 — 재실행해도 계속
# 비어 있고, verify 가 잡아 줄 때까지 원인이 보이지 않는다.
LINE_RE = re.compile(r"^\[(b\d{4,}[a-p]*)\]\s?(.*)$")


# ---------- book.json ----------

def load_book(path: str | Path) -> dict:
    return json.loads(Path(path).read_text(encoding="utf-8"))


def save_book(path: str | Path, book: dict) -> None:
    p = Path(path)
    tmp = p.with_suffix(p.suffix + ".tmp")
    tmp.write_text(json.dumps(book, ensure_ascii=False, indent=1), encoding="utf-8")
    tmp.replace(p)


def work_dir(book_path: str | Path) -> Path:
    d = Path(book_path).parent
    d.mkdir(parents=True, exist_ok=True)
    return d


def translatable(book: dict) -> list[dict]:
    """Blocks that should be sent to the model."""
    return [b for b in book["blocks"]
            if b.get("translate", True) and b.get("src", "").strip()]


# ---------- chunking ----------

def chunk_blocks(blocks: list[dict], max_chars: int = 6000) -> list[list[dict]]:
    """Group consecutive blocks. Never split a block. Prefer breaking before a heading."""
    chunks, cur, size = [], [], 0
    for b in blocks:
        blen = len(b.get("src", "")) + len(b.get("ko") or "")
        is_head = b["type"].startswith("h")
        if cur and (size + blen > max_chars or (is_head and size > max_chars * 0.5)):
            chunks.append(cur)
            cur, size = [], 0
        cur.append(b)
        size += blen
    if cur:
        chunks.append(cur)
    return chunks


# ---------- cache ----------

class Cache:
    def __init__(self, root: Path, stage: str):
        self.dir = Path(root) / ".cache" / stage
        self.dir.mkdir(parents=True, exist_ok=True)

    def key(self, payload: str, *salts: str) -> str:
        h = hashlib.sha1()
        h.update(payload.encode("utf-8"))
        for s in salts:
            h.update(b"\x00")
            h.update(str(s).encode("utf-8"))
        return h.hexdigest()[:20]

    def get(self, key: str) -> dict | None:
        f = self.dir / f"{key}.json"
        if f.exists():
            try:
                return json.loads(f.read_text(encoding="utf-8"))
            except Exception:
                return None
        return None

    def put(self, key: str, value: dict) -> None:
        (self.dir / f"{key}.json").write_text(
            json.dumps(value, ensure_ascii=False), encoding="utf-8")


# ---------- wire format ----------

def to_wire(blocks: list[dict], field: str = "src") -> str:
    """One block per line: [b0012] text"""
    out = []
    for b in blocks:
        text = (b.get(field) or "").replace("\n", " ").strip()
        out.append(f"[{b['id']}] {text}")
    return "\n".join(out)


def from_wire(text: str) -> dict[str, str]:
    result: dict[str, str] = {}
    for line in text.splitlines():
        m = LINE_RE.match(line.strip())
        if m:
            result[m.group(1)] = m.group(2).strip()
    return result


# ---------- .env ----------

# 키를 셸마다 export 하는 것은 배치 파이프라인과 잘 맞지 않는다. 한 단계가 밤새
# 돌다 끊겨 다른 창에서 재개하면 그 창에는 키가 없다. `.env` 를 읽어 두면 어느
# 창에서 재개하든 같은 키를 쓴다.
#
# 형식은 느슨하게 받는다. 사람이 손으로 고치는 파일이라 ` KEY  = value` 처럼
# 등호 둘레에 공백이 붙고, 줄바꿈 없이 끝나고, 편집기가 BOM 을 남긴다. 그중
# 하나라도 파서를 깨면 "키가 없습니다" 만 보이고 원인은 보이지 않는다.
_ENV_LOADED = False
# pagecheck 는 기본 8워커로 페이지를 동시에 읽는다. 플래그를 세우고 나서 파일을
# 읽으면, 그 사이에 들어온 워커가 "이미 읽었다"고 보고 키 없이 나간다 — 열두 쪽
# 중 몇 쪽만 무작위로 죽는다. 락으로 첫 워커가 다 읽을 때까지 나머지를 세운다.
_ENV_LOCK = __import__("threading").Lock()


def _env_candidates() -> list[Path]:
    """`.env` 를 찾을 자리 — 먼저 나오는 것이 이긴다."""
    out: list[Path] = []
    explicit = os.environ.get("PKT_ENV_FILE")
    if explicit:
        out.append(Path(explicit).expanduser())
    cwd = Path.cwd()
    out.extend(p / ".env" for p in (cwd, *cwd.parents))
    out.append(Path(__file__).resolve().parent.parent / ".env")  # 스킬 루트
    out.append(Path.home() / ".env")
    return out


def load_env_file(path: Path) -> int:
    """`.env` 한 벌을 환경으로 올린다. 이미 있는 변수는 건드리지 않는다.

    실제 환경변수가 언제나 이긴다 — 파일은 기본값이지 권위가 아니다. 값은 절대
    찍지 않는다. 로그와 오류 메시지에 키가 새어 나가는 가장 흔한 경로다."""
    n = 0
    try:
        text = path.read_text(encoding="utf-8-sig")
    except (OSError, UnicodeDecodeError):
        return 0
    for line in text.splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        if line.startswith("export "):
            line = line[len("export "):]
        key, _, value = line.partition("=")
        key, value = key.strip(), value.strip()
        if not key.replace("_", "").isalnum():
            continue
        if len(value) >= 2 and value[0] == value[-1] and value[0] in "\"'":
            value = value[1:-1]
        if key not in os.environ:          # 실제 환경변수가 이긴다
            os.environ[key] = value
            n += 1
    return n


def ensure_env() -> Path | None:
    """첫 API 호출 전에 `.env` 를 한 번만 읽는다."""
    global _ENV_LOADED
    with _ENV_LOCK:
        if _ENV_LOADED:
            return None
        found = None
        for cand in _env_candidates():
            if cand.is_file() and load_env_file(cand):
                found = cand
                break
        _ENV_LOADED = True      # 다 읽은 뒤에 세운다
        return found


# ---------- API ----------

def _client():
    try:
        import anthropic
    except ImportError:
        sys.exit("pip install anthropic")
    ensure_env()
    # 키가 없는 것은 재시도할 일이 아니다. 이걸 걸러내지 않으면 SDK 가 던지는
    # TypeError 를 일반 오류로 보고 여섯 번 물러났다가(70초) 역추적을 토해낸다 —
    # 정작 무엇이 없는지는 어디에도 적혀 있지 않다.
    if not (os.environ.get("ANTHROPIC_API_KEY") or os.environ.get("ANTHROPIC_AUTH_TOKEN")):
        looked = "\n".join(f"  {p}" for p in _env_candidates()[:6])
        sys.exit("ANTHROPIC_API_KEY 가 없습니다. 환경변수로 넣거나, `.env` 에 "
                 "ANTHROPIC_API_KEY=... 를 적거나, 앱에서 파일 → Anthropic API 키… 로 "
                 f"등록하세요.\n찾아본 곳:\n{looked}\n"
                 "다른 곳에 뒀다면 PKT_ENV_FILE 로 알려주세요.")
    return anthropic.Anthropic()


def call(system: str, user: str, max_tokens: int = 8000) -> str:
    client = _client()
    last = None
    for attempt in range(MAX_RETRY):
        try:
            resp = client.messages.create(
                model=MODEL,
                max_tokens=max_tokens,
                system=system,
                messages=[{"role": "user", "content": user}],
            )
            return "".join(c.text for c in resp.content if c.type == "text")
        except Exception as e:  # rate limit, overload, transient
            last = e
            wait = 2 ** attempt * 5
            print(f"  ! {type(e).__name__}: retrying in {wait}s", file=sys.stderr)
            time.sleep(wait)
    raise RuntimeError(f"API failed after {MAX_RETRY} attempts: {last}")


def call_preserving_ids(system: str, user: str, expected: list[str],
                        max_tokens: int = 8000) -> dict[str, str]:
    """Call, parse [id] lines, and re-request any IDs the model dropped."""
    raw = call(system, user, max_tokens)
    got = from_wire(raw)
    missing = [i for i in expected if i not in got or not got[i]]

    if missing:
        print(f"  ! {len(missing)} block(s) missing, re-requesting", file=sys.stderr)
        wanted = "\n".join(l for l in user.splitlines()
                           if any(l.startswith(f"[{m}]") for m in missing))
        if wanted.strip():
            retry = call(system, wanted, max_tokens)
            got.update({k: v for k, v in from_wire(retry).items() if v})

    still = [i for i in expected if i not in got or not got[i]]
    if still:
        print(f"  !! unrecoverable: {still}", file=sys.stderr)
    # never invent blocks
    return {k: v for k, v in got.items() if k in set(expected)}


def progress(i: int, total: int, label: str = "") -> None:
    pct = int(100 * (i + 1) / total)
    print(f"[{i+1}/{total}] {pct}% {label}", flush=True)


# ---------- vision ----------

VISION_MODEL = os.environ.get("PKT_VISION_MODEL", "claude-haiku-4-5")


class VisionUnavailable(Exception):
    """이 쪽은 비전으로 읽을 수 없다 — 다시 물어봐도 같은 답이 온다.

    저작물 한 쪽을 통째로 받아쓰게 하면 API 가 출력을 막는다(400,
    'Output blocked by content filtering policy'). 판정은 쪽 내용에 따라 결정적이라
    재시도가 의미 없고, 한 쪽 때문에 책 전체를 세울 이유도 없다. 부르는 쪽에서
    잡아 그 쪽만 건너뛰고, 글자는 텍스트 레이어 것을 그대로 둔다."""


def call_vision(system: str, user: str, image_path, max_tokens: int = 3000,
                media_type: str = "image/png", model: str | None = None) -> str:
    """Send one page image plus a text instruction. Used by pagecheck.py.

    Defaults to the cheap model — page reading is a volume job, not a reasoning job."""
    import base64

    data = base64.standard_b64encode(Path(image_path).read_bytes()).decode("ascii")
    client = _client()
    last = None
    for attempt in range(MAX_RETRY):
        try:
            resp = client.messages.create(
                model=model or VISION_MODEL,
                max_tokens=max_tokens,
                system=system,
                messages=[{"role": "user", "content": [
                    {"type": "image",
                     "source": {"type": "base64", "media_type": media_type, "data": data}},
                    {"type": "text", "text": user},
                ]}],
            )
            return "".join(c.text for c in resp.content if c.type == "text")
        except Exception as e:
            # 400 은 요청 자체가 잘못됐다는 뜻이다. 그대로 세 번 더 보내도 같은 400 이
            # 돌아오고, 8워커면 쪽마다 35초씩 헛되이 기다린다.
            if getattr(e, "status_code", None) == 400:
                raise VisionUnavailable(str(e)[:200]) from e
            last = e
            wait = 2 ** attempt * 5
            print(f"  ! {type(e).__name__}: retrying in {wait}s", file=sys.stderr)
            time.sleep(wait)
    raise RuntimeError(f"vision API failed after {MAX_RETRY} attempts: {last}")


def strip_fence(text: str) -> str:
    return re.sub(r"^```(?:json)?\s*|\s*```$", "", text.strip())
