"""Shared helpers: block I/O, chunking, ID-preserving LLM calls, cache/resume."""
from __future__ import annotations

import hashlib
import json
import os
import re
import sys
import time
from pathlib import Path

# Corporate networks routinely terminate TLS at an inspection appliance whose root is
# installed in the OS trust store. Some of those roots are malformed by OpenSSL's
# rules — a CA certificate whose basicConstraints extension is not marked critical,
# for instance — and OpenSSL 3 then refuses a connection that the browser, and every
# other application on the machine, makes without complaint. The symptom is
# `CERTIFICATE_VERIFY_FAILED` on every API call while `curl` works.
#
# `truststore` hands verification to the operating system, so we make the same trust
# decision the rest of the machine already makes. It does not disable verification.
# If it is not installed we simply carry on with OpenSSL's own store.
try:
    import truststore
    truststore.inject_into_ssl()
except Exception:
    pass

# A Windows console is cp949/cp1252, not UTF-8, and `print` raises on the first
# character the codepage cannot hold. Progress text must never be able to fail a job
# that has already done its work — an em dash in one line used to do exactly that.
for _s in (sys.stdout, sys.stderr):
    try:
        _s.reconfigure(errors="replace")
    except Exception:
        pass

MODEL = os.environ.get("PKT_MODEL", "claude-sonnet-4-6")
MAX_RETRY = 3

# pagecheck 가 삽입·재구성한 블록은 접미사 ID 를 갖는다(b0052a). 한 페이지에 여러
# 개가 들어가면 직전 ID 에 다시 글자를 붙여 b0052aa, b0052aaa 로 자란다. 접미사를
# 허용하지 않으면 그 블록들의 번역이 응답에서 조용히 버려진다 — 재실행해도 계속
# 비어 있고, verify 가 잡아 줄 때까지 원인이 보이지 않는다.
LINE_RE = re.compile(r"^\[(b\d{4,}[a-p]*)\]\s?(.*)$")


# ---------- book.json ----------

def load_book(path: str | Path) -> dict:
    return json.loads(Path(path).read_text(encoding="utf-8"))


def save_book(path: str | Path, book: dict) -> None:
    p = Path(path)
    tmp = p.with_suffix(p.suffix + ".tmp")
    tmp.write_text(json.dumps(book, ensure_ascii=False, indent=1), encoding="utf-8")
    tmp.replace(p)


def work_dir(book_path: str | Path) -> Path:
    d = Path(book_path).parent
    d.mkdir(parents=True, exist_ok=True)
    return d


def translatable(book: dict) -> list[dict]:
    """Blocks that should be sent to the model."""
    return [b for b in book["blocks"]
            if b.get("translate", True) and b.get("src", "").strip()]


# ---------- chunking ----------

def chunk_blocks(blocks: list[dict], max_chars: int = 6000) -> list[list[dict]]:
    """Group consecutive blocks. Never split a block. Prefer breaking before a heading."""
    chunks, cur, size = [], [], 0
    for b in blocks:
        blen = len(b.get("src", "")) + len(b.get("ko") or "")
        is_head = b["type"].startswith("h")
        if cur and (size + blen > max_chars or (is_head and size > max_chars * 0.5)):
            chunks.append(cur)
            cur, size = [], 0
        cur.append(b)
        size += blen
    if cur:
        chunks.append(cur)
    return chunks


# ---------- cache ----------

class Cache:
    def __init__(self, root: Path, stage: str):
        self.dir = Path(root) / ".cache" / stage
        self.dir.mkdir(parents=True, exist_ok=True)

    def key(self, payload: str, *salts: str) -> str:
        h = hashlib.sha1()
        h.update(payload.encode("utf-8"))
        for s in salts:
            h.update(b"\x00")
            h.update(str(s).encode("utf-8"))
        return h.hexdigest()[:20]

    def get(self, key: str) -> dict | None:
        f = self.dir / f"{key}.json"
        if f.exists():
            try:
                return json.loads(f.read_text(encoding="utf-8"))
            except Exception:
                return None
        return None

    def put(self, key: str, value: dict) -> None:
        (self.dir / f"{key}.json").write_text(
            json.dumps(value, ensure_ascii=False), encoding="utf-8")


# ---------- wire format ----------

def to_wire(blocks: list[dict], field: str = "src") -> str:
    """One block per line: [b0012] text"""
    out = []
    for b in blocks:
        text = (b.get(field) or "").replace("\n", " ").strip()
        out.append(f"[{b['id']}] {text}")
    return "\n".join(out)


def from_wire(text: str) -> dict[str, str]:
    result: dict[str, str] = {}
    for line in text.splitlines():
        m = LINE_RE.match(line.strip())
        if m:
            result[m.group(1)] = m.group(2).strip()
    return result


# ---------- API ----------

def _client():
    try:
        import anthropic
    except ImportError:
        sys.exit("pip install anthropic")
    # 키가 없는 것은 재시도할 일이 아니다. 이걸 걸러내지 않으면 SDK 가 던지는
    # TypeError 를 일반 오류로 보고 여섯 번 물러났다가(70초) 역추적을 토해낸다 —
    # 정작 무엇이 없는지는 어디에도 적혀 있지 않다.
    if not (os.environ.get("ANTHROPIC_API_KEY") or os.environ.get("ANTHROPIC_AUTH_TOKEN")):
        sys.exit("ANTHROPIC_API_KEY 가 없습니다. 환경변수로 넣거나 앱에서 "
                 "파일 → Anthropic API 키… 로 등록하세요.")
    return anthropic.Anthropic()


def call(system: str, user: str, max_tokens: int = 8000) -> str:
    client = _client()
    last = None
    for attempt in range(MAX_RETRY):
        try:
            resp = client.messages.create(
                model=MODEL,
                max_tokens=max_tokens,
                system=system,
                messages=[{"role": "user", "content": user}],
            )
            return "".join(c.text for c in resp.content if c.type == "text")
        except Exception as e:  # rate limit, overload, transient
            last = e
            wait = 2 ** attempt * 5
            print(f"  ! {type(e).__name__}: retrying in {wait}s", file=sys.stderr)
            time.sleep(wait)
    raise RuntimeError(f"API failed after {MAX_RETRY} attempts: {last}")


def call_preserving_ids(system: str, user: str, expected: list[str],
                        max_tokens: int = 8000) -> dict[str, str]:
    """Call, parse [id] lines, and re-request any IDs the model dropped."""
    raw = call(system, user, max_tokens)
    got = from_wire(raw)
    missing = [i for i in expected if i not in got or not got[i]]

    if missing:
        print(f"  ! {len(missing)} block(s) missing, re-requesting", file=sys.stderr)
        wanted = "\n".join(l for l in user.splitlines()
                           if any(l.startswith(f"[{m}]") for m in missing))
        if wanted.strip():
            retry = call(system, wanted, max_tokens)
            got.update({k: v for k, v in from_wire(retry).items() if v})

    still = [i for i in expected if i not in got or not got[i]]
    if still:
        print(f"  !! unrecoverable: {still}", file=sys.stderr)
    # never invent blocks
    return {k: v for k, v in got.items() if k in set(expected)}


def progress(i: int, total: int, label: str = "") -> None:
    pct = int(100 * (i + 1) / total)
    print(f"[{i+1}/{total}] {pct}% {label}", flush=True)


# ---------- vision ----------

VISION_MODEL = os.environ.get("PKT_VISION_MODEL", "claude-haiku-4-5")


def call_vision(system: str, user: str, image_path, max_tokens: int = 3000,
                media_type: str = "image/png", model: str | None = None) -> str:
    """Send one page image plus a text instruction. Used by pagecheck.py.

    Defaults to the cheap model — page reading is a volume job, not a reasoning job."""
    import base64

    data = base64.standard_b64encode(Path(image_path).read_bytes()).decode("ascii")
    client = _client()
    last = None
    for attempt in range(MAX_RETRY):
        try:
            resp = client.messages.create(
                model=model or VISION_MODEL,
                max_tokens=max_tokens,
                system=system,
                messages=[{"role": "user", "content": [
                    {"type": "image",
                     "source": {"type": "base64", "media_type": media_type, "data": data}},
                    {"type": "text", "text": user},
                ]}],
            )
            return "".join(c.text for c in resp.content if c.type == "text")
        except Exception as e:
            last = e
            wait = 2 ** attempt * 5
            print(f"  ! {type(e).__name__}: retrying in {wait}s", file=sys.stderr)
            time.sleep(wait)
    raise RuntimeError(f"vision API failed after {MAX_RETRY} attempts: {last}")


def strip_fence(text: str) -> str:
    return re.sub(r"^```(?:json)?\s*|\s*```$", "", text.strip())
