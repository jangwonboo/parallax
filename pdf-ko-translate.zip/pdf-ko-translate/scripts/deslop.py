#!/usr/bin/env python3
"""Second pass: strip 번역투 / AI slop from the Korean while preserving meaning.

Reads the deslop skill's Korean taxonomy if installed, plus this skill's
translation-specific exceptions. Keeps the original Korean in `ko_raw`.

    python scripts/deslop.py work/book.json
"""
from __future__ import annotations

import argparse
import difflib
import json
from pathlib import Path

import _llm as L

STRENGTH = {"literal": "약", "fiction": "중", "essay": "중", "business": "중강"}

LEVEL_RULE = {
    "약": "S1(결정적 번역투)만 손댄다. 나머지는 그대로 둔다.",
    "중": "S1 전부와, 3회 이상 반복되는 S2를 손댄다.",
    "중강": "S1과 S2를 전부 손댄다.",
}

SYS = """당신은 한국어 번역문에서 번역투와 AI 문체를 걷어내는 교정자다. 번역자가 아니다.

[입력]
각 줄은 `[ID] 한국어` 형식이다. 원문(영어)은 참고용으로 따로 준다. 의미가 바뀌었는지 스스로
검사하는 데만 쓰고, 다시 번역하지 마라.

[출력]
입력과 같은 ID, 같은 수, 같은 순서로 `[ID] 고친 한국어` 만 출력한다. 다른 말은 쓰지 마라.
고칠 게 없으면 원래 문장을 그대로 출력한다.

[불변]
1. 사실·숫자·연도·단위·고유명사·인용 내용은 100% 보존한다.
2. 근거가 있는 곳만 고친다. 번역투가 아니면 건드리지 마라. "더 좋은 표현"으로 바꾸는 것이
   가장 흔한 사고다.
3. 문단을 합치거나 나누지 마라. 블록 하나는 한 줄이다.
4. 원문에 없는 접속사·부연을 넣지 마라.
5. 존대 체계를 바꾸지 마라.
6. 한 블록에서 35% 이상 고쳐야 할 것 같으면 고치지 말고 원문 그대로 출력하라. 그건 재번역이지
   교정이 아니다.

[자주 나오는 번역투]
- it/this that 주어 → 주어 생략 또는 실주어 복원
- 수동태 "~되어진다", "~에 의해 ~된다" → 능동
- 소유격 of 3중 연쇄 "~의 ~의 ~" → 서술어로 풀기
- 복수 "~들" 남발 → 한국어는 복수 표지가 대개 불필요
- 긴 관계절 수식 → 문장 분리
- 분사구문 "~하면서, ~하면서" 연쇄 → 끊고 접속
- "~이 존재한다" → "~이 있다"
- "가장 ~한 것들 중 하나" → "손꼽히는"
- 형식주어 "~하는 것은 중요하다" → "~해야 한다"
- 조동사 중첩 "~할 수 있을 것이다" → 시제 하나로
- 문장 첫머리의 "그는/그녀는/그것은" → 지우고 읽어 모호하지 않으면 지운다

[보존 예외 — 지우면 안 되는 것]
원문에 근거가 있으면 그대로 둔다. 저자의 문체를 지우는 건 이 작업이 아니다.
- 의도적 반복 (저자가 같은 말을 반복했으면 한국어도 반복한다)
- 파편문·비문 (원문이 조각이면 번역도 조각이다)
- 의도적 장문 (의식의 흐름, 열거의 압박 — 끊지 마라)
- 시적·실험적 리듬, 고풍스러운 말투
- 인용문 (원저자의 문체다)
- 대사 (인물의 말투다)
판단이 서지 않으면 그대로 두어라."""


def changed_ratio(a: str, b: str) -> float:
    if not a:
        return 0.0
    return 1 - difflib.SequenceMatcher(None, a, b).ratio()


def load_taxonomy() -> str:
    for p in (Path("/mnt/skills/user/deslop/references/korean-taxonomy.md"),
              Path.home() / ".claude/skills/deslop/references/korean-taxonomy.md"):
        if p.exists():
            return "\n\n[deslop 스킬 한국어 분류표]\n" + p.read_text(encoding="utf-8")[:12000]
    return ""


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("book")
    ap.add_argument("--strength", choices=list(LEVEL_RULE),
                    help="default is derived from the register")
    ap.add_argument("--chunk-chars", type=int, default=5000)
    ap.add_argument("--max-change", type=float, default=0.35)
    ap.add_argument("--force", action="store_true")
    args = ap.parse_args()

    book = L.load_book(args.book)
    work = L.work_dir(args.book)
    register = book["meta"].get("register") or "essay"
    strength = args.strength or STRENGTH.get(register, "중")

    system = SYS + f"\n\n[강도 — {strength}]\n{LEVEL_RULE[strength]}" + load_taxonomy()
    (work / "deslop-system.txt").write_text(system, encoding="utf-8")

    blocks = [b for b in L.translatable(book) if b.get("ko")]
    # dialogue-heavy fiction quotes are the riskiest to touch; still send them, the
    # preservation rules cover it, but never touch untranslated or raw-table blocks
    blocks = [b for b in blocks if b["type"] != "table_raw"]

    cache = L.Cache(work, "deslop")
    chunks = L.chunk_blocks(blocks, args.chunk_chars)
    print(f"{len(blocks)} blocks · {len(chunks)} chunks · strength={strength} ({register})")

    by_id = {b["id"]: b for b in book["blocks"]}
    edited, skipped, review = 0, 0, []

    for i, chunk in enumerate(chunks):
        base = [b.get("ko_raw") or b["ko"] for b in chunk]
        for b, raw in zip(chunk, base):
            b.setdefault("ko_raw", raw)

        wire = "\n".join(f"[{b['id']}] {raw}" for b, raw in zip(chunk, base))
        src = "\n".join(f"[{b['id']}] {b['src']}" for b in chunk)
        key = cache.key(wire, strength, L.MODEL, "v1")
        hit = None if args.force else cache.get(key)

        if hit is None:
            got = L.call_preserving_ids(
                system,
                f"[영어 원문 — 의미 검사용, 번역 대상 아님]\n{src}\n\n[교정 대상 한국어]\n{wire}",
                [b["id"] for b in chunk],
                max_tokens=min(16000, len(wire) * 2 + 2000))
            cache.put(key, got)
        else:
            got = hit

        for b, raw in zip(chunk, base):
            new = got.get(b["id"])
            if not new:
                continue
            ratio = changed_ratio(raw, new)
            if ratio > args.max_change:
                b["needs_review"] = True
                review.append((b["id"], round(ratio, 2)))
                skipped += 1
                continue
            if new != raw:
                by_id[b["id"]]["ko"] = new
                edited += 1

        L.progress(i, len(chunks), "cached" if hit else "deslopped")
        L.save_book(args.book, book)

    L.save_book(args.book, book)

    print(f"\nedited {edited} · left alone (over {int(args.max_change*100)}% change) {skipped}")
    if review:
        rp = work / "deslop-review.md"
        rp.write_text(
            "# 변경률 초과로 손대지 않은 블록\n\n"
            "재번역 수준의 수정이 필요하다는 신호다. "
            "전체의 15%를 넘으면 register를 바꿔 translate 단계부터 다시 돌려라.\n\n"
            + "\n".join(f"- `{i}` — {r:.0%}" for i, r in review),
            encoding="utf-8")
        pct = len(review) / max(len(blocks), 1)
        print(f"  review list -> {rp}  ({pct:.0%} of blocks)")
        if pct > 0.15:
            print("  !! over 15% — the register is probably wrong. Re-run translate.py.")


if __name__ == "__main__":
    main()
