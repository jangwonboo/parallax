#!/usr/bin/env python3
"""book.json -> out/book.parallax, the working file the Parallax app opens.

This skill does not render a reading copy. It used to emit `book.md` and a
self-contained `book.html` with its own toolbar, table of contents and dictionary
popup; all of that now lives in the Parallax desktop app, which reads `.parallax`
directly. Keeping a second renderer here meant two copies of the same typesetting
drifting apart — the app is the one that gets used, so it is the one that stays.

`.parallax` is not a rendering. It is the editable working form: every block ID,
both languages, the pre-deslop text, the glossary and the page-check history
survive, so a book translated overnight by this pipeline can be opened in the app,
and a book started in the app can be finished here (`parallax_import.py`).

    python scripts/export.py work/book.json --out out/
"""
from __future__ import annotations

import argparse
import hashlib
import json
import time
import uuid
from pathlib import Path

import _llm as L
import _parallax as PX


def write_parallax(book: dict, out: Path, work: Path) -> Path:
    path = out / "book.parallax"
    if path.exists():
        path.unlink()
    con = PX.connect(path)
    meta = book.get("meta", {})
    now = int(time.time())

    src_path = meta.get("source", "")
    src_hash = ""
    for cand in (work.parent / src_path, Path(src_path)):
        if cand.exists():
            src_hash = hashlib.sha1(cand.read_bytes()).hexdigest()
            break

    gpath = work / "glossary.json"
    glossary = json.loads(gpath.read_text(encoding="utf-8")) if gpath.exists() else {}

    con.execute(
        "INSERT INTO doc(id,title,title_ko,author,source_path,source_hash,source_kind,"
        "pages,schema_version,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?)",
        (str(uuid.uuid4()), meta.get("title", ""), glossary.get("title_ko", ""),
         meta.get("author", ""), src_path, src_hash,
         Path(src_path).suffix.lstrip(".").lower() or "pdf",
         meta.get("pages"), PX.SCHEMA_VERSION, now, now))

    con.executemany(
        "INSERT INTO block(id,ord,page,type,src,ko,ko_raw,state,flags,updated_at) "
        "VALUES (?,?,?,?,?,?,?,?,?,?)",
        [(b["id"], (i + 1) * PX.ORD_STEP, b.get("page"), b["type"], b.get("src", ""),
          b.get("ko"), b.get("ko_raw"), PX.state_of(b), PX.flags_of(b), now)
         for i, b in enumerate(book["blocks"])])

    con.executemany("INSERT INTO superseded(page,payload) VALUES (?,?)",
                    [(int(pg), json.dumps(items, ensure_ascii=False))
                     for pg, items in (book.get("superseded") or {}).items()])

    rows = [(en, ko, "term", 0) for en, ko in (glossary.get("terms") or {}).items()]
    rows += [(w, w, "keep_original", 1) for w in (glossary.get("keep_original") or [])]
    con.executemany(
        "INSERT OR REPLACE INTO glossary(en,ko,kind,locked) VALUES (?,?,?,?)", rows)

    con.commit()
    con.close()
    return path


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("book")
    ap.add_argument("--out", default="out")
    args = ap.parse_args()

    book = L.load_book(args.book)
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)

    path = write_parallax(book, out, L.work_dir(args.book))
    n = len(book["blocks"])
    done = sum(1 for b in book["blocks"] if (b.get("ko") or "").strip())
    print(f"{path}  ({path.stat().st_size // 1024} KB · {n} blocks · 번역 {done}/{n})")
    print("\n>> Open it in Parallax.  The English source is embedded — personal use only.")


if __name__ == "__main__":
    main()
