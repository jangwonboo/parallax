#!/usr/bin/env python3
"""PDF -> book.json. Recovers headings, paragraphs, quotes, footnotes; assigns immutable block IDs.

    python scripts/extract.py book.pdf --out work/book.json
"""
from __future__ import annotations

import argparse
import json
import re
import statistics
import sys
from collections import Counter
from pathlib import Path

try:
    import fitz  # PyMuPDF
except ImportError:
    sys.exit("PyMuPDF required:  pip install pymupdf")

# Some PDFs are screen captures of an ebook reader that were OCR'd with a Korean
# language pack enabled. The engine then emits Hangul syllables for Latin letters it
# is unsure about — always the same handful, always inside otherwise-English words.
# Left alone this corrupts roughly 1-2% of words and poisons every downstream stage.
HANGUL_OCR_FIX = {
    "판": "e", "폰": "e", "믄": "e", "픈": "e", "은": "e", "본": "e", "브": "e",
    "으": "e", "판": "e",
    "나": "u", "니": "u",
    "융": "g",
    "아": "OF",
}
CJK_RE = re.compile(r"[\uac00-\ud7a3\u1100-\u11ff\u3130-\u318f\u4e00-\u9fff]")


def repair_ocr_layer(text: str) -> str:
    """Undo Hangul-for-Latin OCR substitutions inside English words."""
    out = []
    for ch in text:
        if ch in HANGUL_OCR_FIX:
            out.append(HANGUL_OCR_FIX[ch])
        elif CJK_RE.match(ch):
            out.append("")  # unmapped stray glyph, almost always a note marker
        else:
            out.append(ch)
    return "".join(out)


def cjk_density(doc, sample: int = 40) -> float:
    words = hits = 0
    for i in range(min(sample, len(doc))):
        for w in doc[i].get_text().split():
            words += 1
            if CJK_RE.search(w):
                hits += 1
    return hits / words if words else 0.0


SKIP_HINTS = ("index", "bibliography", "references", "notes",
              "acknowledgments", "copyright", "contents", "about the author")
FIGCAP_RE = re.compile(r"^(figure|fig\.|table|plate|chart|exhibit)\s*[\d.]", re.I)
CHAPTER_RE = re.compile(
    r"^(chapter|part|book|section)\s+([\divxlcIVXLC]+)|^[IVXLC]{1,6}[.\s]|^\d{1,2}[.\s]", re.I)


# ---------- line assembly ----------

def page_lines(page):
    """Return [{text,size,bold,x0,x1,top,bottom}] for one page, in reading order."""
    out = []
    d = page.get_text("dict")
    for block in d["blocks"]:
        if block.get("type") != 0:
            continue
        for line in block["lines"]:
            spans = [s for s in line["spans"] if s["text"].strip()]
            if not spans:
                continue
            text = "".join(s["text"] for s in line["spans"])
            sizes = [round(s["size"], 1) for s in spans]
            out.append({
                "text": text.rstrip(),
                "page_h": page.rect.height,
                "size": statistics.median(sizes),
                "bold": any("bold" in s["font"].lower() or (s["flags"] & 2 ** 4)
                            for s in spans),
                "italic": any("italic" in s["font"].lower() or (s["flags"] & 2 ** 1)
                              for s in spans),
                "x0": min(s["bbox"][0] for s in spans),
                "x1": max(s["bbox"][2] for s in spans),
                "top": min(s["bbox"][1] for s in spans),
                "bottom": max(s["bbox"][3] for s in spans),
            })
    return out


def detect_columns(lines, page_width):
    """Two-column if x0 values cluster into two well-separated groups."""
    if len(lines) < 10:
        return 1
    mid = page_width / 2
    left = [l for l in lines if l["x1"] < mid + page_width * 0.04]
    right = [l for l in lines if l["x0"] > mid - page_width * 0.04]
    if len(left) > len(lines) * 0.3 and len(right) > len(lines) * 0.3:
        return 2
    return 1


def order_lines(lines, page_width):
    if detect_columns(lines, page_width) == 2:
        mid = page_width / 2
        left = sorted([l for l in lines if l["x0"] < mid], key=lambda l: l["top"])
        right = sorted([l for l in lines if l["x0"] >= mid], key=lambda l: l["top"])
        return left + right
    return sorted(lines, key=lambda l: (round(l["top"], 1), l["x0"]))


BAND = 0.08          # top / bottom fraction of the page a head or folio lives in
FOLIO_RE = re.compile(r"^[\divxlcIVXLC\s.\[\]()—–-]{1,12}$")


def in_band(l) -> bool:
    """True when the line sits wholly inside the top or bottom band of its page."""
    h = l.get("page_h") or 0
    if not h:
        return False
    return l["bottom"] < h * BAND or l["top"] > h * (1 - BAND)


def norm_head(t: str) -> str:
    """Fold whitespace, case and any page number so 'Chapter 3 | 47' matches itself."""
    return re.sub(r"\s+", " ", re.sub(r"\d+", "#", t)).strip().lower()


def strip_running_heads(pages, outline_titles=frozenset()):
    """Drop running heads, running feet and folios.

    Two things were wrong with the obvious version of this.

    **Geometry, not line index.** Taking `lines[:2] + lines[-2:]` calls whatever
    happens to be first on the page an edge line. A drop cap, an epigraph or a
    figure pushes the real head down out of that window, and on a short page the
    first line of body text gets accused instead. The band is a fraction of the
    page height, so it means the same thing on every page.

    **The threshold has to be low.** Books print the head on verso only, drop it on
    chapter openings, full-page figures and part titles. A head that runs on a fifth
    of the pages is entirely normal. Requiring 25% of pages let a head that appeared
    on 37 of 191 pages survive, and `classify()` then scored all 37 as headings —
    short, title case, no terminal punctuation — so the table of contents came out
    with the book title repeated 37 times. Repetition inside the band is already a
    strong signal; three pages is enough to be sure it is furniture.

    A line matching a PDF outline entry is never stripped — a chapter title is
    supposed to sit at the top of its opening page."""
    seen: dict[str, set[int]] = {}
    for pno, lines in enumerate(pages):
        for l in lines:
            if not in_band(l):
                continue
            t = norm_head(l["text"])
            if 0 < len(t) < 70:
                seen.setdefault(t, set()).add(pno)

    threshold = max(3, round(len(pages) * 0.05))
    repeated = {t for t, pgs in seen.items() if len(pgs) >= threshold}

    dropped = Counter()
    for lines in pages:
        keep = []
        for l in lines:
            text = l["text"].strip()
            if in_band(l):
                plain = re.sub(r"\s+", " ", text).strip().lower()
                if plain not in outline_titles:
                    if norm_head(text) in repeated:
                        dropped[text] += 1
                        continue
                    if FOLIO_RE.fullmatch(text):
                        dropped["<folio>"] += 1
                        continue
            keep.append(l)
        lines[:] = keep
    return dropped


# ---------- paragraph merging ----------

def dehyphenate(prev: str, nxt: str) -> str | None:
    if prev[-1:] in HYPHENS and len(prev) > 2 and prev[-2].islower() and nxt[:1].islower():
        return prev[:-1] + nxt
    return None


TERMINAL_RE = re.compile(r'[.!?…”"\'’)\]]\s*$')

# A book sets its line-break hyphen as U+002D, but an OCR'd text layer renders the
# same glyph as U+00AC NOT SIGN or drops in a soft hyphen. This book had 612 of them
# (`am¬ bitious`, `dec¬ ade`), every one a word split at a line end. Treating only
# U+002D as a hyphen leaves those words broken in two for the translator.
HYPHENS = "-¬­‐‑"
SOFT_RE = re.compile(rf"(\w)[{HYPHENS[1:]}]\s*(\w)")


def repair_soft_hyphens(text: str) -> str:
    """Rejoin `am¬ bitious`; keep a real compound as a plain hyphen."""
    def sub(m):
        a, b = m.group(1), m.group(2)
        return a + b if a.islower() and b.islower() else f"{a}-{b}"
    return SOFT_RE.sub(sub, text)


def join_src(prev: str, nxt: str) -> str:
    """Join two halves of one paragraph, undoing a justification hyphen only."""
    a, b = prev.rstrip(), nxt.lstrip()
    if a[-1:] in HYPHENS and len(a) > 2 and a[-2].islower() and b[:1].islower():
        return a[:-1] + b        # re- + counting -> recounting
    if a[-1:] in HYPHENS[1:]:
        return a[:-1] + "-" + b  # a compound the OCR wrote with ¬
    return a + " " + b           # self- + assessment keeps its hyphen


def stitch_blocks(blocks):
    """Rejoin paragraphs that the page break, or a stray style shift, split in two.

    `merge_paragraphs()` runs one page at a time and cannot see across the seam, so
    a paragraph running over a page boundary always came out as two blocks. It is
    the most common structural break in a book — a 191-page book had 88 of them, and
    21 were split mid-word (`worth re-` / `counting. Matter-of-factly…`). Translating
    the halves separately gives the model a fragment with no subject.

    This used to live in `pagecheck.py`, which costs a vision call per page. Most
    runs never get there, so the extractor shipped these breaks downstream. The rule
    is deterministic and needs no model.

    The evidence required differs by where the seam is:

    * **Across a page break** the earlier block ending with no terminal punctuation
      is enough. Demanding that the continuation start lowercase would miss every
      paragraph that breaks before a proper noun (`…a position at Harvard` /
      `University. My intention…`).
    * **Within one page** the extractor had a positive reason to split — a wide gap
      or a font change — so overriding it needs more: either a hyphen at the break
      or a continuation that starts lowercase.

    Body and quote are both accepted because the type classifier is the least
    reliable part of the extractor. When the two disagree the merged block becomes a
    paragraph: a quote that flows into body text was body text all along."""
    BODY = ("p", "quote")
    out: list[dict] = []
    n = 0
    for b in blocks:
        prev = out[-1] if out else None
        if (prev and prev["type"] in BODY and b["type"] in BODY
                and prev.get("translate", True) and b.get("translate", True)
                and not TERMINAL_RE.search(prev["src"])):
            across = b["page"] == prev["page"] + 1
            same_page = b["page"] == prev["page"]
            continues = b["src"][:1].islower() or b["src"][:1] in ",;:"
            if across or (same_page and (prev["src"].rstrip().endswith("-") or continues)):
                prev["src"] = join_src(prev["src"], b["src"])
                if prev["type"] != b["type"]:
                    prev["type"] = "p"
                prev["stitched"] = True
                n += 1
                continue
        out.append(b)
    return out, n


def merge_paragraphs(lines, body_size, body_x0, line_gap, args):
    """Merge lines into blocks. Returns [{text,size,bold,italic,x0,gap_before}]."""
    blocks = []
    cur = None
    prev_bottom = None

    for l in lines:
        gap = (l["top"] - prev_bottom) if prev_bottom is not None else 0
        prev_bottom = l["bottom"]

        indented = l["x0"] > body_x0 + body_size * 0.6
        big_gap = gap > line_gap * args.para_gap
        style_shift = cur is not None and (
            abs(l["size"] - cur["size"]) > 0.6 or l["bold"] != cur["bold"])
        ends_sentence = cur is not None and re.search(r'[.!?…"\'\u201d\u2019]\s*$', cur["text"])
        short_last = cur is not None and cur["last_x1"] < body_x0 + (l["x1"] - body_x0) * 0.82

        start_new = (
            cur is None
            or big_gap
            or style_shift
            or (indented and ends_sentence)
            or (short_last and ends_sentence and indented)
        )

        if start_new:
            if cur:
                blocks.append(cur)
            cur = {"text": l["text"].strip(), "size": l["size"], "bold": l["bold"],
                   "italic": l["italic"], "x0": l["x0"], "last_x1": l["x1"],
                   "gap_before": gap, "top": l["top"]}
        else:
            joined = dehyphenate(cur["text"], l["text"].strip())
            cur["text"] = joined if joined else cur["text"] + " " + l["text"].strip()
            cur["last_x1"] = l["x1"]
    if cur:
        blocks.append(cur)
    return blocks


# ---------- classification ----------

def classify(b, body_size, body_x0, outline_titles, args):
    text = b["text"].strip()
    norm = re.sub(r"\s+", " ", text).lower()

    if norm in outline_titles:
        return "h1"
    if FIGCAP_RE.match(text):
        return "figcaption"
    if b["size"] < body_size * 0.92 and re.match(r"^[\d*†‡]{1,3}[.\s)]", text):
        return "footnote"

    ratio = b["size"] / body_size
    score = 0
    if ratio >= args.heading_ratio:
        score += 2
    if b["bold"] and ratio > 0.98:
        score += 1
    if len(text) < 80:
        score += 1
    if not re.search(r"[.!?]\s*$", text):
        score += 1
    if CHAPTER_RE.match(text):
        score += 2
    if text.isupper() and len(text) < 60:
        score += 1

    if score >= 4:
        if ratio >= args.heading_ratio * 1.25:
            return "h1"
        return "h2" if ratio >= args.heading_ratio else "h3"

    if b["x0"] > body_x0 + body_size * 1.4 or (b["italic"] and len(text) < 400):
        return "quote"
    return "p"


def should_translate(block_type, text, section_flag):
    if section_flag:
        return False
    if block_type == "footnote":
        return True
    if re.fullmatch(r"[\d\s.,:;\-–—/()]+", text):
        return False
    return True


# ---------- main ----------

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("pdf")
    ap.add_argument("--out", default="work/book.json")
    ap.add_argument("--heading-ratio", type=float, default=1.15,
                    help="font-size multiple over body text that suggests a heading")
    ap.add_argument("--para-gap", type=float, default=1.5,
                    help="line-gap multiple that breaks a paragraph")
    ap.add_argument("--repair-ocr", choices=["auto", "on", "off"], default="auto",
                    help="undo Hangul-for-Latin OCR substitutions in the text layer")
    ap.add_argument("--allow-scanned", action="store_true",
                    help="continue with an empty/thin text layer; pagecheck.py rebuilds it")
    ap.add_argument("--translate-all", action="store_true",
                    help="also translate index / bibliography / copyright")
    args = ap.parse_args()

    doc = fitz.open(args.pdf)
    chars = sum(len(p.get_text()) for p in doc)
    if chars / max(len(doc), 1) < 100 and not args.allow_scanned:
        sys.exit(f"Scanned PDF ({chars} chars over {len(doc)} pages).\n"
                 f"  best:  ocrmypdf --skip-text '{args.pdf}' ocr.pdf   then re-run extract\n"
                 f"  or:    extract.py --allow-scanned, then pagecheck.py --vision all")

    outline_titles = {re.sub(r"\s+", " ", t[1]).strip().lower()
                      for t in doc.get_toc(simple=True)}
    print(f"outline entries: {len(outline_titles)}")

    density = cjk_density(doc)
    repair = args.repair_ocr == "on" or (args.repair_ocr == "auto" and density > 0.002)
    if density > 0.002:
        print(f"! Hangul/CJK glyphs in {density:.1%} of words — this text layer was OCR'd "
              f"with a Korean language pack")
    if repair:
        print("  repairing Latin letters written as Hangul (판/폰/은 -> e, 나/니 -> u …)")

    pages = [order_lines(page_lines(p), p.rect.width) for p in doc]
    dropped = strip_running_heads(pages, outline_titles)
    if dropped:
        top = " · ".join(f"{t[:40]!r}×{c}" for t, c in dropped.most_common(3))
        print(f"running heads/folios removed: {sum(dropped.values())} lines  ({top})")

    all_lines = [l for p in pages for l in p]
    if not all_lines:
        if not args.allow_scanned:
            sys.exit("no text extracted")
        print("! empty text layer — writing page placeholders for pagecheck.py")
    body_size = (Counter(round(l["size"], 1) for l in all_lines).most_common(1)[0][0]
                 if all_lines else 10.0)
    body_x0 = statistics.median(l["x0"] for l in all_lines) if all_lines else 0.0
    gaps = [b["top"] - a["bottom"] for p in pages for a, b in zip(p, p[1:])
            if 0 < b["top"] - a["bottom"] < 40]
    line_gap = statistics.median(gaps) if gaps else 4.0
    print(f"body size {body_size}pt · x0 {body_x0:.0f} · line gap {line_gap:.1f}")

    raw_blocks, section_flag = [], False
    for pno, lines in enumerate(pages, 1):
        for raw in merge_paragraphs(lines, body_size, body_x0, line_gap, args):
            text = re.sub(r"\s+", " ", raw["text"]).strip()
            if repair:
                text = re.sub(r"\s+", " ", repair_ocr_layer(text)).strip()
            text = repair_soft_hyphens(text)
            if not text:
                continue
            btype = classify(raw, body_size, body_x0, outline_titles, args)
            if btype.startswith("h"):
                low = text.lower().strip()
                section_flag = any(low.startswith(h) for h in SKIP_HINTS)
            raw_blocks.append({
                "type": btype,
                "page": pno,
                "src": text,
                "ko": None,
                "translate": args.translate_all or should_translate(btype, text, section_flag),
            })

    # Stitch before numbering, so IDs stay contiguous and the "IDs are immutable
    # after pagecheck" contract starts from a settled block list.
    raw_blocks, stitched = stitch_blocks(raw_blocks)
    blocks = [{"id": f"b{i:04d}", **b} for i, b in enumerate(raw_blocks, 1)]

    book = {
        "meta": {
            "source": Path(args.pdf).name,
            "title": doc.metadata.get("title") or Path(args.pdf).stem,
            "author": doc.metadata.get("author") or "",
            "pages": len(doc),
            "register": None,
        },
        "blocks": blocks,
    }

    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(book, ensure_ascii=False, indent=1), encoding="utf-8")

    preview = out.parent / "blocks.txt"
    with preview.open("w", encoding="utf-8") as f:
        for b in blocks:
            mark = " " if b["translate"] else "-"
            f.write(f"{mark}[{b['id']}] ({b['type']:10}) p{b['page']:>3}  {b['src'][:120]}\n")

    kinds = Counter(b["type"] for b in blocks)
    unfinished = sum(1 for b in blocks
                     if b["type"] == "p" and not TERMINAL_RE.search(b["src"]))
    print(f"\n{len(blocks)} blocks -> {out}")
    print("  " + " · ".join(f"{k} {v}" for k, v in kinds.most_common()))
    print(f"  skipped from translation: {sum(1 for b in blocks if not b['translate'])}")
    print(f"  paragraphs stitched back together: {stitched}")
    print(f"  still ending mid-sentence: {unfinished}"
          f"{'  (check blocks.txt — the split may be real)' if unfinished else ''}")
    print(f"\n>> Next: pagecheck.py cross-checks every page with OCR and repairs structure.")
    print(f"   Read {preview} after that — it is rewritten with the repairs applied.")


if __name__ == "__main__":
    main()
