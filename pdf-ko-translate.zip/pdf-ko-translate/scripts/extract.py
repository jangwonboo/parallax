#!/usr/bin/env python3
"""PDF -> book.json. Recovers headings, paragraphs, quotes, footnotes; assigns immutable block IDs.

    python scripts/extract.py book.pdf --out work/book.json
"""
from __future__ import annotations

import argparse
import json
import re
import shutil
import statistics
import subprocess
import sys
from collections import Counter
from pathlib import Path

try:
    import fitz  # PyMuPDF
except ImportError:
    sys.exit("PyMuPDF required:  pip install pymupdf")

# A Windows console is cp949/cp1252, not UTF-8, and `print` raises on the first
# character the codepage cannot hold. An em dash in a progress line was enough to
# kill a run whose book.json had already been written — the caller saw exit 1 and
# threw the extraction away. Progress text must never be able to fail the job.
for _s in (sys.stdout, sys.stderr):
    try:
        _s.reconfigure(errors="replace")
    except Exception:
        pass

# Some PDFs are screen captures of an ebook reader that were OCR'd with a Korean
# language pack enabled. The engine then emits Hangul syllables for Latin letters it
# is unsure about — always the same handful, always inside otherwise-English words.
# Left alone this corrupts roughly 1-2% of words and poisons every downstream stage.
HANGUL_OCR_FIX = {
    "판": "e", "폰": "e", "믄": "e", "픈": "e", "은": "e", "본": "e", "브": "e",
    "으": "e", "판": "e",
    "나": "u", "니": "u",
    "융": "g",
    "아": "OF",
}
CJK_RE = re.compile(r"[\uac00-\ud7a3\u1100-\u11ff\u3130-\u318f\u4e00-\u9fff]")


def repair_ocr_layer(text: str) -> str:
    """Undo Hangul-for-Latin OCR substitutions inside English words."""
    out = []
    for ch in text:
        if ch in HANGUL_OCR_FIX:
            out.append(HANGUL_OCR_FIX[ch])
        elif CJK_RE.match(ch):
            out.append("")  # unmapped stray glyph, almost always a note marker
        else:
            out.append(ch)
    return "".join(out)


def cjk_density(doc, sample: int = 40) -> float:
    words = hits = 0
    for i in range(min(sample, len(doc))):
        for w in doc[i].get_text().split():
            words += 1
            if CJK_RE.search(w):
                hits += 1
    return hits / words if words else 0.0


def scan_backed(doc, sample: int = 20) -> float:
    """Fraction of sampled pages that are a full-page raster with text drawn over it.

    This is what an OCR sandwich looks like: the page you see is a photograph, and the
    text layer is what an engine read off it. Such a layer is not authoritative — its
    characters are a guess, so pagecheck's `--trust vision` applies to it and not to a
    born-digital PDF. The Hangul-glyph heuristic below only catches layers OCR'd with a
    Korean language pack, which is a small corner of the same problem.
    """
    n = len(doc)
    if not n:
        return 0.0
    step = max(1, n // sample)
    seen = covered = 0
    for i in range(0, n, step):
        page = doc[i]
        area = abs(page.rect)
        if not area:
            continue
        seen += 1
        for img in page.get_images(full=True):
            if any(abs(r) / area >= 0.8 for r in page.get_image_rects(img[0])):
                covered += 1
                break
    return covered / seen if seen else 0.0


SKIP_HINTS = ("index", "bibliography", "references", "notes",
              "acknowledgments", "copyright", "contents", "about the author")
FIGCAP_RE = re.compile(r"^(figure|fig\.|table|plate|chart|exhibit)\s*[\d.]", re.I)
CHAPTER_RE = re.compile(
    r"^(chapter|part|book|section)\s+([\divxlcIVXLC]+)|^[IVXLC]{1,6}[.\s]|^\d{1,2}[.\s]", re.I)


# ---------- line assembly ----------

def page_lines(page):
    """Return [{text,size,bold,x0,x1,top,bottom}] for one page, in reading order."""
    out = []
    d = page.get_text("dict")
    for block in d["blocks"]:
        if block.get("type") != 0:
            continue
        for line in block["lines"]:
            spans = [s for s in line["spans"] if s["text"].strip()]
            if not spans:
                continue
            text = "".join(s["text"] for s in line["spans"])
            sizes = [round(s["size"], 1) for s in spans]
            out.append({
                "text": text.rstrip(),
                "page_h": page.rect.height,
                "size": statistics.median(sizes),
                "bold": any("bold" in s["font"].lower() or (s["flags"] & 2 ** 4)
                            for s in spans),
                "italic": any("italic" in s["font"].lower() or (s["flags"] & 2 ** 1)
                              for s in spans),
                "x0": min(s["bbox"][0] for s in spans),
                "x1": max(s["bbox"][2] for s in spans),
                "top": min(s["bbox"][1] for s in spans),
                "bottom": max(s["bbox"][3] for s in spans),
            })
    return out


def detect_columns(lines, page_width):
    """Two-column if x0 values cluster into two well-separated groups."""
    if len(lines) < 10:
        return 1
    mid = page_width / 2
    left = [l for l in lines if l["x1"] < mid + page_width * 0.04]
    right = [l for l in lines if l["x0"] > mid - page_width * 0.04]
    if len(left) > len(lines) * 0.3 and len(right) > len(lines) * 0.3:
        return 2
    return 1


def order_lines(lines, page_width):
    if detect_columns(lines, page_width) == 2:
        mid = page_width / 2
        left = sorted([l for l in lines if l["x0"] < mid], key=lambda l: l["top"])
        right = sorted([l for l in lines if l["x0"] >= mid], key=lambda l: l["top"])
        return left + right
    return sorted(lines, key=lambda l: (round(l["top"], 1), l["x0"]))


BAND = 0.08          # top / bottom fraction of the page a head or folio lives in
FOLIO_RE = re.compile(r"^[\divxlcIVXLC\s.\[\]()—–-]{1,12}$")


def in_band(l) -> bool:
    """True when the line sits wholly inside the top or bottom band of its page."""
    h = l.get("page_h") or 0
    if not h:
        return False
    return l["bottom"] < h * BAND or l["top"] > h * (1 - BAND)


def norm_head(t: str) -> str:
    """Fold whitespace, case and any page number so 'Chapter 3 | 47' matches itself."""
    return re.sub(r"\s+", " ", re.sub(r"\d+", "#", t)).strip().lower()


def strip_running_heads(pages, outline_titles=frozenset()):
    """Drop running heads, running feet and folios.

    Two things were wrong with the obvious version of this.

    **Geometry, not line index.** Taking `lines[:2] + lines[-2:]` calls whatever
    happens to be first on the page an edge line. A drop cap, an epigraph or a
    figure pushes the real head down out of that window, and on a short page the
    first line of body text gets accused instead. The band is a fraction of the
    page height, so it means the same thing on every page.

    **The threshold has to be low.** Books print the head on verso only, drop it on
    chapter openings, full-page figures and part titles. A head that runs on a fifth
    of the pages is entirely normal. Requiring 25% of pages let a head that appeared
    on 37 of 191 pages survive, and `classify()` then scored all 37 as headings —
    short, title case, no terminal punctuation — so the table of contents came out
    with the book title repeated 37 times. Repetition inside the band is already a
    strong signal; three pages is enough to be sure it is furniture.

    A line matching a PDF outline entry is never stripped — a chapter title is
    supposed to sit at the top of its opening page."""
    seen: dict[str, set[int]] = {}
    for pno, lines in enumerate(pages):
        for l in lines:
            if not in_band(l):
                continue
            t = norm_head(l["text"])
            if 0 < len(t) < 70:
                seen.setdefault(t, set()).add(pno)

    threshold = max(3, round(len(pages) * 0.05))
    repeated = {t for t, pgs in seen.items() if len(pgs) >= threshold}

    dropped = Counter()
    for lines in pages:
        keep = []
        for l in lines:
            text = l["text"].strip()
            if in_band(l):
                plain = re.sub(r"\s+", " ", text).strip().lower()
                if plain not in outline_titles:
                    if norm_head(text) in repeated:
                        dropped[text] += 1
                        continue
                    if FOLIO_RE.fullmatch(text):
                        dropped["<folio>"] += 1
                        continue
            keep.append(l)
        lines[:] = keep
    return dropped


# ---------- paragraph merging ----------

def dehyphenate(prev: str, nxt: str) -> str | None:
    if prev[-1:] in HYPHENS and len(prev) > 2 and prev[-2].islower() and nxt[:1].islower():
        return prev[:-1] + nxt
    return None


TERMINAL_RE = re.compile(r'[.!?…”"\'’)\]]\s*$')

# A book sets its line-break hyphen as U+002D, but an OCR'd text layer renders the
# same glyph as U+00AC NOT SIGN or drops in a soft hyphen. This book had 612 of them
# (`am¬ bitious`, `dec¬ ade`), every one a word split at a line end. Treating only
# U+002D as a hyphen leaves those words broken in two for the translator.
HYPHENS = "-¬­‐‑"
SOFT_RE = re.compile(rf"(\w)[{HYPHENS[1:]}]\s*(\w)")


def repair_soft_hyphens(text: str) -> str:
    """Rejoin `am¬ bitious`; keep a real compound as a plain hyphen."""
    def sub(m):
        a, b = m.group(1), m.group(2)
        return a + b if a.islower() and b.islower() else f"{a}-{b}"
    return SOFT_RE.sub(sub, text)


def join_src(prev: str, nxt: str) -> str:
    """Join two halves of one paragraph, undoing a justification hyphen only."""
    a, b = prev.rstrip(), nxt.lstrip()
    if a[-1:] in HYPHENS and len(a) > 2 and a[-2].islower() and b[:1].islower():
        return a[:-1] + b        # re- + counting -> recounting
    if a[-1:] in HYPHENS[1:]:
        return a[:-1] + "-" + b  # a compound the OCR wrote with ¬
    return a + " " + b           # self- + assessment keeps its hyphen


def demote_numbered_items(blocks) -> int:
    """굵은 번호로 시작하는 문항이 각주·제목으로 오분류된 것을 본문으로 되돌린다.

    자기평가 문항 같은 번호 목록은 번호만 굵어서 폰트 신호가 흔들리고, 실제로
    한 책에서 문항 여덟 개가 전부 footnote 로 분류됐다. footnote 는 stitch 의
    본문 유형에 들지 않아 쪽·줄 경계로 쪼개진 문항이 이어지지도 못한다 —
    그래서 stitch **전에** 돌려야 한다. 진짜 각주는 `[14]` 처럼 대괄호 마커로
    시작하므로 걸리지 않는다. 60자 미만의 짧은 번호 제목(`1. Introduction`)도
    남긴다."""
    n = 0
    for b in blocks:
        if (str(b.get("type", "")) in ("footnote", "h1", "h2", "h3")
                and re.match(r"^\d+[.)] ", b.get("src", ""))
                and len(b["src"]) >= 60
                and not b["src"].startswith("[")):
            b["type"] = "p"
            n += 1
    return n


def stitch_blocks(blocks):
    """Rejoin paragraphs that the page break, or a stray style shift, split in two.

    `merge_paragraphs()` runs one page at a time and cannot see across the seam, so
    a paragraph running over a page boundary always came out as two blocks. It is
    the most common structural break in a book — a 191-page book had 88 of them, and
    21 were split mid-word (`worth re-` / `counting. Matter-of-factly…`). Translating
    the halves separately gives the model a fragment with no subject.

    This used to live in `pagecheck.py`, which costs a vision call per page. Most
    runs never get there, so the extractor shipped these breaks downstream. The rule
    is deterministic and needs no model.

    The evidence required differs by where the seam is:

    * **Across a page break** the earlier block ending with no terminal punctuation
      is enough. Demanding that the continuation start lowercase would miss every
      paragraph that breaks before a proper noun (`…a position at Harvard` /
      `University. My intention…`).
    * **Within one page** the extractor had a positive reason to split — a wide gap
      or a font change — so overriding it needs more: either a hyphen at the break
      or a continuation that starts lowercase.

    Body and quote are both accepted because the type classifier is the least
    reliable part of the extractor. When the two disagree the merged block becomes a
    paragraph: a quote that flows into body text was body text all along."""
    BODY = ("p", "quote")
    out: list[dict] = []
    n = 0
    for b in blocks:
        prev = out[-1] if out else None
        if (prev and prev["type"] in BODY and b["type"] in BODY
                and prev.get("translate", True) and b.get("translate", True)
                and not TERMINAL_RE.search(prev["src"])):
            across = b["page"] == prev["page"] + 1
            same_page = b["page"] == prev["page"]
            continues = b["src"][:1].islower() or b["src"][:1] in ",;:"
            # 분철 하이픈으로 끝났는데 다음이 대문자로 시작하면 그 블록은 낱말의
            # 나머지가 아니다 — 레이어가 다음 페이지 첫 조각을 잃었거나 제목이
            # 섞여 든 것이다. 실제로 `…a diffi¬` 뒤에 제목+문항 융합 블록이 붙어
            # `diffiQuestions…` 가 됐다. 잇지 말고 두는 쪽이 복구 가능하다.
            fused = prev["src"].rstrip()[-1:] in HYPHENS and b["src"][:1].isupper()
            if not fused and (across or (same_page and (prev["src"].rstrip().endswith("-") or continues))):
                prev["src"] = join_src(prev["src"], b["src"])
                if prev["type"] != b["type"]:
                    prev["type"] = "p"
                prev["stitched"] = True
                n += 1
                continue
        out.append(b)
    return out, n


# ---------- heading levels ----------

CHAPTER_MARK_RE = re.compile(
    r"^(chapter|part|book|section)\s+([0-9]{1,3}|[ivxlcdm]{1,7})\b", re.I)

# 장과 나란히 서는 앞뒤 부속물. 소문자·구두점 제거 후 비교한다.
TOP_LEVEL_TITLES = {
    "contents", "table of contents", "introduction", "prologue", "epilogue",
    "preface", "foreword", "afterword", "conclusion", "acknowledgments",
    "acknowledgements", "notes", "index", "bibliography", "about the author",
    "appendix", "dedication", "epigraph",
}


def normalize_headings(book_blocks) -> int:
    """제목 레벨을 문서 전체에서 일관되게 만든다.

    레벨이 어긋나는 데에는 하류에서 고칠 수 없는 이유가 있다. extract 는 폰트
    크기로 레벨을 추론하는데 같은 장 제목이라도 쪽마다 조판이 조금씩 다르고,
    `pagecheck --trust vision` 은 한 페이지씩 따로 읽으므로 같은 종류의 제목이
    어느 쪽에 실렸느냐에 따라 다른 레벨을 받는다. 실제로 한 책에서 CHAPTER 1 이
    h3, CHAPTER 2 가 h2, CHAPTER 3 이 h3 로 나왔다. 이 레벨로 목차를 만들면 장이
    그 장에 속한 절보다 아래에 놓인다.

    단행본에는 두 단계면 충분하다 — 장을 여는 제목과 그 나머지. 더 잘게 나누려면
    추측해야 하는데, 틀린 추측은 평평한 목록보다 나쁘다.

    바꾼 블록 수를 돌려준다."""
    changed = 0
    for b in book_blocks:
        if not str(b.get("type", "")).startswith("h"):
            continue
        text = re.sub(r"\s+", " ", b.get("src", "")).strip()
        # 번호 목록 항목이 제목으로 읽힌 것 — 자기평가 문항처럼 굵은 번호로
        # 시작하는 문장을 비전이 쪽마다 다르게 제목으로 올린다(실제로 문항
        # 1~4는 본문, 같은 목록의 5~8만 h2 가 됐다). 번호로 시작하면서 문장
        # 길이면 제목이 아니다. "1. Introduction" 같은 짧은 번호 제목은 남는다.
        if re.match(r"^\d+[.)] ", text) and len(text) >= 60:
            b["type"] = "p"
            changed += 1
            continue
        low = text.lower().strip(" .:·—-")
        want = "h1" if (CHAPTER_MARK_RE.match(text) or low in TOP_LEVEL_TITLES) else "h2"
        if b["type"] != want:
            b["type"] = want
            changed += 1
    return changed


def merge_paragraphs(lines, body_size, body_x0, line_gap, args):
    """Merge lines into blocks. Returns [{text,size,bold,italic,x0,gap_before}]."""
    blocks = []
    cur = None
    prev_bottom = None

    for l in lines:
        gap = (l["top"] - prev_bottom) if prev_bottom is not None else 0
        prev_bottom = l["bottom"]

        indented = l["x0"] > body_x0 + body_size * 0.6
        big_gap = gap > line_gap * args.para_gap
        style_shift = cur is not None and (
            abs(l["size"] - cur["size"]) > 0.6 or l["bold"] != cur["bold"])
        ends_sentence = cur is not None and re.search(r'[.!?…"\'\u201d\u2019]\s*$', cur["text"])
        short_last = cur is not None and cur["last_x1"] < body_x0 + (l["x1"] - body_x0) * 0.82

        start_new = (
            cur is None
            or big_gap
            or style_shift
            or (indented and ends_sentence)
            or (short_last and ends_sentence and indented)
        )

        if start_new:
            if cur:
                blocks.append(cur)
            cur = {"text": l["text"].strip(), "size": l["size"], "bold": l["bold"],
                   "italic": l["italic"], "x0": l["x0"], "last_x1": l["x1"],
                   "gap_before": gap, "top": l["top"]}
        else:
            joined = dehyphenate(cur["text"], l["text"].strip())
            cur["text"] = joined if joined else cur["text"] + " " + l["text"].strip()
            cur["last_x1"] = l["x1"]
    if cur:
        blocks.append(cur)
    return blocks


# ---------- classification ----------

def classify(b, body_size, body_x0, outline_titles, args):
    text = b["text"].strip()
    norm = re.sub(r"\s+", " ", text).lower()

    if norm in outline_titles:
        return "h1"
    if FIGCAP_RE.match(text):
        return "figcaption"
    if b["size"] < body_size * 0.92 and re.match(r"^[\d*†‡]{1,3}[.\s)]", text):
        return "footnote"

    ratio = b["size"] / body_size
    score = 0
    if ratio >= args.heading_ratio:
        score += 2
    if b["bold"] and ratio > 0.98:
        score += 1
    if len(text) < 80:
        score += 1
    if not re.search(r"[.!?]\s*$", text):
        score += 1
    if CHAPTER_RE.match(text):
        score += 2
    if text.isupper() and len(text) < 60:
        score += 1

    if score >= 4:
        if ratio >= args.heading_ratio * 1.25:
            return "h1"
        return "h2" if ratio >= args.heading_ratio else "h3"

    if b["x0"] > body_x0 + body_size * 1.4 or (b["italic"] and len(text) < 400):
        return "quote"
    return "p"


def should_translate(block_type, text, section_flag):
    if section_flag:
        return False
    if block_type == "footnote":
        return True
    if re.fullmatch(r"[\d\s.,:;\-–—/()]+", text):
        return False
    return True


# ---------- main ----------

# ---------- OCR layer for scan-only PDFs ----------

def find_tesseract_cli() -> str | None:
    """PATH 에 없어도 표준 설치 위치를 뒤진다 — Windows 설치기는 PATH 를 안 건드린다."""
    hit = shutil.which("tesseract")
    if hit:
        return hit
    for c in (r"C:\Program Files\Tesseract-OCR\tesseract.exe",
              r"C:\Program Files (x86)\Tesseract-OCR\tesseract.exe"):
        if Path(c).exists():
            return c
    return None


def ensure_text_layer(pdf_path: str, work: Path, lang: str, dpi: int = 300) -> str:
    """텍스트 레이어가 없는 순수 스캔 PDF 에 Tesseract 로 레이어를 입힌 사본을 만든다.

    파이프라인은 텍스트 레이어를 닻으로 쓴다 — 블록 ID·페이지 대응·pagecheck 의
    삽입 기준이 전부 레이어 블록에 걸린다. 레이어가 아예 없으면 비전이 읽은
    텍스트도 붙일 곳이 없어 조용히 버려진다. 글자 품질은 중요하지 않다.
    `--trust vision` 이 어차피 이미지에서 다시 받아쓴다.

    ocrmypdf 가 아니라 Tesseract 를 직접 부른다 — ocrmypdf 는 Ghostscript 가
    필수인데 Windows 에서 그 설치가 가장 큰 장벽이다. Tesseract 의 pdf 출력을
    쪽마다 만들어 PyMuPDF 로 합치면 같은 결과(검색 가능한 PDF)가 나온다.

    레이어가 이미 있으면(쪽당 100자 이상) 원본 경로를 그대로 돌려준다."""
    doc = fitz.open(pdf_path)
    if sum(len(p.get_text()) for p in doc) / max(len(doc), 1) >= 100:
        doc.close()
        return pdf_path

    tess = find_tesseract_cli()
    if not tess:
        sys.exit(f"Scanned PDF with no text layer, and no Tesseract to build one.\n"
                 f"  install:  winget install UB-Mannheim.TesseractOCR\n"
                 f"  or:       extract.py --allow-scanned  (placeholders only)")

    print(f"no text layer — building one with tesseract ({lang}, {dpi}dpi, {len(doc)} pages)",
          flush=True)
    tmp = work / "ocr-layer"
    tmp.mkdir(parents=True, exist_ok=True)
    merged = fitz.open()
    for i, page in enumerate(doc):
        png = tmp / f"p{i:04d}.png"
        base = tmp / f"p{i:04d}"
        page.get_pixmap(dpi=dpi).save(png)
        r = subprocess.run([tess, str(png), str(base), "-l", lang, "--dpi", str(dpi), "pdf"],
                           capture_output=True, text=True)
        if r.returncode != 0:
            sys.exit(f"tesseract failed on page {i+1}: {r.stderr.strip()[:300]}")
        with fitz.open(str(base) + ".pdf") as pg:
            merged.insert_pdf(pg)
        png.unlink()
        Path(str(base) + ".pdf").unlink()
        if (i + 1) % 10 == 0 or i + 1 == len(doc):
            print(f"[{i+1}/{len(doc)}] {int(100*(i+1)/len(doc))}% ocr layer", flush=True)
    doc.close()
    out = work / (Path(pdf_path).stem + ".ocr.pdf")
    merged.save(str(out), garbage=3, deflate=True)
    merged.close()
    tmp.rmdir()
    print(f"-> {out}", flush=True)
    return str(out)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("pdf")
    ap.add_argument("--out", default="work/book.json")
    ap.add_argument("--heading-ratio", type=float, default=1.15,
                    help="font-size multiple over body text that suggests a heading")
    ap.add_argument("--para-gap", type=float, default=1.5,
                    help="line-gap multiple that breaks a paragraph")
    ap.add_argument("--repair-ocr", choices=["auto", "on", "off"], default="auto",
                    help="undo Hangul-for-Latin OCR substitutions in the text layer")
    ap.add_argument("--allow-scanned", action="store_true",
                    help="continue with an empty/thin text layer; pagecheck.py rebuilds it")
    ap.add_argument("--ocr-lang", default="eng",
                    help="tesseract language(s) for the auto-built text layer, e.g. eng+kor")
    ap.add_argument("--translate-all", action="store_true",
                    help="also translate index / bibliography / copyright")
    ap.add_argument("--keep-heading-levels", action="store_true",
                    help="leave h1/h2/h3 as inferred; by default they are flattened to "
                         "h1 (chapter openers) and h2 (everything else) so the table of "
                         "contents is not ordered by whichever page a heading landed on")
    args = ap.parse_args()

    # 순수 스캔이면 Tesseract 로 레이어를 입힌 사본으로 바꿔 탄다. 사본은
    # book.json 옆(작업 폴더)에 남는다 — pagecheck 는 원본 PDF 로 불러도 된다.
    # 쪽 이미지가 같으므로 어느 쪽이든 무방하다.
    orig_pdf = args.pdf   # meta.source 는 사용자가 가진 원본 이름이어야 한다
    if not args.allow_scanned:
        work_dir = Path(args.out).parent
        work_dir.mkdir(parents=True, exist_ok=True)
        args.pdf = ensure_text_layer(args.pdf, work_dir, args.ocr_lang)

    doc = fitz.open(args.pdf)

    outline_titles = {re.sub(r"\s+", " ", t[1]).strip().lower()
                      for t in doc.get_toc(simple=True)}
    print(f"outline entries: {len(outline_titles)}")

    density = cjk_density(doc)
    scanned = scan_backed(doc)
    ocr_layer = density > 0.002 or scanned >= 0.6
    repair = args.repair_ocr == "on" or (args.repair_ocr == "auto" and density > 0.002)
    if density > 0.002:
        print(f"! Hangul/CJK glyphs in {density:.1%} of words — this text layer was OCR'd "
              f"with a Korean language pack")
    if scanned >= 0.6:
        print(f"! {scanned:.0%} of sampled pages are a full-page image with text over it — "
              f"the text layer is OCR output, not the document's own characters")
    if repair:
        print("  repairing Latin letters written as Hangul (판/폰/은 -> e, 나/니 -> u …)")

    pages = [order_lines(page_lines(p), p.rect.width) for p in doc]
    dropped = strip_running_heads(pages, outline_titles)
    if dropped:
        top = " · ".join(f"{t[:40]!r}×{c}" for t, c in dropped.most_common(3))
        print(f"running heads/folios removed: {sum(dropped.values())} lines  ({top})")

    all_lines = [l for p in pages for l in p]
    if not all_lines:
        if not args.allow_scanned:
            sys.exit("no text extracted")
        print("! empty text layer — writing page placeholders for pagecheck.py")
    body_size = (Counter(round(l["size"], 1) for l in all_lines).most_common(1)[0][0]
                 if all_lines else 10.0)
    body_x0 = statistics.median(l["x0"] for l in all_lines) if all_lines else 0.0
    gaps = [b["top"] - a["bottom"] for p in pages for a, b in zip(p, p[1:])
            if 0 < b["top"] - a["bottom"] < 40]
    line_gap = statistics.median(gaps) if gaps else 4.0
    print(f"body size {body_size}pt · x0 {body_x0:.0f} · line gap {line_gap:.1f}")

    raw_blocks, section_flag = [], False
    for pno, lines in enumerate(pages, 1):
        for raw in merge_paragraphs(lines, body_size, body_x0, line_gap, args):
            text = re.sub(r"\s+", " ", raw["text"]).strip()
            if repair:
                text = re.sub(r"\s+", " ", repair_ocr_layer(text)).strip()
            text = repair_soft_hyphens(text)
            if not text:
                continue
            btype = classify(raw, body_size, body_x0, outline_titles, args)
            if btype.startswith("h"):
                low = text.lower().strip()
                section_flag = any(low.startswith(h) for h in SKIP_HINTS)
            raw_blocks.append({
                "type": btype,
                "page": pno,
                "src": text,
                "ko": None,
                "translate": args.translate_all or should_translate(btype, text, section_flag),
            })

    # Stitch before numbering, so IDs stay contiguous and the "IDs are immutable
    # after pagecheck" contract starts from a settled block list.
    # 번호 문항 강등은 stitch 보다 먼저 — footnote 로 오분류된 문항은 본문
    # 유형이 아니라서 쪼개진 반쪽이 이어지지 못한다.
    demote_numbered_items(raw_blocks)
    raw_blocks, stitched = stitch_blocks(raw_blocks)
    leveled = 0 if args.keep_heading_levels else normalize_headings(raw_blocks)
    blocks = [{"id": f"b{i:04d}", **b} for i, b in enumerate(raw_blocks, 1)]

    book = {
        "meta": {
            "source": Path(orig_pdf).name,
            "title": doc.metadata.get("title") or Path(orig_pdf).stem,
            "author": doc.metadata.get("author") or "",
            "pages": len(doc),
            "register": None,
            # 텍스트 레이어 자체가 OCR 산출물인가. pagecheck 의 --trust 를 무엇으로
            # 둘지는 이 한 가지에 달려 있는데, 지금까지는 화면에 찍고 버려서
            # 사람이 로그를 읽어야만 알 수 있었다. 앱이 물어보려면 값이 필요하다.
            "ocr_layer": ocr_layer,
        },
        "blocks": blocks,
    }

    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(book, ensure_ascii=False, indent=1), encoding="utf-8")

    preview = out.parent / "blocks.txt"
    with preview.open("w", encoding="utf-8") as f:
        for b in blocks:
            mark = " " if b["translate"] else "-"
            f.write(f"{mark}[{b['id']}] ({b['type']:10}) p{b['page']:>3}  {b['src'][:120]}\n")

    kinds = Counter(b["type"] for b in blocks)
    unfinished = sum(1 for b in blocks
                     if b["type"] == "p" and not TERMINAL_RE.search(b["src"]))
    print(f"\n{len(blocks)} blocks -> {out}")
    print("  " + " · ".join(f"{k} {v}" for k, v in kinds.most_common()))
    print(f"  skipped from translation: {sum(1 for b in blocks if not b['translate'])}")
    print(f"  paragraphs stitched back together: {stitched}")
    print(f"  heading levels normalised: {leveled}")
    print(f"  still ending mid-sentence: {unfinished}"
          f"{'  (check blocks.txt — the split may be real)' if unfinished else ''}")
    print(f"\n>> Next: pagecheck.py cross-checks every page with OCR and repairs structure.")
    print(f"   Read {preview} after that — it is rewritten with the repairs applied.")


if __name__ == "__main__":
    main()
