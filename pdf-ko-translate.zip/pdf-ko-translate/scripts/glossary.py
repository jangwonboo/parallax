#!/usr/bin/env python3
"""Build work/glossary.json — fixed Korean equivalents for names/terms, plus a
character sheet (speech register + who-addresses-whom) for fiction.

    python scripts/glossary.py work/book.json --fiction
"""
from __future__ import annotations

import argparse
import json
import re
from collections import Counter
from pathlib import Path

import _llm as L

STOP = set("""the a an and or but if while of to in on at by for with from as is are was were
be been being this that these those it its he she they we you i his her their our your my
not no all any some more most other such than then there here when where which who whom what
how why can could will would shall should may might must do does did have has had one two
chapter part book page""".split())

TERM_SYS = """You extract translation glossary candidates from an English book.

From the excerpts, list terms whose Korean rendering must stay identical across the whole book:
- personal names, place names, organization names
- domain concepts the author uses repeatedly, especially ones given a special meaning
- titles of works

For each, give the standard Korean rendering. Use the established Korean form when one exists
(Florence -> 피렌체, not 플로렌스). For company, index, product and acronym names that Korean
publishing normally leaves in Latin script, output the original unchanged and mark keep_original.

Output JSON only, no prose, no code fence:
{"terms": {"English": "한국어"}, "keep_original": ["S&P 500"]}"""

CHAR_SYS = """You build a character sheet for a Korean literary translation.

English has no honorific system; Korean forces a choice in every line of dialogue. Decide it once
here so the translation stays consistent across chapters.

For each significant character:
- en: name as printed
- ko: Korean rendering
- role: one short phrase
- speech: a reproducible instruction, not an adjective. Say what to do with sentence length,
  endings, vocabulary and tone — e.g. "짧은 문장, 종결어미 생략, 명령형 위주" beats "거칠다".
- addresses: {other character: "반말" | "존댓말" | "존댓말(호칭)"} — direction matters;
  A to B being 반말 does not make B to A 반말.

Output JSON only, no prose, no code fence:
{"characters": [{"en":"","ko":"","role":"","speech":"","addresses":{}}]}"""


def candidate_terms(blocks, top=180):
    counts = Counter()
    for b in blocks:
        for m in re.finditer(r"\b([A-Z][a-zA-Z'’\-]+(?:\s+[A-Z][a-zA-Z'’\-]+){0,3})\b", b["src"]):
            phrase = m.group(1).strip()
            if m.start() == 0 and " " not in phrase:
                continue  # sentence-initial capital, probably not a name
            if phrase.lower() in STOP or len(phrase) < 3:
                continue
            counts[phrase] += 1
    return [t for t, c in counts.most_common(top) if c >= 3]


def sample(blocks, n=28):
    """Evenly spaced prose blocks across the whole book."""
    prose = [b for b in blocks if b["type"] in ("p", "quote") and len(b["src"]) > 200]
    if not prose:
        prose = blocks
    step = max(1, len(prose) // n)
    return prose[::step][:n]


def strip_fence(text: str) -> str:
    return re.sub(r"^```(?:json)?\s*|\s*```$", "", text.strip())


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("book")
    ap.add_argument("--fiction", action="store_true", help="also build the character sheet")
    ap.add_argument("--force", action="store_true")
    args = ap.parse_args()

    book = L.load_book(args.book)
    work = L.work_dir(args.book)
    out = work / "glossary.json"
    if out.exists() and not args.force:
        print(f"{out} exists — use --force to rebuild")
        return

    blocks = L.translatable(book)
    cands = candidate_terms(blocks)
    excerpts = "\n\n".join(b["src"][:600] for b in sample(blocks))

    print(f"{len(cands)} candidate terms · asking for Korean equivalents")
    raw = L.call(TERM_SYS,
                 f"Candidate terms by frequency:\n{', '.join(cands)}\n\n"
                 f"Excerpts:\n{excerpts}",
                 max_tokens=4000)
    try:
        data = json.loads(strip_fence(raw))
    except json.JSONDecodeError:
        print("! could not parse term JSON; writing empty skeleton")
        data = {"terms": {}, "keep_original": []}

    glossary = {
        "title_ko": book["meta"].get("title", ""),
        "terms": data.get("terms", {}),
        "keep_original": data.get("keep_original", []),
        "characters": [],
    }

    if args.fiction:
        print("building character sheet")
        dialogue = [b["src"] for b in blocks if '"' in b["src"] or "“" in b["src"]]
        step = max(1, len(dialogue) // 30)
        raw = L.call(CHAR_SYS,
                     "Dialogue-bearing excerpts:\n\n" +
                     "\n\n".join(d[:500] for d in dialogue[::step][:30]),
                     max_tokens=4000)
        try:
            glossary["characters"] = json.loads(strip_fence(raw)).get("characters", [])
        except json.JSONDecodeError:
            print("! could not parse character JSON")

    out.write_text(json.dumps(glossary, ensure_ascii=False, indent=1), encoding="utf-8")

    print(f"\nterms {len(glossary['terms'])} · keep_original {len(glossary['keep_original'])} "
          f"· characters {len(glossary['characters'])}")
    print(f"\n>> {out} is a DRAFT. Open it and fix it before translating.")
    print("   Check: 관용역이 있는 지명/인명, 동음이의어, 저자 고유 용어"
          + (", 인물 관계의 방향성" if args.fiction else ""))


if __name__ == "__main__":
    main()
