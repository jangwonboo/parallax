#!/usr/bin/env python3
"""Per-page cross-check. Reads every page as an image and compares it against what
extract.py pulled from the PDF text layer — then repairs the structure.

Two engines:

  --engine vision     (default) a cheap vision model reads every page.
                      ~$0.0075/page on Haiku, so ~$2.3 for a 300-page book.
                      No local binary needed. Sees structure, not just characters.
  --engine tesseract  local OCR on every page, vision only on flagged pages.
                      Free and offline, but it only detects problems — it cannot fix them.

    python scripts/pagecheck.py work/book.json --pdf book.pdf
    python scripts/pagecheck.py work/book.json --pdf book.pdf --pages 1-40   # cost probe
    python scripts/pagecheck.py work/book.json --pdf book.pdf --engine tesseract

WHO WINS WHAT
  The text layer is character-exact but structurally blind. A vision model is
  structurally smart but not character-exact — it quietly normalizes archaic spelling,
  fixes typos the author meant, and writes fluent text over a line it skipped. So:
  characters come from the text layer, structure comes from vision. Page text read by
  the model is used only to measure coverage and to recover text the layer never had.

IDs are immutable from this point on. Blocks inserted here get suffixed IDs (b0042a)
so existing translation caches stay valid.
"""
from __future__ import annotations

import argparse
import json
import re
import shutil
import subprocess
import sys
import tempfile
from collections import Counter, defaultdict
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

import _llm as L
from extract import normalize_headings

try:
    import fitz
except ImportError:
    sys.exit("PyMuPDF required:  pip install pymupdf")

WORD_RE = re.compile(r"[a-z0-9']+")

VISION_SYS = """You read one page of a book and proof a machine extraction of it.

You get the page image and the blocks extraction pulled from the PDF text layer.

Do two things.

1. TRANSCRIBE the page body exactly as printed. Skip the running head, the running
   footer and the page number. Do not correct spelling, do not modernize archaic forms,
   do not fix what looks like a typo — an author's deliberate misspelling is not an
   error. If a line is illegible, write [?] rather than guessing.

2. REPORT what the extraction got wrong. Only what is wrong.
   - reading order, especially multi-column pages where extraction interleaves columns
   - block types: h1/h2/h3 (headings), p (body), quote (block quotation or epigraph),
     figcaption, footnote, table_raw
   - body text visible on the page that appears in NO block — the text layer drops text
     inside images, drop caps, sidebars and rotated captions
   - blocks holding the running head or page number, which should be dropped

Copy missing text verbatim. Never invent text you cannot read.

REBUILD is the last resort. Use it only when the blocks are damaged in a way that
reordering and retyping cannot repair — most often two columns interleaved INSIDE a
single block, so one block holds alternating lines from both columns. Then return the
whole page as a fresh block list in correct reading order. Do not use rebuild for a
page that merely needs reordering or a type fix; rebuilt text comes from your reading,
which is less reliable than the PDF's own text layer.

Output JSON only, no prose, no code fence:
{"text": "full page transcription",
 "columns": 1,
 "order": ["b0012","b0013"],
 "types": {"b0014":"h2"},
 "missing": [{"after":"b0015","type":"p","text":"..."}],
 "drop": ["b0019"],
 "rebuild": [{"type":"h2","text":"..."},{"type":"p","text":"..."}],
 "notes": "one short line, or empty"}

Omit every key you have no correction for."""


# `--trust vision`. The prompt above defends the text layer because in a normal PDF
# the layer is character-exact and a vision model is not: it modernises archaic
# spelling, silently corrects an author's deliberate misspelling, and skips a line
# while producing a sentence that still reads smoothly. Trusting it there loses more
# than it gains.
#
# That argument collapses when the layer is itself an OCR artifact — a scan, or a
# screen capture of an ebook reader run through an OCR engine. Then the layer is not
# character-exact either, and it is wrong in ways nothing downstream can repair:
# `bom` for `born`, `beSeattle` for `be Seattle`, `1temporarily` for `I temporarily`,
# a line-break hyphen written as `¬`. Against that, a vision transcription is simply
# better. This prompt flips the authority for those documents only.
VISION_SYS_TRUST = """You read one page of a book and transcribe it.

You also get the blocks a machine pulled from the PDF's text layer. That layer is NOT
reliable for this document — it was produced by OCR and is corrupted: letters swapped
for lookalikes, spaces dropped between words, line-break hyphens written as stray
glyphs. Use it only as a hint about layout and about words you cannot read. When your
reading and the layer disagree, YOUR READING WINS.

Transcribe the page body as printed, in reading order, split into blocks.

- Skip the running head, the running footer and the page number.
- Rejoin a word broken across a line break: `am-` + `bitious` is one word, `ambitious`.
- Rejoin a paragraph broken across a line break into one block. A block is a whole
  paragraph, not a line.
- If a paragraph starts on this page and does not finish, still emit what is here —
  the pipeline stitches page-crossing paragraphs afterwards.
- Do not correct spelling, do not modernise archaic forms, do not fix what looks like
  an author's deliberate misspelling. Fix only what is plainly OCR damage.
- If a passage is genuinely illegible write [?] rather than guessing.
- A title page or half-title is not a stack of headings. Emit the title as one block.

Block types: h1/h2/h3 (headings), p (body), quote (block quotation or epigraph),
figcaption, footnote, table_raw.

Output JSON only, no prose, no code fence:
{"text": "full page transcription",
 "columns": 1,
 "rebuild": [{"type":"h2","text":"..."},{"type":"p","text":"..."}],
 "notes": "one short line, or empty"}

`rebuild` is the page. Always return it, even when the layer looks fine."""


# ---------- local OCR ----------

def find_tesseract():
    try:
        import pytesseract  # noqa: F401
        return "pytesseract"
    except ImportError:
        pass
    return "cli" if shutil.which("tesseract") else None


def ocr_page(png: Path, backend: str, lang: str):
    """Return (text, [(x_center, y_top, word)])."""
    if backend == "pytesseract":
        import pytesseract
        from PIL import Image
        d = pytesseract.image_to_data(Image.open(png), lang=lang,
                                      output_type=pytesseract.Output.DICT)
        words, boxes = [], []
        for i, w in enumerate(d["text"]):
            w = w.strip()
            if not w or int(d["conf"][i]) < 40:
                continue
            words.append(w)
            boxes.append((d["left"][i] + d["width"][i] / 2, d["top"][i], w))
        return " ".join(words), boxes

    with tempfile.TemporaryDirectory() as td:
        base = Path(td) / "o"
        subprocess.run(["tesseract", str(png), str(base), "-l", lang, "tsv"],
                       check=True, capture_output=True)
        words, boxes = [], []
        for r in base.with_suffix(".tsv").read_text(encoding="utf-8").splitlines()[1:]:
            f = r.split("\t")
            if len(f) < 12 or not f[11].strip():
                continue
            try:
                if float(f[10]) < 40:
                    continue
            except ValueError:
                continue
            words.append(f[11].strip())
            boxes.append((int(f[6]) + int(f[8]) / 2, int(f[7]), f[11].strip()))
        return " ".join(words), boxes


def ocr_columns(boxes, page_width: float) -> int:
    if len(boxes) < 60:
        return 1
    xs = [b[0] for b in boxes]
    mid = page_width / 2
    left = sum(1 for x in xs if x < mid * 0.92)
    right = sum(1 for x in xs if x > mid * 1.08)
    gutter = sum(1 for x in xs if mid * 0.92 <= x <= mid * 1.08)
    if left > len(xs) * .3 and right > len(xs) * .3 and gutter < len(xs) * .08:
        return 2
    return 1


def order_looks_ok(boxes, page_width: float, layer_text: str) -> bool:
    if ocr_columns(boxes, page_width) != 2:
        return True
    mid = page_width / 2
    left = [w for x, y, w in sorted(boxes, key=lambda b: b[1]) if x < mid][:8]
    if len(left) < 6:
        return True
    return left[0].lower() in WORD_RE.findall(layer_text.lower())[:400]


# ---------- shared ----------

def tokens(text: str) -> Counter:
    return Counter(WORD_RE.findall(text.lower()))


def coverage(page_text: str, layer_text: str) -> tuple[float, int]:
    pt, lt = tokens(page_text), tokens(layer_text)
    total = sum(pt.values())
    if not total:
        return 1.0, 0
    return sum(min(c, lt[w]) for w, c in pt.items()) / total, total


def suffix_id(base: str, used: set[str]) -> str:
    for c in "abcdefghijklmnop":
        if base + c not in used:
            return base + c
    raise RuntimeError(f"too many insertions after {base}")


def rebuild_page(book: dict, page_blocks: list[dict], items: list[dict],
                 stats: Counter) -> bool:
    """Replace a page's blocks wholesale. Only for pages the model reports as
    unrepairable — interleaved columns inside a block, mainly.

    The replacement text comes from the model's reading, so the displaced text-layer
    text is archived under book["superseded"] rather than discarded: it is the only
    character-exact record of the page, and the reader-facing drawer needs to be able
    to say that this particular source text is a reading, not the original."""
    clean = [(i.get("type", "p"), re.sub(r"\s+", " ", (i.get("text") or "")).strip())
             for i in items]
    clean = [(t, x) for t, x in clean if len(x) >= 3 and "[?]" not in x]
    if not clean or not page_blocks:
        return False

    old_ids = [b["id"] for b in page_blocks]
    page = page_blocks[0]["page"]
    first = next(i for i, b in enumerate(book["blocks"]) if b["id"] == old_ids[0])

    # archive before deleting — nothing character-exact gets thrown away
    book.setdefault("superseded", {})[str(page)] = [
        {"id": b["id"], "type": b["type"], "src": b["src"]} for b in page_blocks]

    keep = set(old_ids)
    book["blocks"] = [b for b in book["blocks"] if b["id"] not in keep]

    used = {b["id"] for b in book["blocks"]}
    ids = []
    for k in range(len(clean)):
        if k < len(old_ids) and old_ids[k] not in used:
            ids.append(old_ids[k])
        else:
            ids.append(suffix_id(ids[-1] if ids else old_ids[0], used))
        used.add(ids[-1])

    fresh = [{"id": bid, "type": t, "page": page, "src": x, "ko": None,
              "translate": True, "from_ocr": True, "rebuilt": True}
             for bid, (t, x) in zip(ids, clean)]
    book["blocks"][first:first] = fresh
    stats["rebuilt"] += 1
    return True


def apply_fix(book: dict, page_blocks: list[dict], fix: dict, stats: Counter) -> None:
    if fix.get("rebuild") and rebuild_page(book, page_blocks, fix["rebuild"], stats):
        return

    by_id = {b["id"]: b for b in book["blocks"]}
    used = {b["id"] for b in book["blocks"]}
    ids = [b["id"] for b in page_blocks]
    known = set(ids)

    for bid, newtype in (fix.get("types") or {}).items():
        if bid in known and newtype in ("h1", "h2", "h3", "p", "quote",
                                        "figcaption", "footnote", "table_raw"):
            if by_id[bid]["type"] != newtype:
                by_id[bid]["type"] = newtype
                stats["types"] += 1

    for bid in (fix.get("drop") or []):
        if bid in known:
            by_id[bid]["translate"] = False
            by_id[bid]["dropped"] = True
            stats["dropped"] += 1

    order = [i for i in (fix.get("order") or []) if i in known]
    if order and len(order) == len(ids) and order != ids:
        pos = {b["id"]: i for i, b in enumerate(book["blocks"])}
        for slot, bid in zip(sorted(pos[i] for i in ids), order):
            book["blocks"][slot] = by_id[bid]
        stats["reordered"] += 1

    for item in (fix.get("missing") or []):
        text = re.sub(r"\s+", " ", (item.get("text") or "")).strip()
        if len(text) < 12 or "[?]" in text:
            continue
        page_text = " ".join(b["src"] for b in page_blocks).lower()
        probe = " ".join(WORD_RE.findall(text.lower())[:6])
        if probe and probe in page_text:
            continue  # already extracted; the model misread it as missing
        after = item.get("after")
        idx = next((i for i, b in enumerate(book["blocks"]) if b["id"] == after), None)
        if idx is None:
            idx = max((i for i, b in enumerate(book["blocks"]) if b["id"] in known),
                      default=None)
            if idx is None:
                continue
        new_id = suffix_id(book["blocks"][idx]["id"], used)
        used.add(new_id)
        book["blocks"].insert(idx + 1, {
            "id": new_id, "type": item.get("type", "p"),
            "page": book["blocks"][idx]["page"], "src": text,
            "ko": None, "translate": True, "from_ocr": True,
        })
        stats["inserted"] += 1


def read_with_vision(png: Path, pno: int, total: int, blocks: list[dict],
                     cache: L.Cache, model: str, trust: str = "layer") -> dict:
    listing = "\n".join(f"[{b['id']}] ({b['type']}) {b['src'][:400]}"
                        for b in blocks) or "(no blocks — the text layer is empty here)"
    # trust belongs in the key: the two modes ask different questions of the same page
    key = cache.key(listing, pno, model, "v2", trust)
    hit = cache.get(key)
    if hit is not None:
        return hit
    raw = L.call_vision(VISION_SYS_TRUST if trust == "vision" else VISION_SYS,
                        f"Page {pno} of {total}.\n\nExtracted blocks:\n{listing}",
                        png, max_tokens=4000, model=model)
    try:
        fix = json.loads(L.strip_fence(raw))
    except json.JSONDecodeError:
        fix = {"notes": "unparseable response"}
    cache.put(key, fix)
    return fix


def stitch_pages(book: dict, stats: Counter) -> None:
    """Merge paragraphs broken by a page break.

    Per-page repair cannot see across the seam, and a paragraph running over a page
    boundary is the single most common structural break in a book. The rule is
    deterministic and conservative: the earlier block must end mid-sentence and the
    later one starts the next page. The earlier block ending with no terminal
    punctuation at all is the load-bearing signal — requiring the continuation to
    start lowercase would miss every paragraph that breaks before a proper noun
    ("...a position at Harvard" / "University. My intention...").

    Body and quote are both accepted, because the type classifier is the least
    reliable thing in the extractor: a document whose last line on every page gets
    read as a quotation would otherwise lose every cross-page paragraph. A real
    block quotation almost never ends mid-sentence at a page break with body text
    resuming it, so the risk runs the other way. When the two disagree, body wins —
    a quote that flows into a paragraph was a paragraph all along."""
    BODY = ("p", "quote")
    blocks = book["blocks"]
    out: list[dict] = []
    for b in blocks:
        prev = out[-1] if out else None
        if (prev and prev["type"] in BODY and b["type"] in BODY
                and b["page"] == prev["page"] + 1
                and prev.get("translate", True) and b.get("translate", True)
                and not prev.get("ko") and not b.get("ko")
                and not re.search(r'[.!?…”"\')\]]\s*$', prev["src"])):
            joined = prev["src"].rstrip()
            nxt = b["src"].lstrip()
            prev["src"] = (joined[:-1] + nxt if joined.endswith("-")
                           else joined + " " + nxt)
            if prev["type"] != b["type"]:
                prev["type"] = "p"
            prev["stitched"] = True
            stats["stitched"] += 1
            continue
        out.append(b)
    book["blocks"] = out


def flag(cov: float, total: int, blocks: list, cols: int, threshold: float) -> list[str]:
    out = []
    if total >= 25 and cov < threshold:
        out.append(f"본문 누락 의심 (일치율 {cov:.0%})")
    if total >= 25 and not blocks:
        out.append("텍스트 레이어 없음 (이미지 페이지)")
    if cols > 1:
        out.append(f"{cols}단 조판")
    return out


# ---------- main ----------

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("book")
    ap.add_argument("--pdf", required=True)
    ap.add_argument("--engine", choices=["vision", "tesseract"], default="vision")
    ap.add_argument("--trust", choices=["layer", "vision"], default="layer",
                    help="who wins when the page image and the text layer disagree. "
                         "'layer' (default) keeps the PDF's own characters and takes "
                         "only structure from vision. 'vision' retypes every page from "
                         "the image — for documents whose text layer is itself OCR")
    ap.add_argument("--model", default=None,
                    help="vision model (default claude-haiku-4-5; $PKT_VISION_MODEL)")
    ap.add_argument("--workers", type=int, default=8, help="concurrent page reads")
    ap.add_argument("--dpi", type=int, default=150)
    ap.add_argument("--long-edge", type=int, default=1568,
                    help="max image edge sent to the model; beyond this you pay for pixels "
                         "that get downscaled away")
    ap.add_argument("--lang", default="eng", help="tesseract language (eng, eng+kor …)")
    ap.add_argument("--coverage", type=float, default=0.90,
                    help="page tokens that must appear in the text layer")
    ap.add_argument("--pages", help="limit to a range, e.g. 1-40")
    ap.add_argument("--max-vision", type=int, default=0,
                    help="tesseract engine: cap on follow-up vision calls (0 = no cap)")
    ap.add_argument("--keep-images", action="store_true")
    ap.add_argument("--keep-heading-levels", action="store_true",
                    help="leave h1/h2/h3 as read; by default they are flattened to h1 "
                         "(chapter openers) and h2 (everything else). Reading pages one "
                         "at a time gives the same kind of heading a different level "
                         "depending on the page, and the table of contents inherits it")
    args = ap.parse_args()

    book = L.load_book(args.book)
    work = L.work_dir(args.book)
    pages_dir = work / "pages"
    pages_dir.mkdir(exist_ok=True)
    cache = L.Cache(work, "pagecheck")
    model = args.model or L.VISION_MODEL

    doc = fitz.open(args.pdf)
    lo, hi = 1, len(doc)
    if args.pages:
        lo, hi = (int(x) for x in args.pages.split("-"))
        hi = min(hi, len(doc))
    page_nos = list(range(lo, hi + 1))

    by_page: dict[int, list[dict]] = defaultdict(list)
    for b in book["blocks"]:
        by_page[b["page"]].append(b)

    print(f"rasterizing pages {lo}-{hi} at {args.dpi} dpi")
    for pno in page_nos:
        png = pages_dir / f"p{pno:04d}.png"
        if png.exists():
            continue
        page = doc[pno - 1]
        zoom = args.dpi / 72
        long_px = max(page.rect.width, page.rect.height) * zoom
        if long_px > args.long_edge:
            zoom *= args.long_edge / long_px
        page.get_pixmap(matrix=fitz.Matrix(zoom, zoom)).save(png)

    findings: dict[int, dict] = {}
    stats = Counter()

    if args.engine == "vision":
        print(f"vision pass · {model} · {len(page_nos)} pages · {args.workers} workers · "
              f"trust={args.trust} · rough cost ${len(page_nos) * 0.0075:.2f}")
        if args.trust == "vision":
            print("  every page is retyped from the image; the text layer is archived "
                  "under superseded")

        def job(pno):
            return pno, read_with_vision(pages_dir / f"p{pno:04d}.png", pno, len(doc),
                                         by_page.get(pno, []), cache, model, args.trust)

        results = {}
        with ThreadPoolExecutor(max_workers=args.workers) as pool:
            for i, (pno, fix) in enumerate(pool.map(job, page_nos)):
                results[pno] = fix
                if (i + 1) % 20 == 0 or i + 1 == len(page_nos):
                    L.progress(i, len(page_nos), "pages read")

        for pno in page_nos:  # serial: block mutation must stay ordered
            fix = results[pno]
            blocks = by_page.get(pno, [])
            cov, total = coverage(fix.get("text", ""), " ".join(b["src"] for b in blocks))
            cols = fix.get("columns") or 1
            findings[pno] = {"page": pno, "coverage": cov, "columns": cols,
                             "blocks": len(blocks),
                             "reasons": flag(cov, total, blocks, cols, args.coverage),
                             "notes": fix.get("notes", "")}
            apply_fix(book, blocks, fix, stats)
        L.save_book(args.book, book)

    else:
        backend = find_tesseract()
        if backend is None:
            sys.exit("no tesseract.  pip install pytesseract pillow  + the binary,\n"
                     "  or use the default --engine vision (no local install needed)")
        print(f"tesseract pass · {backend} ({args.lang})")
        flagged = []
        for i, pno in enumerate(page_nos):
            blocks = by_page.get(pno, [])
            layer_text = " ".join(b["src"] for b in blocks)
            try:
                otext, boxes = ocr_page(pages_dir / f"p{pno:04d}.png", backend, args.lang)
            except Exception as e:
                otext, boxes = "", []
                print(f"  ! page {pno} OCR failed: {type(e).__name__}", file=sys.stderr)
            cov, total = coverage(otext, layer_text)
            width = doc[pno - 1].rect.width * (args.dpi / 72)
            cols = ocr_columns(boxes, width)
            reasons = flag(cov, total, blocks, cols, args.coverage)
            if cols == 2 and not order_looks_ok(boxes, width, layer_text):
                reasons.append("단 읽기 순서 뒤바뀜")
            findings[pno] = {"page": pno, "coverage": cov, "columns": cols,
                             "blocks": len(blocks), "reasons": reasons, "notes": ""}
            if reasons:
                flagged.append(pno)
            if (i + 1) % 25 == 0 or i + 1 == len(page_nos):
                L.progress(i, len(page_nos), "pages scanned")

        print(f"\nflagged {len(flagged)}/{len(page_nos)} pages")
        rank = sorted(flagged, key=lambda p: findings[p]["coverage"])
        if args.max_vision:
            rank = rank[:args.max_vision]
        rank.sort()
        if rank:
            print(f"vision repair on {len(rank)} page(s) · {model}")
            for i, pno in enumerate(rank):
                fix = read_with_vision(pages_dir / f"p{pno:04d}.png", pno, len(doc),
                                       by_page.get(pno, []), cache, model)
                findings[pno]["notes"] = fix.get("notes", "")
                apply_fix(book, by_page.get(pno, []), fix, stats)
                L.progress(i, len(rank), f"page {pno}")
            L.save_book(args.book, book)

    stitch_pages(book, stats)
    # 재구성으로 레벨이 다시 흩어지므로 마지막에 한 번 더 고른다
    if not args.keep_heading_levels:
        stats["heading_levels"] = normalize_headings(book["blocks"])
    L.save_book(args.book, book)

    (work / "blocks.txt").write_text(
        "".join(f"{' ' if b['translate'] else '-'}[{b['id']}] ({b['type']:10}) "
                f"p{b['page']:>3}  {b['src'][:120]}\n" for b in book["blocks"]),
        encoding="utf-8")

    low = [f for f in findings.values() if f["coverage"] < args.coverage and f["blocks"]]
    lines = ["# 페이지 검증 리포트", "",
             f"페이지 {len(page_nos)} · 블록 {len(book['blocks'])} · 엔진 `{args.engine}`"
             + (f" ({model})" if args.engine == "vision" else ""),
             f"유형 수정 {stats['types']} · 순서 교정 {stats['reordered']} · "
             f"누락 삽입 {stats['inserted']} · 제외 {stats['dropped']} · "
             f"페이지 재구성 {stats['rebuilt']} · 페이지 넘김 단락 병합 {stats['stitched']} · "
             f"제목 레벨 정규화 {stats['heading_levels']}", "",
             "삽입 블록은 `from_ocr: true`, ID는 접미사(b0042a) 형태다. "
             "판독 텍스트는 대조용으로만 쓰이며 기존 블록 내용을 덮어쓰지 않는다.", "",
             "## 이상 페이지", "",
             "| 쪽 | 일치율 | 단 | 블록 | 사유 | 판독 메모 |",
             "|---|---|---|---|---|---|"]
    rows = 0
    for pno in page_nos:
        f = findings.get(pno)
        if not f or (not f["reasons"] and not f["notes"]):
            continue
        rows += 1
        lines.append(f"| {f['page']} | {f['coverage']:.0%} | {f['columns']} | {f['blocks']} "
                     f"| {'; '.join(f['reasons']) or '-'} | {f['notes'] or '-'} |")
    if not rows:
        lines.append("| — | — | — | — | 이상 없음 | — |")

    lines += ["", "## 판단", "",
              f"- 일치율 {args.coverage:.0%} 미만 페이지: {len(low)}",
              "- 일치율이 전 페이지에서 고르게 낮으면 개별 페이지 문제가 아니라 텍스트 레이어가 "
              "부실한 것이다. `ocrmypdf --redo-ocr` 로 다시 만들고 extract부터 다시 돌려라.",
              "- 삽입 블록(`from_ocr: true`)은 판독 텍스트라 원본보다 부정확하다. blocks.txt에서 "
              "따로 확인하라.",
              "- 방언·의도적 오기가 있는 소설이라면 삽입 블록을 특히 의심하라. 판독 모델은 그런 "
              "표기를 조용히 표준형으로 고친다.",
              "- 재구성된 페이지는 전 블록이 판독 텍스트다(`rebuilt: true`). 2단이 블록 내부에서 "
              "뒤섞여 블록 단위 교정으로는 못 고치는 경우에만 발생한다. 수가 많으면 extract의 단 "
              "판별이 실패한 것이므로 `--para-gap` 조정 후 extract부터 다시 돌리는 쪽이 낫다.",
              "- 밀려난 텍스트 레이어 원문은 `book.json`의 `superseded`에 페이지별로 보관된다. "
              "지워지지 않으니 필요하면 대조하라."]

    (work / "pagecheck-report.md").write_text("\n".join(lines), encoding="utf-8")

    if not args.keep_images:
        for p in pages_dir.glob("*.png"):
            p.unlink()
        if not any(pages_dir.iterdir()):
            pages_dir.rmdir()

    print(f"\n유형 {stats['types']} · 순서 {stats['reordered']} · "
          f"삽입 {stats['inserted']} · 제외 {stats['dropped']} · 재구성 {stats['rebuilt']} · "
          f"페이지 병합 {stats['stitched']} · 제목 레벨 {stats['heading_levels']}")
    print(f"-> {work/'pagecheck-report.md'}")
    print(">> 구조를 고칠 수 있는 마지막 단계다. ID는 이제부터 불변이다.")


if __name__ == "__main__":
    main()
