#!/usr/bin/env python3
"""`.parallax` -> book.json, so a document worked on in the app can go back
through the CLI pipeline (batch-translate the rest, re-run deslop, export again).

    python scripts/parallax_import.py out/book.parallax --out work/book.json

The round trip is lossless for everything the pipeline uses: block IDs, order,
both languages, pre-deslop text, flags, glossary and the superseded archive.
Reading progress and row-height caches are app-only and are dropped.
"""
from __future__ import annotations

import argparse
import json
import sqlite3
from pathlib import Path

import _parallax as PX


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("parallax")
    ap.add_argument("--out", default="work/book.json")
    args = ap.parse_args()

    con = sqlite3.connect(args.parallax)
    con.row_factory = sqlite3.Row

    d = con.execute("SELECT * FROM doc LIMIT 1").fetchone()
    if d is None:
        raise SystemExit("no doc row — not a .parallax file?")

    blocks = []
    for r in con.execute("SELECT * FROM block ORDER BY ord"):
        f = r["flags"] or 0
        b = {
            "id": r["id"],
            "type": r["type"],
            "page": r["page"],
            "src": r["src"],
            "ko": r["ko"],
            "translate": not (f & PX.NO_TRANSLATE),
        }
        if r["ko_raw"]:
            b["ko_raw"] = r["ko_raw"]
        for bit, key in ((PX.FROM_OCR, "from_ocr"), (PX.REBUILT, "rebuilt"),
                         (PX.STITCHED, "stitched"), (PX.NEEDS_REVIEW, "needs_review"),
                         (PX.DROPPED, "dropped")):
            if f & bit:
                b[key] = True
        blocks.append(b)

    book = {
        "meta": {
            "source": d["source_path"],
            "title": d["title"],
            "author": d["author"],
            "pages": d["pages"],
            "register": "essay",
        },
        "blocks": blocks,
    }
    if d["title_ko"]:
        book["meta"]["title_ko"] = d["title_ko"]

    sup = {str(r["page"]): json.loads(r["payload"])
           for r in con.execute("SELECT * FROM superseded")}
    if sup:
        book["superseded"] = sup

    # page=0 은 요약, 나머지는 쪽별 행(export.py 의 역방향). notes 는 이미 합쳐진
    # 문자열이라 reasons 로 되가르지 않고 그대로 둔다.
    pc_rows = list(con.execute("SELECT * FROM page_check ORDER BY page"))
    if pc_rows:
        book["page_check"] = {
            "summary": next((r["notes"] for r in pc_rows if r["page"] == 0), ""),
            "pages": [{"page": r["page"], "coverage": r["coverage"],
                       "columns": r["columns"], "notes": r["notes"] or ""}
                      for r in pc_rows if r["page"] != 0],
        }

    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(book, ensure_ascii=False, indent=1), encoding="utf-8")

    terms, keep = {}, []
    for r in con.execute("SELECT * FROM glossary"):
        (keep.append(r["en"]) if r["kind"] == "keep_original"
         else terms.update({r["en"]: r["ko"]}))
    if terms or keep:
        (out.parent / "glossary.json").write_text(json.dumps(
            {"title_ko": d["title_ko"] or "", "terms": terms,
             "keep_original": keep, "characters": []},
            ensure_ascii=False, indent=1), encoding="utf-8")

    con.close()
    done = sum(1 for b in blocks if (b.get("ko") or "").strip())
    print(f"{out}  ({len(blocks)} blocks · 번역 {done}/{len(blocks)})")
    if terms or keep:
        print(f"{out.parent / 'glossary.json'}  (용어 {len(terms)} · 원문유지 {len(keep)})")


if __name__ == "__main__":
    main()
