#!/usr/bin/env bash
# Full pipeline.  Usage:  bash scripts/run.sh book.pdf [register]
#   ENGINE=tesseract bash scripts/run.sh book.pdf fiction   # local OCR instead of vision
# Every stage is resumable — rerun this after a crash and cached chunks are skipped.
# The output is out/book.parallax. Reading it is the Parallax app's job, not ours.
set -euo pipefail

PDF="${1:?usage: run.sh book.pdf [literal|fiction|essay|business]}"
REG="${2:-essay}"
HERE="$(cd "$(dirname "$0")" && pwd)"
WORK="work"
OUT="out"

: "${ANTHROPIC_API_KEY:?set ANTHROPIC_API_KEY}"

step () { printf '\n\033[1m── %s\033[0m\n' "$1"; }
pause_for_human () {
  printf '\n>> %s\n   Enter to continue, Ctrl-C to stop: ' "$1"
  read -r _
}

step "1/7  extract"
[ -f "$WORK/book.json" ] || python3 "$HERE/extract.py" "$PDF" --out "$WORK/book.json"

step "2/7  pagecheck  (per-page read + structure repair)"
python3 "$HERE/pagecheck.py" "$WORK/book.json" --pdf "$PDF" --engine "${ENGINE:-vision}"
pause_for_human "Read $WORK/pagecheck-report.md, then $WORK/blocks.txt. Last chance to fix structure."

step "3/7  glossary"
FICTION=""
[ "$REG" = "fiction" ] && FICTION="--fiction"
python3 "$HERE/glossary.py" "$WORK/book.json" $FICTION
pause_for_human "Edit $WORK/glossary.json — established renderings, ambiguous terms, character relations."

step "4/7  translate  ($REG)"
python3 "$HERE/translate.py" "$WORK/book.json" --register "$REG"
pause_for_human "Read a few paragraphs. Wrong register is cheapest to fix now."

step "5/7  deslop"
python3 "$HERE/deslop.py" "$WORK/book.json"

step "6/7  verify"
python3 "$HERE/verify.py" "$WORK/book.json" || {
  echo
  echo "!! verify found problems — see $WORK/verify-report.md"
  pause_for_human "Export anyway?"
}

step "7/7  export  (.parallax)"
python3 "$HERE/export.py" "$WORK/book.json" --out "$OUT"

printf '\n\033[1mdone\033[0m  ->  %s/book.parallax   (open it in Parallax)\n' "$OUT"
