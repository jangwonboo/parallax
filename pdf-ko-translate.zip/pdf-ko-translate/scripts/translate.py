#!/usr/bin/env python3
"""Translate blocks EN -> KO under a fixed register. Chunked, cached, resumable.

    python scripts/translate.py work/book.json --register essay
    python scripts/translate.py work/book.json --register fiction --limit 30   # style probe
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import _llm as L

REGISTERS = {
    "literal": {
        "label": "직역",
        "axes": [
            "종결어미: -다 평서형",
            "문장 분할: 원문 유지 — 영어 문장 하나에 한국어 문장 하나. 세미콜론·콜론 구조도 최대한 살려라.",
            "어휘: 원어 근접. 학술 용어는 관용역이 있어도 원어를 괄호 병기하라.",
            "대명사: 명시. he/she/it/they를 생략하지 마라.",
            "고유명사: 음차하고 첫 등장 시 원문을 괄호 병기하라 — 에이해브(Ahab)",
        ],
        "extra": ["원문의 어순과 구조를 최대한 보존하라. 읽는 맛보다 대응 관계가 우선이다."],
    },
    "fiction": {
        "label": "소설",
        "axes": [
            "종결어미: -다 평서형 (서술). 대사는 인물관계표를 따른다.",
            "문장 분할: 적극 — 관계절·분사구문이 겹친 영어 장문은 반드시 끊어라. "
            "한국어 문장이 60자를 넘으면 끊을 자리를 찾아라.",
            "어휘: 고유어 우선. 한자어보다 순우리말 동사·형용사를 골라라.",
            "대명사: 대폭 생략 — 문맥으로 주어가 복원되면 쓰지 마라. "
            "인물이 명확하면 he said는 '말했다'로 충분하다.",
            "고유명사: 음차, 원문 병기 없음. 지명은 관용역 우선.",
        ],
        "extra": [
            "대사는 인물의 말투를 유지하라. 교육 수준·나이·시대·관계가 말투에 드러나야 하고 챕터가 바뀌어도 같아야 한다.",
            "he said / she replied 같은 지시문은 한국어에서 반복이 거슬린다. 필요할 때만 남겨라.",
            "원문 문단의 첫 문장이 짧고 강하면 한국어도 짧고 강하게. 리듬은 의미의 일부다.",
        ],
    },
    "essay": {
        "label": "에세이",
        "axes": [
            "종결어미: -다 평서형",
            "문장 분할: 중간 — 장문은 끊되 논리 연결이 끊기면 유지하라.",
            "어휘: 균형. 개념어는 한자어, 서술은 고유어.",
            "대명사: 생략. 단 지시 대상이 모호해지면 명시하라.",
            "고유명사: 음차. 인명은 첫 등장 시 원문 괄호 병기.",
        ],
        "extra": [
            "저자의 1인칭은 필요할 때만 쓴다. I argue that은 주어 없이 '~라고 본다'가 자연스럽다.",
            "수사적 질문·도치·삽입구 같은 저자의 문체 장치는 살려라.",
        ],
    },
    "business": {
        "label": "비즈니스",
        "axes": [
            "종결어미: -다 평서형",
            "문장 분할: 적극 — 한 문장 한 메시지.",
            "어휘: 한자어 우선. 업계 표준 용어를 쓰되, 원어가 이미 표준이면(프레임워크, 레버리지) 억지로 번역하지 마라.",
            "대명사: 생략",
            "고유명사: 기업명·제품명·지수명은 원문 그대로 두고 음차하지 마라.",
        ],
        "extra": [
            "불릿·번호 목록은 병렬 구조를 살리고 항목 끝을 통일하라(전부 명사형 또는 전부 서술형).",
            "수치·단위·연도는 절대 손대지 마라.",
            "원문이 결론을 뒤에 두더라도 문장 순서를 바꾸지 마라. 구조 재배열은 번역이 아니다.",
        ],
    },
}

BASE = """당신은 영한 문학·비문헌 번역자다. 아래 블록들을 한국어로 옮긴다.

[절대 규칙]
1. 출력은 입력과 같은 블록 수, 같은 ID, 같은 순서다. 블록을 합치거나 나누거나 빠뜨리지 마라.
2. 각 줄은 정확히 `[ID] 번역문` 형식이다. 다른 말은 한 글자도 쓰지 마라.
3. 한 블록의 번역은 반드시 한 줄이다. 블록 안에서 문장을 몇 개로 나누든 자유지만 줄바꿈은 넣지 마라.
4. 숫자·연도·단위·통화·퍼센트는 원문 그대로.
5. [^3] 각주 마커, **강조**, *이탤릭* 마크업은 위치를 지켜라.
6. 원문에 없는 설명·부연·역주를 만들지 마라. 모르면 음차하고 넘어가라.
7. 용어집의 역어를 어기지 마라.
"""


def build_system(register: str, glossary: dict, polite: bool) -> str:
    r = REGISTERS[register]
    axes = list(r["axes"])
    if polite and register == "business":
        axes[0] = "종결어미: -습니다 경어체"

    parts = [BASE, f"\n[문체 사양 — {r['label']}]", *(f"- {a}" for a in axes)]
    if r["extra"]:
        parts += ["\n[추가 지시]", *(f"- {e}" for e in r["extra"])]

    terms = glossary.get("terms") or {}
    if terms:
        parts.append("\n[용어집 — 반드시 이 역어를 쓴다]")
        parts.append(" · ".join(f"{k} → {v}" for k, v in list(terms.items())[:250]))
    keep = glossary.get("keep_original") or []
    if keep:
        parts.append("\n[원문 유지 — 번역하지 않는다]")
        parts.append(" · ".join(keep))

    chars = glossary.get("characters") or []
    if chars and register == "fiction":
        parts.append("\n[인물관계표 — 대사의 존대·말투는 여기가 정답이다]")
        for c in chars:
            addr = ", ".join(f"{k}에게 {v}" for k, v in (c.get("addresses") or {}).items())
            parts.append(f"- {c.get('en')} = {c.get('ko')} ({c.get('role','')}) "
                         f"| 말투: {c.get('speech','')}" + (f" | {addr}" if addr else ""))

    parts.append("\n[블록 타입]\nh1/h2/h3 = 제목 · p = 단락 · quote = 인용 · "
                 "figcaption = 그림 설명 · footnote = 각주. 제목은 짧고 명사형으로.")
    return "\n".join(parts)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("book")
    ap.add_argument("--register", required=True, choices=list(REGISTERS))
    ap.add_argument("--polite", action="store_true", help="business register: -습니다")
    ap.add_argument("--chunk-chars", type=int, default=6000)
    ap.add_argument("--limit", type=int, help="translate only the first N blocks (style probe)")
    ap.add_argument("--range", help="block id range, e.g. b0120-b0240")
    ap.add_argument("--force", action="store_true", help="ignore cache and existing translations")
    args = ap.parse_args()

    book = L.load_book(args.book)
    work = L.work_dir(args.book)

    gpath = work / "glossary.json"
    if not gpath.exists():
        print("! no glossary.json — run glossary.py first for consistent names/terms")
        glossary = {}
    else:
        glossary = json.loads(gpath.read_text(encoding="utf-8"))
        if args.register == "fiction" and not glossary.get("characters"):
            raise SystemExit("fiction register needs a character sheet: "
                             "python scripts/glossary.py work/book.json --fiction")

    blocks = L.translatable(book)
    if args.range:
        lo, hi = args.range.split("-")
        blocks = [b for b in blocks if lo <= b["id"] <= hi]
    if args.limit:
        blocks = blocks[:args.limit]

    system = build_system(args.register, glossary, args.polite)
    (work / "translate-system.txt").write_text(system, encoding="utf-8")

    cache = L.Cache(work, "translate")
    chunks = L.chunk_blocks(blocks, args.chunk_chars)
    print(f"{len(blocks)} blocks · {len(chunks)} chunks · register={args.register}")

    by_id = {b["id"]: b for b in book["blocks"]}
    prev_tail = ""
    done = 0

    for i, chunk in enumerate(chunks):
        wire = L.to_wire(chunk, "src")
        key = cache.key(wire, args.register, args.polite, L.MODEL, "v1")
        hit = None if args.force else cache.get(key)

        if hit is None and not args.force and all(by_id[b["id"]].get("ko") for b in chunk):
            prev_tail = "\n".join(f"{b['src']}\n→ {by_id[b['id']]['ko']}" for b in chunk[-2:])
            L.progress(i, len(chunks), "already translated")
            continue

        if hit is None:
            user = wire
            if prev_tail:
                user = ("[직전 문맥 — 참고만 하고 번역하지 마라]\n" + prev_tail +
                        "\n\n[번역 대상]\n" + wire)
            got = L.call_preserving_ids(system, user, [b["id"] for b in chunk],
                                        max_tokens=min(16000, len(wire) * 2 + 2000))
            cache.put(key, got)
        else:
            got = hit

        for b in chunk:
            if got.get(b["id"]):
                ko = got[b["id"]]
                # 시스템 프롬프트의 블록 타입 설명을 보고 모델이 이따금 타입
                # 토큰을 번역 앞에 흘린다. 자기 블록의 타입과 일치할 때만 벗긴다.
                tok = str(b.get("type", "")) + " "
                if len(tok) > 1 and ko.startswith(tok):
                    ko = ko[len(tok):].strip()
                by_id[b["id"]]["ko"] = ko
                done += 1

        prev_tail = "\n".join(f"{b['src']}\n→ {by_id[b['id']].get('ko','')}" for b in chunk[-2:])
        L.progress(i, len(chunks), "cached" if hit else "translated")
        L.save_book(args.book, book)  # save every chunk so a crash loses nothing

    book["meta"]["register"] = args.register
    L.save_book(args.book, book)

    missing = [b["id"] for b in blocks if not by_id[b["id"]].get("ko")]
    print(f"\ntranslated {done} blocks")
    if missing:
        print(f"! {len(missing)} still empty: {missing[:12]}{' …' if len(missing) > 12 else ''}")
    print(">> Read a few paragraphs before running deslop. Wrong register is cheapest to fix now.")


if __name__ == "__main__":
    main()
