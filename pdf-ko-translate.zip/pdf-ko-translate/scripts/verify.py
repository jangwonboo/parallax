#!/usr/bin/env python3
"""Mechanical QA. Silent paragraph drops and number errors are invisible on reading.

    python scripts/verify.py work/book.json
"""
from __future__ import annotations

import argparse
import json
import re
import statistics
from collections import Counter
from pathlib import Path

import _llm as L

NUM_RE = re.compile(r"\d[\d,.]*\s*%?")
HANGUL = re.compile(r"[\uac00-\ud7a3]")
# 42,000 -> "4만 2천" is correct Korean; don't flag digits that were spelled out this way
KO_NUMERAL = re.compile(r"[일이삼사오육칠팔구십백천만억조]")
ENDINGS = ("습니다", "합니다", "입니다", "이다", "했다", "한다", "된다", "였다", "있다", "없다")


def numbers(text: str) -> Counter:
    out = Counter()
    for m in NUM_RE.finditer(text):
        t = m.group(0).replace(",", "").replace(" ", "").rstrip(".")
        if t:
            out[t] += 1
    return out


def ending_profile(texts: list[str]) -> dict:
    c = Counter()
    for t in texts:
        for sent in re.split(r"[.!?…]\s*", t):
            sent = sent.strip()
            if not sent:
                continue
            for e in ENDINGS:
                if sent.endswith(e) or sent.endswith(e + "."):
                    c[e] += 1
                    break
    total = sum(c.values()) or 1
    return {k: v / total for k, v in c.most_common(6)}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("book")
    ap.add_argument("--ratio-low", type=float, default=0.35)
    ap.add_argument("--ratio-high", type=float, default=1.60)
    args = ap.parse_args()

    book = L.load_book(args.book)
    work = L.work_dir(args.book)
    blocks = L.translatable(book)

    gpath = work / "glossary.json"
    glossary = json.loads(gpath.read_text(encoding="utf-8")) if gpath.exists() else {}
    terms = glossary.get("terms") or {}

    missing, notko, numbad, ratiobad, termbad, review = [], [], [], [], [], []
    ratios = []

    for b in blocks:
        ko = (b.get("ko") or "").strip()
        if not ko:
            missing.append(b["id"])
            continue
        if b.get("needs_review"):
            review.append(b["id"])
        if len(ko) > 20 and not HANGUL.search(ko):
            notko.append(b["id"])

        src_n, ko_n = numbers(b["src"]), numbers(ko)
        lost = [n for n in src_n if ko_n[n] < src_n[n] and len(n) > 1]
        if lost and KO_NUMERAL.search(ko):
            # digits may have been spelled out (42,000 -> 4만 2천); keep only the
            # ones whose leading digits are absent from the Korean entirely
            lost = [n for n in lost if n.lstrip("0")[:1] and n.lstrip("0")[:1] not in ko]
        if lost:
            numbad.append((b["id"], lost[:5]))

        r = len(ko) / max(len(b["src"]), 1)
        ratios.append(r)
        if len(b["src"]) > 120 and not (args.ratio_low <= r <= args.ratio_high):
            ratiobad.append((b["id"], round(r, 2)))

    for en, ko_term in terms.items():
        if not ko_term or ko_term == en:
            continue
        hits = [b for b in blocks if b.get("ko") and re.search(rf"\b{re.escape(en)}\b", b["src"])]
        if len(hits) < 3:
            continue
        used = sum(1 for b in hits if ko_term in b["ko"] or en in b["ko"])
        if used / len(hits) < 0.6:
            termbad.append((en, ko_term, f"{used}/{len(hits)}"))

    ordered = [b for b in blocks if b.get("ko")]
    n = max(len(ordered) // 5, 1)
    head, tail = ordered[:n], ordered[-n:]
    head_len = statistics.median(len(b["ko"]) for b in head) if head else 0
    tail_len = statistics.median(len(b["ko"]) for b in tail) if tail else 0
    head_end = ending_profile([b["ko"] for b in head])
    tail_end = ending_profile([b["ko"] for b in tail])

    def block_list(items, fmt=lambda x: f"`{x}`"):
        return "\n".join(f"- {fmt(i)}" for i in items[:60]) or "- 없음"

    report = [
        f"# 검증 리포트 — {book['meta'].get('title','')}",
        "",
        f"번역 대상 블록 {len(blocks)} · 완료 {len(blocks)-len(missing)} · "
        f"register `{book['meta'].get('register')}`",
        f"평균 길이 비율(한/영) {statistics.mean(ratios):.2f}" if ratios else "",
        "",
        f"## 1. 누락 — {len(missing)}",
        "번역이 비어 있는 블록. 있으면 translate.py를 다시 돌려라.",
        block_list(missing),
        "",
        f"## 2. 한글 없음 — {len(notko)}",
        "영어가 그대로 남았을 가능성.",
        block_list(notko),
        "",
        f"## 3. 숫자 누락 — {len(numbad)}",
        "원문에 있는 수치가 번역에서 사라짐. 사람이 직접 확인할 것.",
        block_list(numbad, lambda x: f"`{x[0]}` — {', '.join(x[1])}"),
        "",
        f"## 4. 길이 비율 이상 — {len(ratiobad)}",
        f"정상 범위 {args.ratio_low}–{args.ratio_high} 밖. 낮으면 축약·누락, 높으면 군더더기.",
        block_list(ratiobad, lambda x: f"`{x[0]}` — {x[1]}"),
        "",
        f"## 5. 용어집 불이행 — {len(termbad)}",
        "확정 역어가 실제로 쓰이지 않은 용어.",
        block_list(termbad, lambda x: f"{x[0]} → {x[1]} (적용 {x[2]})"),
        "",
        f"## 6. deslop 보류 — {len(review)}",
        "변경률 초과로 손대지 않은 블록.",
        block_list(review),
        "",
        "## 7. 후반 드리프트",
        f"- 중앙 블록 길이: 앞 20% {head_len:.0f}자 → 뒤 20% {tail_len:.0f}자",
        f"- 앞 20% 종결어미: {head_end}",
        f"- 뒤 20% 종결어미: {tail_end}",
        "",
        "길이가 30% 이상 벌어지거나 종결어미 분포가 크게 다르면 후반 문체가 흐려진 것이다.",
        "해당 구간만 `translate.py --range bXXXX-bYYYY --force` 로 다시 돌려라.",
    ]

    out = work / "verify-report.md"
    out.write_text("\n".join(report), encoding="utf-8")

    total = len(missing) + len(notko) + len(numbad) + len(termbad)
    print(f"누락 {len(missing)} · 한글없음 {len(notko)} · 숫자 {len(numbad)} · "
          f"길이이상 {len(ratiobad)} · 용어집 {len(termbad)} · 보류 {len(review)}")
    print(f"-> {out}")
    if total:
        print("\n!! 경고가 남아 있다. 해결하고 export 하라.")
        raise SystemExit(1)
    print("\nclean.")


if __name__ == "__main__":
    main()
