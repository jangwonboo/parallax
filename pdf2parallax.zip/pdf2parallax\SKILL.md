---
name: pdf2parallax
description: Turn an English PDF into a Korean working file for the Parallax reader. Recovers document structure from the PDF (headings, paragraphs, running heads, paragraphs broken across page breaks), optionally cross-checks every page with a vision model, then translates into Korean with a selectable register (직역 / 소설 / 에세이 / 비즈니스 / 뉴닉 / 개조식), de-slops the Korean and verifies nothing was dropped. Emits `.parallax`; it does not render a reading copy — the Parallax desktop app does that. Trigger on "PDF 번역해줘", "이 책 한글로", "영문 PDF 추출", "translate this PDF to Korean", or any request to turn an English document into a Korean reading copy. Runs as a resumable batch pipeline, not inside the chat session.
license: MIT
---

# PDF → 한국어 작업 파일

영문 PDF 한 권을 Parallax 리더가 여는 `.parallax` 작업 파일로 바꾸는 7단계 파이프라인. 각 단계는 `book.json` 하나를 읽고 고쳐 쓴다. 모든 단계는 청크 단위 캐시를 쓰므로 중단 후 재개해도 이미 끝난 부분은 다시 호출하지 않는다.

```
extract → pagecheck → glossary → translate → deslop → verify → export
  ①          ②           ③          ④          ⑤        ⑥        ⑦
```

**읽는 화면은 여기 없다.** 예전에는 마지막 단계가 `book.md`와 자체 툴바·목차·사전 팝업을 가진 단일 파일 `book.html`을 냈다. 그 조판이 전부 Parallax 데스크톱 앱으로 옮겨갔고, 같은 조판을 두 벌 유지하면 반드시 어긋난다. 이 스킬은 문서를 뽑아 번역해 `.parallax`로 넘기는 데까지만 한다.

## 핵심 계약: 단락 단위 앵커

**pagecheck 이후 블록 ID는 불변이다.** 추출이 문서를 블록(제목·단락·인용·각주)으로 쪼개 `b0001`부터 ID를 매기고, pagecheck가 페이지 이미지와 대조해 구조를 고친다. 구조를 바꿀 수 있는 건 여기까지다. 이후 어떤 단계도 블록을 만들거나 없애거나 합치거나 순서를 바꾸지 않는다. 채워 넣기만 한다.

문장 분할은 자유다. 영어 장문 하나를 한국어 세 문장으로 쪼개도 되고, 짧은 두 문장을 붙여도 된다. 단 그 결과가 **같은 블록 안에** 머물러야 한다. 이 계약이 지켜지는 한 앱의 좌우 대역은 항상 같은 줄에 정렬된다.

이걸 어기면 나머지가 전부 무너진다. 프롬프트에서 반복해 강조하고, `verify`가 기계적으로 검사한다.

## 설치

```bash
unzip pdf2parallax.zip -d ~/.claude/skills/
pip install -r ~/.claude/skills/pdf2parallax/requirements.txt
```

`~/.claude/skills/` 에 두면 이후 어떤 세션에서든 자동으로 잡힌다. 프로젝트 단위로 쓰려면 저장소의 `.claude/skills/` 에 넣고 커밋한다.

## 실행

```bash
pip install -r requirements.txt
export ANTHROPIC_API_KEY=...        # 또는 아래 `.env`

python scripts/extract.py   book.pdf --out work/book.json
python scripts/pagecheck.py work/book.json --pdf book.pdf     # 페이지별 판독 대조·구조 교정
python scripts/glossary.py  work/book.json                    # 인명·용어·인물관계 확정
python scripts/translate.py work/book.json --register essay   # literal 직역 / fiction 소설 / essay 에세이 /
                                                              # business 비즈니스 / newneek 뉴닉 / nominal 개조식
python scripts/deslop.py    work/book.json                    # nominal 은 스스로 빠진다
python scripts/verify.py    work/book.json                    # 누락·숫자·고유명사 검사
python scripts/export.py    work/book.json --out out/         # -> out/book.parallax
```

또는 `bash scripts/run.sh book.pdf essay` 로 한 번에.

### API 키 — `.env` 도 읽는다

밤새 도는 배치를 창을 옮겨 가며 재개하는데 키가 셸에만 있으면 그때마다 다시 export 해야 한다. 첫 API 호출 직전에 `.env` 를 한 번 읽는다. **이미 있는 환경변수가 언제나 이긴다** — 파일은 기본값이지 권위가 아니다.

찾는 순서는 `$PKT_ENV_FILE` → 현재 디렉터리에서 위로 → 스킬 루트 → `~/.env`. 형식은 느슨하게 받는다(`export` 접두사, 등호 둘레 공백, 따옴표, BOM, 줄바꿈 없는 끝). 못 찾으면 어디를 봤는지 적어 준다.

```bash
PKT_ENV_FILE=/path/to/.env python scripts/translate.py work/book.json
```

작업 폴더와 저장소가 다른 드라이브에 있으면 위로 훑어도 못 만나므로 `PKT_ENV_FILE` 을 쓰는 게 확실하다. **`.env` 는 반드시 `.gitignore` 에 넣어라.**

각 단계는 독립적으로 다시 돌릴 수 있다. 문체가 마음에 안 들면 `translate.py --register fiction --force` 로 4단계부터 다시.

## 단계별 요점

### ① extract — PDF에서 구조 복원
PDF에는 장·절·단락 개념이 없다. 폰트 크기·굵기와 PDF outline(북마크)으로 heading을 추론하고, 하이픈 줄바꿈을 복원하고, 머리글·꼬리글·쪽번호를 걷어낸다. 자세한 규칙과 흔한 실패는 [`references/structure.md`](references/structure.md).

**머리글 판정은 규칙이지 비전이 아니다.** 페이지 높이의 위·아래 8% 안에 온전히 들어가는 줄만 후보로 본다. "첫 두 줄"로 잡으면 드롭캡이나 제사(題詞)가 밀어낸 머리글을 놓치고, 짧은 페이지에서는 본문 첫 줄을 머리글로 몬다. 후보 중 숫자를 `#`으로 지운 텍스트가 **서로 다른 3쪽 이상(또는 전체의 5% 이상)** 에서 반복되면 머리글이다. 책은 짝수쪽에만 머리글을 넣거나 장 시작·전면 도판에서는 빼므로, 전체의 20% 남짓에만 나타나는 게 정상이다 — 임계값을 25%로 잡았더니 191쪽 중 37쪽에 있던 머리글이 살아남아 `classify()`가 전부 heading으로 읽었고 목차가 책 제목 37개로 도배됐다. PDF outline에 있는 제목은 절대 지우지 않는다. 장 제목은 원래 첫 페이지 맨 위에 있다.

**페이지를 넘나드는 단락은 여기서 붙인다.** `merge_paragraphs()`는 한 페이지씩 보므로 페이지 경계를 넘는 단락은 항상 두 블록으로 갈린다. 예전에는 `pagecheck.py`가 이걸 붙였는데, pagecheck는 쪽당 비전 호출이라 대개 돌리지 않고 넘어간다. 규칙은 결정론적이라 모델이 필요 없다 — 자세한 근거는 `stitch_blocks()` 주석과 [`references/decisions.md`](references/decisions.md) C.

OCR로 만든 텍스트 레이어는 분철 하이픈을 `¬`(U+00AC)나 soft hyphen으로 쓴다. `am¬ bitious`가 그대로 남으면 번역기에 조각난 단어가 들어가므로 함께 복원한다.

**제목 레벨은 책이 스스로 적어 둔 목차를 정답지로 삼아 다시 고른다.** 폰트 크기 추론은 쪽마다 조판이 조금씩 달라 흔들리고, `pagecheck`는 한 페이지씩 따로 읽으므로 같은 장 제목이 어느 쪽에 실렸느냐에 따라 다른 레벨을 받는다 — 실제로 한 책에서 `CHAPTER 1`이 h3, `CHAPTER 2`가 h2, `CHAPTER 3`이 h3으로 나왔다.

거의 모든 단행본은 앞머리에 Contents를 싣고, 거기엔 판독기가 알 수 없는 것 둘이 들어 있다 — **어느 제목이 장이고 어느 것이 그 아래인지**, 그리고 **무엇이 애초에 제목인지**. `harvest_printed_toc()`이 그것을 거둬 `normalize_headings()`가 쓴다.

레벨은 이 순서로 정한다: **별행 번호**(`1.1`→h2, `1.9.1`→h3) → **맨 수사**(`ONE`) → **정답지 최상위** → **정답지 하위** → 수사·부속물 → **목차에 없음**(목차보다 잔 것) → 나머지. 마지막에 `_compact_levels()`가 스택으로 조상을 좇아 건너뛴 단을 메운다 — 형제는 반드시 같은 깊이를 받는다.

인쇄 목차가 **부(部)와 장(章) 두 계열로 번호를 매기면**(`PART I…IV` + `CHAPTER 1…19`) 장부터 한 단 내려 부 아래에 넣는다. 들여쓰기 좌표는 이 단계에 없지만 번호 체계가 둘이라는 사실 자체가 증거다. 판정은 반드시 **목차 항목**으로 한다 — 본문은 번호를 떼고 제목만 찍는 일이 흔해서(목차는 `1 The Power of Invention`, 본문은 `The Power of Invention`) 본문 글로 보면 앞부속이 장 취급을 받는다.

같은 정답지로 목차를 더럽히는 것들을 함께 걷어낸다.

| 함수 | 걷어내는 것 |
|---|---|
| `demote_printed_toc` | 인쇄 목차 쪽의 항목(같은 목차가 두 벌 실린다) |
| `drop_printed_toc` | 목차 쪽 자체를 본문에서 감춘다(`dropped`) — 목차는 앱 왼쪽 패널이 전담 |
| `_demote_figure_titles` | 도판 **안에** 인쇄된 제목. 뒤가 **설명 달린** 그림일 때만 |
| `demote_back_matter` | 뒤쪽 주석·색인 아래 세부 항목. 표제만 남긴다 |
| `demote_front_cover` | 인쇄 목차보다 앞쪽 쪽의 제목(표지·속표지·판권) |

**수사가 붙은 제목은 「수사 · 제목」 한 꼴로 맞춘다**(`canonical_label_headings`). 원본 조판이 제각각이기 때문이다 — 붙은 것(`CHAPTER 2THE LAST GENERATION`), 콜론, 줄표. 붙어 있으면 아예 장으로 읽히지도 않는다. 가르는 자리는 인쇄 목차가 정한다: 로마자·영문 서수는 제목 첫 글자를 삼켜서 글자만 보고는 못 가른다(`PART IIDIFFERENT`를 탐욕 매칭하면 **D도 로마자라** `PART IIDI`+`FFERENT`로 끊긴다). `merge_label_subtitles`는 맨 수사와 부제가 두 블록인 것을 목차가 한 줄로 실었을 때만 합친다.

원본 레벨이 필요하면 `--keep-heading-levels`. 인쇄 목차가 없는 책은 예전 두 단계 규칙으로 물러선다.

추출은 좌표와 폰트만 보는 추론이라 반드시 틀린다. 그래서 다음 단계가 있다.

### ② pagecheck — 페이지마다 판독해 대조
페이지를 이미지로 렌더링해 **싼 비전 모델(Haiku)로 전 페이지를 읽고**, 텍스트 레이어에서 뽑은 것과 대조한다. 휴리스틱만으로는 못 잡는 것들이 여기서 걸린다.

- **본문 누락** — PDF 텍스트 레이어는 이미지 안의 글자, 드롭캡, 사이드바, 회전된 캡션을 통째로 빠뜨린다. 토큰 일치율이 기준(기본 90%) 아래면 표시한다.
- **단 읽기 순서** — 2단 조판에서 좌우가 교차돼 문장이 뒤섞이는 사고.
- **제목이 본문에 파묻힘** — 폰트 크기 추론이 실패한 경우.
- **이미지 페이지** — 텍스트 레이어가 아예 없는 쪽.

**역할 분담이 핵심이다. 글자는 텍스트 레이어가 정답, 구조는 비전이 정답.** 텍스트 레이어는 문자 단위로 정확하지만 구조를 모르고, 비전 모델은 구조를 알지만 문자 단위로 정확하지 않다 — 고어 철자를 조용히 현대식으로 고치고, 저자가 의도한 오기를 바로잡고, 한 줄을 건너뛰고도 매끄러운 문장을 만든다.

그래서 판독 텍스트가 블록 내용이 되는 경로는 딱 두 가지로 제한된다. **누락 삽입**(레이어가 아예 못 본 텍스트)과 **페이지 재구성**(뒤 참조)뿐이고, 둘 다 `from_ocr: true`가 붙는다. 페이지 전문 판독은 일치율 계산에만 쓰이고 어떤 블록에도 기록되지 않는다.

재구성은 유일하게 레이어 내용을 밀어내는 경로다. 밀려난 원문은 버리지 않고 `book.json`의 `superseded`에 페이지별로 보관한다 — 그게 그 페이지의 유일한 문자 정확 기록이기 때문이다.

```bash
python scripts/pagecheck.py work/book.json --pdf book.pdf                   # 기본: vision
python scripts/pagecheck.py work/book.json --pdf book.pdf --pages 1-40      # 비용 시험
python scripts/pagecheck.py work/book.json --pdf book.pdf --engine datalab  # Datalab API 재판독
python scripts/pagecheck.py work/book.json --pdf book.pdf --engine tesseract  # 로컬 OCR
python scripts/pagecheck.py work/book.json --pdf book.pdf --trust vision    # 레이어가 OCR 산출물일 때
```

**`--trust vision` — 권한을 뒤집는 모드.** 위의 역할 분담은 텍스트 레이어가 문자 단위로 정확하다는 전제 위에 서 있다. 레이어 자체가 OCR 산출물이면(스캔본, 또는 전자책 리더 화면 캡처를 OCR한 PDF) 그 전제가 무너진다. 그런 문서에서는 레이어도 부정확한데, 하류가 고칠 수 없는 방식으로 부정확하다 — `bom`(born), `beSeattle`(be Seattle), `1temporarily`(I temporarily), 분철 하이픈이 `¬`로. 이때는 비전 판독이 그냥 더 낫다.

`--trust vision`은 전 페이지를 이미지에서 다시 받아쓴다. 밀려난 레이어 텍스트는 버리지 않고 `superseded`에 보관하고, 새 블록에는 `from_ocr`가 붙는다. 191쪽 실측:

| | 레이어 | `--trust vision` |
|---|---|---|
| `¬`로 쪼개진 단어 | 612 | 0 |
| 공백 누락(`beSeattle`) 추정 | 21 / 20쪽 | 3 |
| `I`를 `1`로 읽음 | 9 / 20쪽 | 0 |
| 표지·속표지의 가짜 제목 | 14 | 4 (진짜 제목만) |

**레이어가 멀쩡한 책에는 쓰지 마라.** 비전 모델은 고어 철자를 현대식으로 고치고, 저자의 의도적 오기를 바로잡고, 한 줄을 건너뛰고도 매끄러운 문장을 만든다. 곧은 따옴표로 바뀌는 등 사소한 손실도 있다. 먼저 `--pages 1-20`으로 $0.15어치만 돌려 실제로 나아지는지 확인하고 결정하라.

**비용.** 페이지 이미지는 긴 변 1568px로 줄여 보내므로 입력 약 2,500 토큰, 출력 900 안팎 — Haiku 기준 페이지당 약 $0.0075다. 300쪽이면 $2.3, 배치로는 절반. 같은 책 번역이 deslop까지 $7 안팎이니 30% 수준이다. 병목은 돈이 아니라 지연이라 기본 8워커로 동시 호출한다(`--workers`).

`--engine datalab`은 [Datalab API](https://www.datalab.to)(Chandra OCR 을 만든 곳의 호스팅 서비스 — 공개 웨이트보다 정확한 개선판 Chandra 가 돌아간다)로 **전 페이지를 다시 받아쓴다** — `--trust vision`과 같은 일을 다른 모델로 한다. 출력이 우리 블록 ID 를 모르는 통짜 판독이라 블록 단위 교정(layer 신뢰)은 성립하지 않고 항상 재구성이다: 전 블록에 `from_ocr|rebuilt`가 붙고 밀려난 레이어는 `superseded`에 보관된다. 응답은 `output_format=chunks` 로 받는다 — markdown 은 블록 유형을 잃어 그림 설명문이 본문·제목으로 새고 러닝 헤더를 우리 휴리스틱으로 다시 걸러야 했지만(실측), chunks 는 유형이 붙어 와서 `PageHeader`/`PageFooter`/`Picture` 를 결정론적으로 버리고 `SectionHeader`→h, `Caption`→figcaption, `Footnote`→footnote, `Table`→table_raw 로 대응만 하면 된다. **그림은 텍스트만 버리고 데이터는 줍는다** — 청크에 실려 오는 잘라낸 그림(base64 JPG)을 `book["assets"]` 로 수확하고 그 자리에 `figure` 블록(`src`=asset id, 번역 제외)을 끼운다. Picture 블록만 보면 안 된다: 표지에서는 그림이 SectionHeader 안에 `<img>` 로 내장되어 왔으므로 유형과 무관하게 모든 청크의 `images` 필드를 훑는다(`harvest_images()`). 모델이 지어 붙인 그림 설명문은 본문이 아니라 asset 의 `alt` 로만 보관하고, 한 변이 64px 미만인 조각(불릿·괘선)은 버린다. `export.py` 가 `asset` 테이블(스키마 v2)로 옮기고 앱이 그린다. `DATALAB_API_KEY` 가 필요하다(환경변수 또는 `.env` — 현재 폴더 → 스킬 폴더 → 그 부모 순). 모드는 `--datalab-mode fast|balanced|accurate`(기본 accurate), 과금은 Datalab 크레딧으로 실측 accurate 쪽당 1¢ — Claude 비전($0.0075)과 같은 자릿수다. **응답의 `total_cost` 단위는 센트다**(`cost_breakdown.final_cost_cents` 가 같은 값을 명시한다) — 달러로 읽으면 100배로 보여 멀쩡한 작업을 접게 된다.

**끝나면 빈 쪽부터 세라.** 판독이 실패한 쪽은 블록이 하나도 없이 남는데, 리포트의 일치율은 빈 것끼리 비교돼 `—` 로 찍히기 전까지 100% 로 보였다. 쪽별 블록 수를 세어 0 인 쪽을 찾고, 있으면 그 쪽만 `--pages N-N` 으로 다시 태워라 — 실패는 캐시에 남지 않으므로 성공분은 공짜다.

**업로드는 JPEG로 줄인다.** 토큰 값은 픽셀 치수만 따르므로 같은 1568px면 PNG든 JPEG든 값이 같다 — 줄어드는 건 올려보내는 바이트뿐이다. 그래서 기본을 회색조 JPEG q75로 잡았다. 246쪽 스캔본 실측으로 쪽당 561KB(PNG 컬러) → 187KB, 책 한 권이면 135MB → 46MB. 판독 정확도 차이는 없었다. 본문 글자는 명암이지 색이 아니다.

| | 쪽당 | 246쪽 |
|---|---|---|
| PNG 컬러(예전 기본) | 561 KB | 135 MB |
| JPEG q75 회색조(현재 기본) | 187 KB | 46 MB |

컬러 도판의 색이 판단에 필요하면 `--no-gray`, 무손실이 필요하면 `--image-format png`. `--jpeg-quality` 는 60 아래로 내리면 작은 활자가 뭉개진다.

**저작물 한 쪽을 통째로 받아쓰게 하면 API가 출력을 막는다.** 400 `Output blocked by content filtering policy` 가 돌아온다. 판정은 쪽 내용에 따라 결정적이라 재시도해도 같은 답이고, 실측으로 `--trust vision`(전문 재판독)은 12쪽 중 8쪽, 기본 모드는 12쪽 중 2쪽이 막혔다. 막힌 쪽은 건너뛰고 텍스트 레이어 글자를 그대로 둔다 — 번역은 그대로 진행되고 구조 교정만 못 받는다. 리포트의 일치율 칸에 `—`로 적히고 "vision unavailable" 로 센다.

이것이 **스캔본에서 `--trust vision` 대신 기본 모드를 쓰는 실질적인 이유**다. 기본 모드는 판독 텍스트를 출력으로 요구하지 않고 구조만 묻는다.

**도판 안 글자는 본문이 아니다.** 스캔본의 텍스트 레이어는 그림에 인쇄된 축 눈금·범례·지명·화살표 옆 낱말까지 본문과 똑같이 뱉는다. 자리를 잃으면 읽을 수 없는 조각인데 블록으로는 멀쩡해 보여 번역까지 흘러간다. 두 프롬프트 모두 이것을 **건너뛰도록** 못박았다 — 그림 번호표(`Figure 4`, `그림 1`, `(b)`)와 판독 잔해(`ZINZINZINZ`, `sveriGeE 5O`)도 함께다. 기본 모드는 `drop` 에 사유를 붙여 돌려준다.

| 사유 | 뜻 |
|---|---|
| `furniture` | 러닝 헤드·러닝 풋·쪽 번호 |
| `figure` | 그림·도표·지도 안의 글자, 그리고 그림 번호표 |
| `garbled` | 판독기가 만들어 낸 글자 뭉치 |

그림 아래에 **문장으로** 인쇄된 진짜 캡션은 `figcaption` 으로 남는다. 번호표만 앞에서 떼어 낸다.

`extract.py` 에도 같은 판별(`is_figure_label`·`looks_garbled`)이 들어 있어 비전 호출 없이 돌린 판본에서도 걸러진다. 두 파일이 같은 함수를 쓴다 — 한쪽을 고치면 다른 쪽도.

**모델의 판단을 그대로 따르지 않는 세 곳.** 오판의 대가가 한쪽으로만 크기 때문이다.

- **삽입(`missing`)** — 낱말의 8할 이상이 이미 그 쪽에 있으면 버린다. 앞머리만 보고 판단하면 안 된다. 모델은 이미 있는 문장으로 시작해 레이어가 놓친 대목까지 이어 적어 오므로, 겹친다고 지우면 새 본문을 함께 잃는다.
- **제외 `furniture`** — 러닝 헤드는 여러 쪽에 되풀이된다. 3쪽 이상 같은 글자로 나오지 않으면서 60자를 넘는 본문, 그리고 되풀이되지 않는 **모든 제목**은 버리지 않고 리포트에 `제외 N(거부 M)` 로 센다. 246쪽 스캔본에서 모델은 341개를 버리라 했고 그중 123개가 200자 넘는 본문 단락이었다 — 버려진 단락의 뒷부분만 번역돼 문장 중간부터 시작하는 한국어가 남았다.
- **제외 `figure`·`garbled`** — 여기엔 되풀이·길이 잣대를 대지 않는다. 그 잣대는 머리글을 지키자고 만든 것이라 멀쩡한 판정을 막는다. 쪽 이미지를 본 모델이 우리보다 잘 안다. 다만 **문장으로 끝나는 블록**은 되돌린다(`reads_as_prose`) — 본문 단락은 아무리 이상해 보여도 문장으로 끝난다.

`--engine tesseract`는 로컬 OCR을 전 페이지에 돌리고 표시된 페이지만 비전으로 교정한다. 무료·오프라인이지만 **탐지만 하고 교정은 못 한다** — OCR은 글자를 다 읽어도 그게 제목인지 캡션인지 모르고, 읽기 순서도 좌표 추정에 불과하다. `pip install pytesseract pillow` + 바이너리가 필요하다.

**교정 세 종류.**
1. 유형·순서·제외 — 블록 단위 수정
2. 누락 삽입 — 레이어가 못 본 텍스트를 새 블록으로. ID는 **접미사(`b0042a`)**라 전체 번호를 다시 매기지 않으므로 기존 번역 캐시가 유효하다
3. **페이지 재구성** — 2단이 블록 *내부에서* 뒤섞여 블록 단위 교정으로는 못 고치는 경우, 그 페이지만 판독 텍스트로 다시 만든다. 최후 수단이라 모델이 명시적으로 요청할 때만 발동한다

2·3으로 생긴 블록은 `from_ocr: true`가 붙는다. 판독 텍스트는 레이어보다 부정확하니 리포트에서 따로 확인하라.

텍스트 레이어가 아예 없는 순수 스캔본은 `extract.py`가 **Tesseract 로 레이어를 입힌 사본을 자동으로 만들어 탄다**(작업 폴더의 `*.ocr.pdf`, 언어는 `--ocr-lang`, 기본 eng). 글자 품질은 레이어의 역할(블록 ID·페이지 대응의 닻)에만 필요하고, 실제 글자는 `--trust vision` 재판독이 다시 받아쓴다. Tesseract 가 없으면 설치 안내와 함께 멈춘다(`winget install UB-Mannheim.TesseractOCR`).

**단, `--engine datalab` 을 쓸 거면 이 레이어는 낭비다 — `extract.py --allow-scanned` 로 건너뛰어라.** datalab 은 항상 전 쪽 재구성이라 레이어를 통째로 `superseded` 로 밀어낸다(하류로 한 글자도 가지 않는다). 닻이 필요했던 것은 `rebuild_page` 에 **빈 쪽 경로**가 들어오기 전 얘기다 — 지금은 블록이 0인 쪽에도 위치(쪽 번호 순)와 ID(책 전체 최대 번호 이어받기)를 새로 따서 넣는다. 175쪽 책에서 0블록 `book.json` → datalab → 1,120블록으로 실측 확인했고, Tesseract 300dpi 15분을 통째로 아꼈다.

**빈 쪽 경고를 절대 흘려보내지 마라.** 판독은 실패한 쪽을 **조용히 넘긴다**. 정본 여덟 권을 한참 뒤에 훑어 보니 **34쪽이 통째로 비어** 있었고, 그 안에 장 제목과 본문이 들어 있었다 — `rewired` 는 39장 중 8·34장이 목차에서 사라져 있었고 34장은 본문 여덟 쪽이 없었다. 이제 pagecheck 가 끝에서 블록 없는 쪽을 찍고 다시 읽을 명령을 그대로 내놓는다.

```
!! 블록이 없는 쪽 15개: 49,153,260,379,536,537,…
   빈 쪽인지 판독 실패인지 원본을 눈으로 볼 것. 실패라면:
   python scripts/pagecheck.py work/book.json --pdf <pdf> --engine datalab --pages 49,153,…
```

**원본을 먼저 눈으로 보라.** 진짜 빈 쪽·색인 쪽도 여기 걸린다(실측: `the_mind_is_flat` p239 는 색인이라 그냥 두는 게 맞다). 쪽당 Datalab 1¢ 정도이고 캐시가 나머지를 공짜로 넘긴다.

**한 문단에 뭉쳐 온 목록은 줄로 나눈다**(`split_lists_in_blocks`). 판독기는 불릿 목록을 문단 하나로 접어 주고(실측 여덟 권에서 불릿 180블록·번호 목록 64블록), 리더는 줄바꿈이 없으니 통짜로 그린다. **항목마다 블록으로 쪼개지는 않는다** — 대역 리더는 블록끼리 원문·번역을 짝짓는데 번역이 항목 수를 지킨다는 보장이 없다. 번호 목록은 번호가 연달아 이어질 때만 나눈다(그러지 않으면 본문 속 숫자를 목록으로 오인한다).

> **`chunks` 만 받으면 각주 마커를 잃는다.** 2026-08-17 실측: 같은 쪽을 `output_format=json,html` 로 받으면 html 에 **`<sup>1</sup>` 이 살아 있다.** 지금 경로는 `chunks` 만 받아 html 을 벗기며 그것을 버리고, 그래서 「각주 cross-link」가 「본문 쪽 위첨자가 없다」로 막혀 있었다. **네 형식(`json`·`html`·`markdown`·`chunks`)을 한 번에 받아도 값은 같다.** 응답의 `total_cost` 에 실제 과금(쪽당 1¢)이 들어 있어 추정할 필요도 없다. 그리고 **PDF 를 통째로 보낼 수 있고**(4쪽 3¢) 그때도 블록마다 `page`+`bbox` 가 오므로 쪽 이미지를 우리가 렌더할 필요가 없다 — 자세한 것은 `CONTEXT.md` 「Datalab API 가 실제로 무엇을 주는가」.

**끝나면 `work/pagecheck-report.md`와 `work/blocks.txt`를 훑어라.** blocks.txt는 교정 결과가 반영돼 다시 쓰인다. 구조를 고칠 수 있는 마지막 지점이다.

### ③ glossary — 일관성 자산 만들기
본 번역 전에 전체를 훑어 인명·지명·반복 개념어를 뽑고 역어를 **미리 확정**한다. 이걸 건너뛰면 3장의 "the Commission"이 5장에서 다른 말로 바뀐다.

소설이면 여기서 **인물 관계표**도 만든다. 영어에 없는 존대·반말·호칭을 한국어는 매번 정해야 하는데, 고정해두지 않으면 인물 말투가 챕터마다 흔들린다. 자세히는 [`references/consistency.md`](references/consistency.md).

생성된 `work/glossary.json`은 **사람이 고치라고 만든 파일이다.** 번역 시작 전에 반드시 열어보고 어색한 역어를 손봐라. 여기 5분이 뒤의 한 시간을 아낀다.

### ④ translate — 문체 축에 따라 번역
"소설체로 번역해줘" 같은 형용사 지시는 결과가 흔들린다. register를 종결어미·문장분할·어휘·대명사·고유명사·존대 여섯 축의 조합으로 명세해 뒀다. 전문은 [`references/registers.md`](references/registers.md).

| register | 종결 | 문장 분할 | 어휘 | 대명사 | 쓰임 |
|---|---|---|---|---|---|
| `literal` 직역 | -다 | 원문 유지 | 원어 근접 | 명시 | 대조 확인, 학술 |
| `fiction` 소설 | -다 (평서) | 적극 분할 | 고유어 우선 | 대폭 생략 | 소설, 서사 논픽션 |
| `essay` 에세이 | -다 | 중간 | 균형 | 생략 | 에세이, 교양서 |
| `business` 비즈니스 | -습니다/-다 | 적극 분할 | 한자어 | 생략 | 보고서, 실용서 |
| `newneek` 뉴닉 | -요 해요체 | 최대 (40자) | 일상어 | 생략 · '우리' | 교양서를 쉽게 |
| `nominal` 개조식 | **명사형** | 원문 유지 + 단락 내 축약 | 한자어 | 생략 | 보고서식 통독, 발췌 |

**`nominal` — 개조식 명사형 종결.** `business`/`literal` 바탕에 종결부만 바꾼 문체다. 문장이 한자어 동사성 명사로 끝난다(`두 부분으로 구성.` `설명 제시.` `폐기 필요.`). `함·됨·임`은 없어도 뜻이 통하면 떼고, 끝맺는 명사 앞의 조사도 뗀다(`설명을 제시` → `설명 제시`). 고유어 명사형(`있음` `같음` `아님`)은 마땅한 한자어가 없을 때만, `했음/할 것임/고 있음`은 시제·상을 실을 때만 쓴다. 소설에는 쓸 수 없다 — 대사가 전부 무너진다.

> **종결 규칙은 축 하나에 모아 둘 것.** 이 규칙을 계사문·청유형 처리까지 별도 축으로 쪼개고 `BASE` 의 [절대 규칙]에까지 더했더니, 같은 36블록에서 `-다` 누출이 **1건 → 54건**으로 늘었다(시스템 프롬프트 29.4k→33.3k tok). 여러 자리에 흩는 것은 강조가 아니라 희석이다.

**개조식은 종결 교정 패스가 따라붙는다.** 문체 사양만으로는 새는 자리가 남고, 누출은 **긴 블록의 가운데**에 몰린다 — 1,200자 12문장 단락은 앞뒤가 명사형인데 중간 여섯 문장이 서술형으로 풀린다. 실측 누출률은 실행마다 0.6%~8.8%로 흔들린다. `translate.py` 는 번역이 끝나면 종결부가 샌 블록만 골라 다시 보낸다(재번역이 아니라 종결부 교체). 따로 돌리려면 `--fix-endings-only`, 끄려면 `--no-fix-endings`.

검출기는 물음표 문장과 **인용부호 안**을 건드리지 않는다. 대사의 `-습니다`는 인물이 실제로 한 말이라 개조식으로 바꾸지 않으며, 마스킹하지 않으면 그 블록이 영원히 "아직 누출"로 남는다(교정자는 규칙대로 손대지 않으므로).

**번역 뒤에 결정론적 손질 셋이 붙는다.** 모델을 다시 부를 일이 아니라 꼴이 정해진 것들이다.

- `strip_invented_bold` — 모델이 지어낸 마크다운 강조를 걷어낸다. 정본 여덟 권에서 110블록이 `**…**` 로 감싸여 있었고 **원문에 `**` 가 든 블록은 하나도 없었다**. 리더는 마크다운을 해석하지 않아 별표가 글자 그대로 박힌다. 원문에 그 표시가 있으면 손대지 않는다.
- `localize_bare_labels` — `CHAPTER 8` 처럼 낱말과 숫자뿐인 제목은 모델이 옮길 것이 없다고 보고 그대로 돌려준다. 그러면 한 책에서 어떤 장은 `제7장`, 어떤 장은 `CHAPTER 8` 이 된다.
- `split_ko_lists` — 원문이 목록으로 갈렸으면 번역도 같은 자리에서 가른다. **맨 마지막에 돌려야 한다** — 모델에게는 「블록 하나는 한 줄」로 받고(그러지 않으면 `from_wire` 가 뒤 줄을 버린다) 개조식 종결 교정도 ko 를 한 줄로 되돌린다. 원문 쪽 줄 수와 맞을 때만 손댄다.

### ⑤ deslop — 번역투 제거
번역과 동시에 하지 않는다. 번역은 정확성, deslop은 문체라 섞으면 둘 다 나빠진다. 별도 패스로 돌린다.

**`nominal` 은 deslop 을 태우지 않는다.** 교정자의 규칙표가 전부 `-다` 서술문을 전제로 쓰여 있어서("~이 존재한다" → "~이 있다", 조동사 중첩, 형식주어 …) 명사형 종결을 번역투로 읽고 문장을 통째로 서술형으로 되돌린다 — 문체 자체가 지워진다. `deslop.py` 가 register 를 보고 스스로 빠지며, 굳이 돌리려면 `--strength` 를 명시해야 한다. 개조식의 마무리는 위의 종결 교정 패스가 대신한다.

기존 `deslop` 스킬의 Korean sub-track(번역투 A~J 분류, S1~S3 심각도)을 그대로 쓴다. 여기 있는 [`references/deslop-translation.md`](references/deslop-translation.md)는 **번역 문맥에만 해당하는 추가 규칙과 예외**만 담는다. 특히 소설에서 작가 고유 문체(의도적 반복, 파편문, 거친 리듬)를 슬롭으로 오인해 지우는 사고를 막는 예외 규칙이 중요하다.

### ⑥ verify — 조용한 누락 잡기
LLM이 문단을 통째로 빠뜨리는 일은 흔하고, 읽어서는 못 잡는다. `verify.py`가 기계적으로 본다:

- 블록 ID 집합 일치, 빈 번역
- 숫자·연도·통화·퍼센트 대조
- glossary 역어 준수 여부
- 길이 비율 이상치 (한국어/영어 문자 비율이 정상 범위 밖인 블록)

리포트는 `work/verify-report.md`. **경고가 남은 채로 내보내지 마라.**

### ⑦ export — `.parallax` 로 넘기기
`out/book.parallax`를 낸다. 이게 이 파이프라인의 끝이다.

`.parallax`는 렌더링이 아니라 **작업 파일**이다. 블록 ID, 양쪽 언어, deslop 이전 텍스트, 용어집, pagecheck 이력이 전부 살아 있어서 이 파이프라인이 밤새 번역한 책을 앱에서 이어 읽을 수 있고, 앱에서 시작한 책을 `parallax_import.py`로 되받아 CLI에서 끝낼 수 있다. SQLite이며 스키마는 `_parallax.py`에 있다.

읽는 화면 — 좌우 대역 조판, 목차, 서체·폭·줄간격 조절, 사전 팝업, 가상 스크롤 — 은 전부 **Parallax 데스크톱 앱**에 있다. 여기서 HTML을 또 만들지 않는다.

```bash
python scripts/export.py work/book.json --out out/
open out/book.parallax
```

### ⑧ repair — 이미 만든 `.parallax` 되돌리기

파이프라인을 고쳐도 그 전에 만든 책은 번역이 이미 들어 있다. 다시 돌리면 번역값을 통째로 다시 사야 하므로, 블록만 손보고 번역은 살리는 사후 도구를 둔다.

```bash
python scripts/repair.py out/book.parallax                        # 미리보기
python scripts/repair.py out/book.parallax --apply                # .bak 를 남기고 적용
python scripts/repair.py out/book.parallax --stitch-translated --apply
```

pagecheck 이 냈던 손상 세 가지를 되돌린다.

1. **중복 삽입 지우기.** `missing` 삽입의 중복 검사가 구두점 때문에 빗나가, 이미 뽑혀 있던 단락이 조각으로 한 번 더 들어왔다. 낱말의 8할 이상이 그 쪽에 이미 있으면 지운다. 앞부분만 겹치는 블록은 **남긴다** — 뒤에 레이어가 놓친 새 본문이 붙어 있다.
2. **잘못된 제외 되돌리기.** 모델이 절 제목과 본문 단락을 러닝 헤드로 오인해 버린 것을 번역 큐로 돌린다. 이미 번역이 있으면 그대로 살린다.
3. **갈린 단락 잇기.** 두 블록을 합치면 번역을 버려야 하므로, 양쪽에 번역이 있는 이음매는 `--stitch-translated` 없이는 건드리지 않는다.

246쪽 스캔본 실측: 블록 1569 → 1391(중복 97 삭제, 81쌍 병합), 잘못된 제외 234개 복구, 본문 안에 남은 문장 중간 끊김 0.

## 주의

- **비용과 시간.** 300쪽이면 10만 단어 안팎이다. 대략 pagecheck $2 + translate·deslop $7. 먼저 `pagecheck --pages 1-40`, `translate --limit 30` 으로 앞부분만 돌려 확인하고 전체를 태워라.
- **저작권.** 개인 학습·소장용 번역본을 만드는 도구다. 산출 `.parallax`에는 원문 전체가 그대로 들어간다. 배포·공유·게시는 하지 마라.
- **스캔본.** 텍스트 레이어가 없으면 `extract.py`가 Tesseract 로 레이어를 자동 생성한다(위 ② 참조). 그다음은 문서에 따라 갈린다. 예전에는 무조건 `--trust vision` 을 권했지만, 저작물은 전문 재판독이 출력 필터에 막힌다(②의 400 항목). 스캔 품질이 좋으면 기본 모드로 충분하다 — 246쪽 스캔본(전자책 리더 캡처) 실측에서 Tesseract 가 본문 단락을 곡선 따옴표까지 그대로 읽었고, 망가진 것은 도판 안의 글자뿐이었다. 그건 기본 모드의 구조 교정이 `translate:false` 로 걷어낸다. 먼저 열 쪽만 뽑아 `blocks.txt` 를 보고 결정하라.
- **TLS 검사 장비.** 사내망이 TLS를 중간에서 끊고 자체 루트로 다시 서명하면, 그 루트가 OpenSSL 기준으로 형식이 어긋난 경우 브라우저는 되는데 파이썬만 전 호출이 `CERTIFICATE_VERIFY_FAILED`로 죽는다. `requirements.txt`의 `truststore`가 검증을 OS에 맡겨 해결한다 — 검증을 끄는 게 아니라 이 PC의 나머지 프로그램과 같은 판단을 하는 것이다.
- **앞뒤 부속물.** 색인·참고문헌은 기본적으로 원문 유지(`--keep-original index,bibliography`). 번역해 봐야 쓸모가 없고 토큰만 먹는다.

## 파일

```
references/
  decisions.md            설계 결정과 실제로 밟은 지뢰 — 손보기 전에 먼저 읽을 것
  structure.md            PDF 구조 복원 규칙, 흔한 실패
  registers.md            문체 축 명세 + 프롬프트 조각
  consistency.md          용어집·인물관계표 포맷과 운영
  deslop-translation.md   번역 문맥 전용 deslop 규칙과 보존 예외
scripts/
  _llm.py                 API 호출(텍스트·비전), 청킹, 캐시, 재개
  extract.py    PDF → 블록
  pagecheck.py  페이지별 비전 판독 대조 + 구조 교정 (또는 datalab·tesseract 엔진)
  glossary.py  translate.py  deslop.py  verify.py
  export.py          book.json → `.parallax`
  _parallax.py       `.parallax` 스키마
  parallax_import.py `.parallax` → book.json (역방향)
  repair.py          이미 만든 `.parallax` 의 구조 손상 되돌리기 (⑧ 참조)
  run.sh
```

`templates/`(이북 HTML 셸·테마 CSS)와 `render.py`는 제거했다. 읽는 화면은 Parallax 앱이다.
