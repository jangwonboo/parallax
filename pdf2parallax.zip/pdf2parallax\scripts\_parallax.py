"""`.parallax` — the working file the Electron app opens.

It is the only thing this pipeline emits. Every block ID, both languages, the
pre-deslop text, the glossary and the page-check history survive, so a book
translated overnight by the CLI can be read in the app, and a book started in the
app can be finished by the CLI.

It is a SQLite database. Schema follows parallax-engine-spec.md §2.2.
"""
from __future__ import annotations

import json
import sqlite3
import time
from pathlib import Path

SCHEMA_VERSION = 2  # v2: asset 테이블 + figure 블록 유형
ORD_STEP = 1024          # sparse ordering: insertions take the midpoint

# block.flags bits
FROM_OCR = 1 << 0
REBUILT = 1 << 1
STITCHED = 1 << 2
NEEDS_REVIEW = 1 << 3
NO_TRANSLATE = 1 << 4
DROPPED = 1 << 5

# block.state
UNTRANSLATED, IN_FLIGHT, TRANSLATED, DESLOPPED = 0, 1, 2, 3

DDL = """
PRAGMA journal_mode = WAL;

CREATE TABLE IF NOT EXISTS doc (
  id             TEXT PRIMARY KEY,
  title          TEXT,
  title_ko       TEXT,
  author         TEXT,
  source_path    TEXT,
  source_hash    TEXT,
  source_kind    TEXT,
  pages          INTEGER,
  schema_version INTEGER,
  created_at     INTEGER,
  updated_at     INTEGER
);

CREATE TABLE IF NOT EXISTS block (
  id         TEXT PRIMARY KEY,
  ord        INTEGER NOT NULL,
  page       INTEGER,
  type       TEXT NOT NULL,
  src        TEXT NOT NULL,
  ko         TEXT,
  ko_raw     TEXT,
  state      INTEGER DEFAULT 0,
  flags      INTEGER DEFAULT 0,
  height_px  INTEGER,
  updated_at INTEGER
);
CREATE INDEX IF NOT EXISTS block_ord   ON block(ord);
CREATE INDEX IF NOT EXISTS block_state ON block(state, ord);
CREATE INDEX IF NOT EXISTS block_page  ON block(page);

CREATE TABLE IF NOT EXISTS superseded (
  page    INTEGER PRIMARY KEY,
  payload TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS asset (
  id   TEXT PRIMARY KEY,
  mime TEXT NOT NULL,
  w    INTEGER,
  h    INTEGER,
  alt  TEXT,
  wfrac REAL,          -- 원본 쪽 폭 대비 폭(0~1). 옛 파일에는 없다.
  data BLOB NOT NULL
);

CREATE TABLE IF NOT EXISTS glossary (
  en     TEXT PRIMARY KEY,
  ko     TEXT NOT NULL,
  kind   TEXT,
  locked INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS page_check (
  page       INTEGER PRIMARY KEY,
  coverage   REAL,
  columns    INTEGER,
  notes      TEXT,
  checked_at INTEGER
);
"""


def flags_of(b: dict) -> int:
    f = 0
    if b.get("from_ocr"):
        f |= FROM_OCR
    if b.get("rebuilt"):
        f |= REBUILT
    if b.get("stitched"):
        f |= STITCHED
    if b.get("needs_review"):
        f |= NEEDS_REVIEW
    if not b.get("translate", True):
        f |= NO_TRANSLATE
    if b.get("dropped"):
        f |= DROPPED
    return f


def state_of(b: dict) -> int:
    if not (b.get("ko") or "").strip():
        return UNTRANSLATED
    return DESLOPPED if b.get("ko_raw") else TRANSLATED


def connect(path: str | Path) -> sqlite3.Connection:
    con = sqlite3.connect(str(path))
    con.row_factory = sqlite3.Row
    con.executescript(DDL)
    return con
