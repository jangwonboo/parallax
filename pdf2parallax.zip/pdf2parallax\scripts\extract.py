#!/usr/bin/env python3
"""PDF -> book.json. Recovers headings, paragraphs, quotes, footnotes; assigns immutable block IDs.

    python scripts/extract.py book.pdf --out work/book.json
"""
from __future__ import annotations

import argparse
import json
import re
import shutil
import statistics
import subprocess
import sys
from collections import Counter
from pathlib import Path

try:
    import fitz  # PyMuPDF
except ImportError:
    sys.exit("PyMuPDF required:  pip install pymupdf")

# A Windows console is cp949/cp1252, not UTF-8, and `print` raises on the first
# character the codepage cannot hold. An em dash in a progress line was enough to
# kill a run whose book.json had already been written — the caller saw exit 1 and
# threw the extraction away. Progress text must never be able to fail the job.
for _s in (sys.stdout, sys.stderr):
    try:
        _s.reconfigure(errors="replace")
    except Exception:
        pass

# Some PDFs are screen captures of an ebook reader that were OCR'd with a Korean
# language pack enabled. The engine then emits Hangul syllables for Latin letters it
# is unsure about — always the same handful, always inside otherwise-English words.
# Left alone this corrupts roughly 1-2% of words and poisons every downstream stage.
HANGUL_OCR_FIX = {
    "판": "e", "폰": "e", "믄": "e", "픈": "e", "은": "e", "본": "e", "브": "e",
    "으": "e", "판": "e",
    "나": "u", "니": "u",
    "융": "g",
    "아": "OF",
}
CJK_RE = re.compile(r"[\uac00-\ud7a3\u1100-\u11ff\u3130-\u318f\u4e00-\u9fff]")


def repair_ocr_layer(text: str) -> str:
    """Undo Hangul-for-Latin OCR substitutions inside English words."""
    out = []
    for ch in text:
        if ch in HANGUL_OCR_FIX:
            out.append(HANGUL_OCR_FIX[ch])
        elif CJK_RE.match(ch):
            out.append("")  # unmapped stray glyph, almost always a note marker
        else:
            out.append(ch)
    return "".join(out)


def cjk_density(doc, sample: int = 40) -> float:
    words = hits = 0
    for i in range(min(sample, len(doc))):
        for w in doc[i].get_text().split():
            words += 1
            if CJK_RE.search(w):
                hits += 1
    return hits / words if words else 0.0


def scan_backed(doc, sample: int = 20) -> float:
    """Fraction of sampled pages that are a full-page raster with text drawn over it.

    This is what an OCR sandwich looks like: the page you see is a photograph, and the
    text layer is what an engine read off it. Such a layer is not authoritative — its
    characters are a guess, so pagecheck's `--trust vision` applies to it and not to a
    born-digital PDF. The Hangul-glyph heuristic below only catches layers OCR'd with a
    Korean language pack, which is a small corner of the same problem.
    """
    n = len(doc)
    if not n:
        return 0.0
    step = max(1, n // sample)
    seen = covered = 0
    for i in range(0, n, step):
        page = doc[i]
        area = abs(page.rect)
        if not area:
            continue
        seen += 1
        for img in page.get_images(full=True):
            if any(abs(r) / area >= 0.8 for r in page.get_image_rects(img[0])):
                covered += 1
                break
    return covered / seen if seen else 0.0


SKIP_HINTS = ("index", "bibliography", "references", "notes",
              "acknowledgments", "copyright", "contents", "about the author")
FIGCAP_RE = re.compile(r"^(figure|fig\.|table|plate|chart|exhibit)\s*[\d.]", re.I)
CHAPTER_RE = re.compile(
    r"^(chapter|part|book|section)\s+([\divxlcIVXLC]+)|^[IVXLC]{1,6}[.\s]|^\d{1,2}[.\s]", re.I)


# ---------- line assembly ----------

def page_lines(page):
    """Return [{text,size,bold,x0,x1,top,bottom}] for one page, in reading order."""
    out = []
    d = page.get_text("dict")
    for block in d["blocks"]:
        if block.get("type") != 0:
            continue
        for line in block["lines"]:
            spans = [s for s in line["spans"] if s["text"].strip()]
            if not spans:
                continue
            text = "".join(s["text"] for s in line["spans"])
            sizes = [round(s["size"], 1) for s in spans]
            out.append({
                "text": text.rstrip(),
                "page_h": page.rect.height,
                "size": statistics.median(sizes),
                "bold": any("bold" in s["font"].lower() or (s["flags"] & 2 ** 4)
                            for s in spans),
                "italic": any("italic" in s["font"].lower() or (s["flags"] & 2 ** 1)
                              for s in spans),
                "x0": min(s["bbox"][0] for s in spans),
                "x1": max(s["bbox"][2] for s in spans),
                "top": min(s["bbox"][1] for s in spans),
                "bottom": max(s["bbox"][3] for s in spans),
            })
    return out


def detect_columns(lines, page_width):
    """Two-column if x0 values cluster into two well-separated groups."""
    if len(lines) < 10:
        return 1
    mid = page_width / 2
    left = [l for l in lines if l["x1"] < mid + page_width * 0.04]
    right = [l for l in lines if l["x0"] > mid - page_width * 0.04]
    if len(left) > len(lines) * 0.3 and len(right) > len(lines) * 0.3:
        return 2
    return 1


def order_lines(lines, page_width):
    if detect_columns(lines, page_width) == 2:
        mid = page_width / 2
        left = sorted([l for l in lines if l["x0"] < mid], key=lambda l: l["top"])
        right = sorted([l for l in lines if l["x0"] >= mid], key=lambda l: l["top"])
        return left + right
    return sorted(lines, key=lambda l: (round(l["top"], 1), l["x0"]))


BAND = 0.08          # top / bottom fraction of the page a head or folio lives in
FOLIO_RE = re.compile(r"^[\divxlcIVXLC\s.\[\]()—–-]{1,12}$")


def in_band(l) -> bool:
    """True when the line sits wholly inside the top or bottom band of its page."""
    h = l.get("page_h") or 0
    if not h:
        return False
    return l["bottom"] < h * BAND or l["top"] > h * (1 - BAND)


def norm_head(t: str) -> str:
    """Fold whitespace, case and any page number so 'Chapter 3 | 47' matches itself.

    공백은 아예 걷어낸다 — OCR 레이어는 같은 머리글의 띄어쓰기를 쪽마다 다르게
    읽어(`« 10%` / `«9%`), 한 칸으로만 접으면 반복 버킷이 갈라져 임계에 못 미친다."""
    return re.sub(r"\s+", "", re.sub(r"\d+", "#", t)).strip().lower()


PROGRESS_WORDS = {"page", "pages", "of", "location", "loc", "left", "chapter", "min", "mins"}
X_OF_Y_RE = re.compile(r"\d\s*(?:of|0f|oi)\s*\d", re.I)


def is_page_progress(text: str) -> bool:
    """전자책 뷰어 캡처의 쪽 진행 표시인가 — 'Page 26 of 201 · 9%', 'Location 6 of 4093 + 0%'.

    쪽마다 숫자가 달라 반복 탐지에 걸리지 않으므로 무조건 지운다.

    두 가지를 고쳤다.

    **판독이 뭉갠 형태를 놓치고 있었다.** 실제 캡처에서 나온 것들: `Page 60T 252 + 3%`,
    `Page 14 0f 252 * 7%`, `Page /b oT 252 * 30%`. `of` 가 `0f`·`oT`·`/b` 로 읽히면서
    글자 목록에 한두 글자짜리 부스러기가 끼고, 예전 규칙(`words <= {page, of}`)이
    그대로 무너졌다. 세 글자 미만 조각은 낱말로 세지 않는다.

    **그리고 숫자만 있는 블록을 전부 삼키고 있었다.** 예전 규칙은 글자가 하나도 없으면
    (`not words`) 곧바로 참이었다. 그래서 분철된 인용의 꼬리 — `Journal of Nervous and
    Mental Dis-` 뒤에 오는 `ease, 131(2): 135-48.`, `46.`, `80.` — 이 뷰어 부속물로
    지워졌다. **진짜 내용이 사라진 사고다.** 이제 진행 표시라는 증거(`%`, page/location,
    또는 `26 of 201` 꼴)를 요구한다."""
    t = text.strip()
    if len(t) > 48:
        return False
    words = [w for w in re.findall(r"[a-z]+", t.lower()) if len(w) > 2]
    marker = ("%" in t
              or any(w in {"page", "pages", "location", "loc"} for w in words)
              or X_OF_Y_RE.search(t))
    if not marker:
        return False
    if not any(c.isdigit() for c in t):
        return words == ["page"]
    return set(words) <= PROGRESS_WORDS


URL_RE = re.compile(r"https?://|www\.[a-z0-9-]+\.[a-z]{2,}|[a-z0-9-]+\.(?:org|com|net|edu|gov|io)/", re.I)


def is_bare_label(text: str) -> bool:
    """도판에서 뜯겨 나온 맨 숫자·기호 조각인가 — `0.8` · `»16` · `5 0.6` · `=` · `Q)`.

    `is_page_progress` 가 예전에는 이것까지 겸했다(글자가 없고 숫자가 있으면 참).
    그 겸업이 분철된 인용의 꼬리(`46.`·`80.`)를 삼켰기에 둘을 갈랐다. 이쪽은 여전히
    필요하다 — 축 눈금과 범례 숫자는 쪽마다 달라 반복 탐지에 걸리지 않는다.

    **두 글자 이상인 낱말이 하나라도 있으면 아니다.** 저자가 쓴 글에는 낱말이 있다.
    남는 위험은 `46.` 처럼 진짜 내용이 숫자만으로 이루어진 경우인데, 그것들은
    앞 블록이 하이픈으로 끊긴 자리에 있으므로 `pagecheck.continues_hyphen` 이 막는다."""
    t = text.strip()
    if not t or len(t) > 40:
        return False
    if re.search(r"[A-Za-z가-힣]{2,}", t):
        return False
    return bool(re.search(r"\d", t)) or len(t) <= 3


def strip_running_heads(pages, outline_titles=frozenset()):
    """Drop running heads, running feet and folios.

    Two things were wrong with the obvious version of this.

    **Geometry, not line index.** Taking `lines[:2] + lines[-2:]` calls whatever
    happens to be first on the page an edge line. A drop cap, an epigraph or a
    figure pushes the real head down out of that window, and on a short page the
    first line of body text gets accused instead. The band is a fraction of the
    page height, so it means the same thing on every page.

    **The threshold has to be low.** Books print the head on verso only, drop it on
    chapter openings, full-page figures and part titles. A head that runs on a fifth
    of the pages is entirely normal. Requiring 25% of pages let a head that appeared
    on 37 of 191 pages survive, and `classify()` then scored all 37 as headings —
    short, title case, no terminal punctuation — so the table of contents came out
    with the book title repeated 37 times. Repetition inside the band is already a
    strong signal; three pages is enough to be sure it is furniture.

    A line matching a PDF outline entry is never stripped — a chapter title is
    supposed to sit at the top of its opening page."""
    seen: dict[str, set[int]] = {}
    for pno, lines in enumerate(pages):
        for l in lines:
            if not in_band(l):
                continue
            t = norm_head(l["text"])
            if 0 < len(t) < 70:
                seen.setdefault(t, set()).add(pno)

    threshold = max(3, round(len(pages) * 0.05))
    repeated = {t for t, pgs in seen.items() if len(pgs) >= threshold}

    dropped = Counter()
    for lines in pages:
        keep = []
        for l in lines:
            text = l["text"].strip()
            if in_band(l):
                plain = re.sub(r"\s+", " ", text).strip().lower()
                if plain not in outline_titles:
                    if norm_head(text) in repeated:
                        dropped[text] += 1
                        continue
                    if FOLIO_RE.fullmatch(text):
                        dropped["<folio>"] += 1
                        continue
                    if is_page_progress(text):
                        dropped["<page-progress>"] += 1
                        continue
            keep.append(l)
        lines[:] = keep
    return dropped


# ---------- paragraph merging ----------

def dehyphenate(prev: str, nxt: str) -> str | None:
    if prev[-1:] in HYPHENS and len(prev) > 2 and prev[-2].islower() and nxt[:1].islower():
        return prev[:-1] + nxt
    return None


# 문장이 실제로 끝났는가. 닫는 따옴표·괄호는 문장부호 **뒤에** 올 때만 끝이다.
# 예전 규칙은 닫는 부호 하나만으로 끝이라고 봤고, 그래서 `Our ‘inner oracle’` 처럼
# 인용어로 끊긴 줄이 완결된 단락으로 취급돼 다음 조각(`is such a good storyteller
# — …`)과 영영 이어지지 않았다. 인용 부호는 문장의 끝을 뜻하지 않는다.
TERMINAL_RE = re.compile(r'[.!?…][\'"’”)\]]*\s*$')

# A book sets its line-break hyphen as U+002D, but an OCR'd text layer renders the
# same glyph as U+00AC NOT SIGN or drops in a soft hyphen. This book had 612 of them
# (`am¬ bitious`, `dec¬ ade`), every one a word split at a line end. Treating only
# U+002D as a hyphen leaves those words broken in two for the translator.
HYPHENS = "-¬­‐‑"
SOFT_RE = re.compile(rf"(\w)[{HYPHENS[1:]}]\s*(\w)")


def repair_soft_hyphens(text: str) -> str:
    """Rejoin `am¬ bitious`; keep a real compound as a plain hyphen."""
    def sub(m):
        a, b = m.group(1), m.group(2)
        return a + b if a.islower() and b.islower() else f"{a}-{b}"
    return SOFT_RE.sub(sub, text)


# 이어지는 조각이 여는 부호로 시작하는 경우. 한 책에서 29곳이 이것 때문에 갈렸다 —
# `…the very idea that our minds contain` / `‘hidden depths’ is utterly wrong.` 처럼
# 인용 부호로 시작하면 소문자 검사에 걸리지 않아 단락이 둘로 남았다.
OPENERS = "\"'‘“(['«‹「『"


def continues_sentence(s: str) -> bool:
    """앞 블록의 이어짐으로 보이는가. 여는 따옴표·괄호는 벗기고 판단한다."""
    head = s.lstrip()
    if head[:1] in ",;:":
        return True
    return head.lstrip(OPENERS).lstrip()[:1].islower()


# 이어붙이기가 본문으로 인정하는 유형. `footnote` 가 뒤늦게 들어왔다 — 주석 구간에서
# 한 항목이 footnote / p / quote 로 번갈아 분류되는데(글꼴로 유형을 정하니 항목 안에서
# 흔들린다), 유형이 다르면 잇지 않는 규칙 탓에 주석이 통째로 갈려 있었다. 244쪽 책에서
# 문장 중간 끊김 52곳 중 39곳이 이것이었다.
BODY = ("p", "quote", "figcaption", "footnote")

# `1 Wolpe and Rachman (1960), …` — 번호로 시작하면 새 주석 항목이다. 이어붙이기가
# 주석끼리 삼키지 않게 막는 유일한 근거이므로, footnote 를 본문에 넣은 대가로 함께 온다.
NOTE_START_RE = re.compile(r"^\s*\d{1,3}[.)]?\s+\S")


def starts_note(s: str) -> bool:
    """새 주석 항목의 시작인가."""
    return bool(NOTE_START_RE.match(s))


def merged_type(a: str, b: str) -> str:
    """서로 다른 유형을 이어붙일 때 남는 유형.

    캡션과 주석은 자기 자리를 지킨다 — 둘 다 본문 흐름 **밖**에 놓이는 글이라,
    합치면서 `p` 로 바꾸면 도판 설명이나 주석이 본문 한가운데로 들어온다.
    나머지 불일치는 본문이 이긴다(본문으로 흘러드는 인용은 애초에 본문이었다)."""
    for keep in ("figcaption", "footnote"):
        if a == keep or b == keep:
            return keep
    return "p"


def join_src(prev: str, nxt: str) -> str:
    """Join two halves of one paragraph, undoing a justification hyphen only."""
    a, b = prev.rstrip(), nxt.lstrip()
    if a[-1:] in HYPHENS and len(a) > 2 and a[-2].islower() and b[:1].islower():
        return a[:-1] + b        # re- + counting -> recounting
    if a[-1:] in HYPHENS[1:]:
        return a[:-1] + "-" + b  # a compound the OCR wrote with ¬
    return a + " " + b           # self- + assessment keeps its hyphen


def demote_numbered_items(blocks) -> int:
    """굵은 번호로 시작하는 문항이 각주·제목으로 오분류된 것을 본문으로 되돌린다.

    자기평가 문항 같은 번호 목록은 번호만 굵어서 폰트 신호가 흔들리고, 실제로
    한 책에서 문항 여덟 개가 전부 footnote 로 분류됐다. footnote 는 stitch 의
    본문 유형에 들지 않아 쪽·줄 경계로 쪼개진 문항이 이어지지도 못한다 —
    그래서 stitch **전에** 돌려야 한다. 진짜 각주는 `[14]` 처럼 대괄호 마커로
    시작하므로 걸리지 않는다. 60자 미만의 짧은 번호 제목(`1. Introduction`)도
    남긴다."""
    n = 0
    for b in blocks:
        if (str(b.get("type", "")) in ("footnote", "h1", "h2", "h3")
                and re.match(r"^\d+[.)] ", b.get("src", ""))
                and len(b["src"]) >= 60
                and not b["src"].startswith("[")):
            b["type"] = "p"
            n += 1
    return n


def stitch_blocks(blocks):
    """Rejoin paragraphs that the page break, or a stray style shift, split in two.

    `merge_paragraphs()` runs one page at a time and cannot see across the seam, so
    a paragraph running over a page boundary always came out as two blocks. It is
    the most common structural break in a book — a 191-page book had 88 of them, and
    21 were split mid-word (`worth re-` / `counting. Matter-of-factly…`). Translating
    the halves separately gives the model a fragment with no subject.

    This used to live in `pagecheck.py`, which costs a vision call per page. Most
    runs never get there, so the extractor shipped these breaks downstream. The rule
    is deterministic and needs no model.

    The evidence required differs by where the seam is:

    * **Across a page break** the earlier block ending with no terminal punctuation
      is enough. Demanding that the continuation start lowercase would miss every
      paragraph that breaks before a proper noun (`…a position at Harvard` /
      `University. My intention…`).
    * **Within one page** the extractor had a positive reason to split — a wide gap
      or a font change — so overriding it needs more: either a hyphen at the break
      or a continuation that starts lowercase — `continues_sentence()`, which looks
      past an opening quote or bracket before deciding.

    Body, quote and figcaption are all accepted because the type classifier is the
    least reliable part of the extractor. When the two disagree the merged block
    becomes a paragraph: a quote that flows into body text was body text all along.
    A caption is the exception — `Figure 3. … Visual acuity beautifully` / `tracks the
    density of cone cells…` is one caption the layer broke in half, and calling the
    result a paragraph would drop it into the reading flow as body text."""
    out: list[dict] = []
    n = 0
    prev = None                      # 마지막으로 **읽는 글**인 블록. 아래 참조.
    for b in blocks:
        # 읽지 않는 블록(뷰어 부속물·쪽 번호·색인)은 이음매를 끊지 않는다.
        # 예전에는 바로 앞 블록을 봤는데, 문장 한가운데에 `Page 60 of 252 · 3%` 가
        # 끼면 두 반쪽이 영영 이웃이 되지 못했다. 목록에서 빼지는 않는다(ID 불변) —
        # 이음매를 찾을 때만 없는 것으로 친다. 쪽 인접 조건이 그대로 남아 있어
        # 색인처럼 긴 구간을 건너뛰어 엉뚱한 것끼리 붙는 일은 생기지 않는다.
        if not b.get("translate", True):
            out.append(b)
            continue
        if (prev and prev["type"] in BODY and b["type"] in BODY
                and not starts_note(b["src"])
                and not TERMINAL_RE.search(prev["src"])):
            across = b["page"] == prev["page"] + 1
            same_page = b["page"] == prev["page"]
            continues = continues_sentence(b["src"])
            # 분철 하이픈으로 끝났는데 다음이 대문자로 시작하면 그 블록은 낱말의
            # 나머지가 아니다 — 레이어가 다음 페이지 첫 조각을 잃었거나 제목이
            # 섞여 든 것이다. 실제로 `…a diffi¬` 뒤에 제목+문항 융합 블록이 붙어
            # `diffiQuestions…` 가 됐다. 잇지 말고 두는 쪽이 복구 가능하다.
            fused = prev["src"].rstrip()[-1:] in HYPHENS and b["src"][:1].isupper()
            if not fused and (across or (same_page and (prev["src"].rstrip().endswith("-") or continues))):
                prev["src"] = join_src(prev["src"], b["src"])
                if prev["type"] != b["type"]:
                    prev["type"] = merged_type(prev["type"], b["type"])
                prev["stitched"] = True
                n += 1
                continue
        out.append(b)
        prev = b
    return out, n


# ---------- heading levels ----------

# 숫자·로마숫자만 보면 "PART ONE" 같은 영단어 수사를 놓친다 — 실제 책(The Mind
# Is Flat)에서 PART ONE/TWO 가 h1 로 올라가지 못해 목차가 평평해졌다.
_WORD_NUM = ("one|two|three|four|five|six|seven|eight|nine|ten|eleven|twelve|"
             "thirteen|fourteen|fifteen|sixteen|seventeen|eighteen|nineteen|twenty")
CHAPTER_MARK_RE = re.compile(
    r"^(chapter|part|book|section|lecture)\s+([0-9]{1,3}|[ivxlcdm]{1,7}|"
    + _WORD_NUM + r")\b",
    re.I)

# 장과 나란히 서는 앞뒤 부속물. 소문자·구두점 제거 후 비교한다.
TOP_LEVEL_TITLES = {
    "contents", "table of contents", "introduction", "prologue", "epilogue",
    "preface", "foreword", "afterword", "conclusion", "acknowledgments",
    "acknowledgements", "notes", "index", "bibliography", "about the author",
    "appendix", "dedication", "epigraph",
}


_TOC_TITLES = {"contents", "table of contents", "목차", "차례"}

# 접두어 없이 수사만 선 제목 — 「ONE」·「7」·「IV」. 본문 조판에서 「CHAPTER」를
# 빼고 서수만 큼직하게 얹는 책이 흔하다. 이것을 장으로 안 보면 뒤따르는 진짜
# 제목과 레벨이 어긋나 목차에서 둘로 갈린다(실측: no_self_no_problem 은
# 「ONE」이 h2, 「Meet the Interpreter…」가 h1 이라 병합 조건에 못 걸렸다).
_BARE_NUM_RE = re.compile(
    r"^(\d{1,3}|[ivxlcdm]{1,6}|" + _WORD_NUM + r")[.:]?$", re.I)

# 「EXHIBIT 2.1」·「Figure I.3」·「Table 4」 — 도판에 붙은 번호표뿐인 제목.
# 절 제목이 아니라 캡션이므로 목차에 실리면 안 된다.
_FIG_LABEL_HEAD_RE = re.compile(
    r"^(figure|fig\.?|table|plate|chart|exhibit|box|panel|도표|그림|표)\s*"
    r"[\dIVXLCivxlc]+([.\-–—]\d+)*[.:]?$", re.I)

# 「CHAPTER 2THE LAST GENERATION」 — 번호와 제목이 붙어 버린 것.
_GLUED_MARK_RE = re.compile(
    r"^((?:chapter|part|book|section|lecture|appendix)\s+\d{1,3})(?=[A-Za-z])", re.I)
# 번역 쪽도 같이 붙는다 — 「챕터 13구축 이전에」·「16장오케스트레이터는 …」.
_GLUED_MARK_KO_RE = re.compile(
    r"^((?:제\s*)?\d{1,3}\s*[장부편]|(?:챕터|파트|섹션)\s*\d{1,3})(?=[가-힣A-Za-z])")


def unglue_label(text: str) -> str:
    """수사와 제목이 공백 없이 붙은 것을 떼어 놓는다.

    붙어 있으면 `\\b` 가 깨져 장으로 안 읽힌다(실측:
    the_human_agent_orchestrator 의 2·3·5·13·15·16·18·19장이
    「CHAPTER 2THE LAST GENERATION」 꼴이라 목차에서 통째로 빠졌다)."""
    if not text:
        return text
    return _GLUED_MARK_KO_RE.sub(r"\1 ", _GLUED_MARK_RE.sub(r"\1 ", text))

# 「… 47」·「… . . . 47」 — 목차 항목 끝의 쪽번호.
_PAGE_TAIL_RE = re.compile(r"[\s.·…—–-]*\d{1,4}$")
# 「CHAPTER 1:」·「PART ONE —」·「Lecture 3.」 — 앞머리 수사.
_LEAD_MARK_RE = re.compile(
    r"^(chapter|part|book|section|lecture|appendix)\s+"
    r"([0-9]{1,3}|[ivxlcdm]{1,7}|" + _WORD_NUM + r")\b[\s.:)\]—–-]*", re.I)
# 「1 Systems…」·「13: Before…」·「1.9.1 The…」 — 앞머리 번호.
_LEAD_DIGIT_RE = re.compile(r"^\d{1,3}(?:\.\d{1,3})*\s*[.:)\]]?\s+")
# 별행 번호 깊이 — 「1.1」은 두 단, 「1.9.1」은 세 단.
_DOTTED_RE = re.compile(r"^(\d{1,3})((?:\.\d{1,3})+)\s")


def toc_key(text: str) -> str:
    """목차 항목과 본문 제목을 맞대 볼 수 있게 접는다.

    수사와 쪽번호를 떼고 글자만 남긴다. 인쇄된 목차는 「1 Systems and
    Experiments」 한 줄인데 본문은 「Lecture 1」과 「Systems and Experiments」
    두 블록으로 나오는 일이 흔하다 — 수사를 떼야 뒤쪽이 맞물린다."""
    t = re.sub(r"\s+", " ", text).strip()
    t = _PAGE_TAIL_RE.sub("", t)
    t = _LEAD_MARK_RE.sub("", t)
    t = _LEAD_DIGIT_RE.sub("", t)
    return re.sub(r"[^0-9a-z가-힣]+", "", t.lower())


def _toc_entry_is_numbered(text: str) -> bool:
    """목차 항목이 번호를 달고 있는가 — 「CHAPTER 1: …」·「13: …」·「1 Systems …」."""
    t = re.sub(r"\s+", " ", text).strip()
    return bool(CHAPTER_MARK_RE.match(t)
                or re.match(r"^\d{1,3}(\.\d{1,3})*\s*[:.]?\s+\S", t))


def _toc_entry_is_top(text: str) -> bool:
    """인쇄된 목차 **안에서** 이 항목이 최상위인가.

    목차는 평평하지 않다 — 실측한 네 권 모두 「SECTION ONE: …」/「CHAPTER 1: …」
    아래에 들여쓴 하위 항목을 달고 있었다. 들여쓰기 좌표는 이 단계에 남아 있지
    않으므로(블록에 bbox 가 없다) 글로만 가른다: **번호가 붙었거나** 장과 나란히
    서는 부속물(Preface·Introduction…)이면 최상위, 나머지는 하위."""
    t = re.sub(r"\s+", " ", text).strip()
    if CHAPTER_MARK_RE.match(t):
        return True
    # 「13: Before You Build」·「1 Systems and Experiments」. 「1.1 …」은 제외.
    if re.match(r"^\d{1,3}\s*[:.]?\s+\S", t) and not re.match(r"^\d+\.\d", t):
        return True
    low = t.lower().strip(" .:·—–-")
    # 「Introduction: Your guide to Rewired」·「Foreword by Marshall Goldsmith」
    head = re.split(r"[:—–]", low, 1)[0].strip()
    return (low in TOP_LEVEL_TITLES or head in TOP_LEVEL_TITLES
            or head.split(" by ")[0].strip() in TOP_LEVEL_TITLES)


def _looks_like_toc_entry(text: str) -> bool:
    """목차 항목인가, 흘러넘친 본문인가.

    목차 쪽 판정이 헐거우면 뒤쪽 본문까지 항목으로 삼킨다(실측: no_self 의
    목차가 「Notes and References」 뒤로 본문 산문까지 이어졌다). 길면서 문장으로
    끝나는 것은 항목이 아니다."""
    t = re.sub(r"\s+", " ", text).strip()
    if not t or len(t) > 130:
        return False
    return not (len(t) > 80 and re.search(r"[.!?][\"')\]]?$", t))


def toc_pages(book_blocks) -> set:
    """인쇄된 목차가 실린 쪽들. 없으면 빈 집합.

    Contents 표제가 선 쪽부터, **항목처럼 생긴 줄로 채워진** 연속 쪽까지(여러
    쪽에 걸친 목차).

    유형은 보지 않는다. 예전에는 「제목 블록 3개 이상」으로 이어 붙였는데, 그러면
    한 번 정규화한 책을 **다시 손볼 수 없다** — 그때 항목이 이미 본문으로 내려가
    있어 둘째 쪽부터 끊긴다(실측: the_human_agent_orchestrator 의 목차 27줄 중
    5줄만 거둬졌고, 그 부실한 정답지 탓에 멀쩡한 제목이 그림 제목으로 몰렸다)."""
    start = None
    for i, b in enumerate(book_blocks):
        t = re.sub(r"\s+", " ", b.get("src", "")).strip()
        if len(t) < 25 and t.lower().strip(" .:·—–-") in _TOC_TITLES:
            start = i
            break
    if start is None or book_blocks[start].get("page") is None:
        return set()
    by_page: dict = {}
    for b in book_blocks:
        if b.get("src", "").strip() and b.get("page") is not None:
            by_page.setdefault(b["page"], []).append(b.get("src", ""))
    # 앞머리 안내용 목록이 책의 6%를 넘지는 않는다. 짧은 줄로 채워진 본문 쪽에
    # 끌려가는 것을 막는 마지막 그물이다 — 평소에는 걸리지 않는다.
    limit = max(6, len(by_page) // 16)
    pages = {book_blocks[start]["page"]}
    p = book_blocks[start]["page"]
    while True:
        p = _next_page(p)
        rows = by_page.get(p) if p is not None else None
        # 6줄은 넘어야 목차의 계속으로 본다. 3줄로 두면 **표제지가 딸려
        # 들어간다** — rewired 의 p18 은 「REWIRED」·부제·판권 세 줄이 다 짧아
        # 항목처럼 보인다. 강등만 할 때는 무해했지만 목차 쪽을 본문에서 빼는
        # 지금은 책 제목을 통째로 잃는다.
        if not rows or len(rows) < 6:
            break
        if sum(_looks_like_toc_entry(r) for r in rows) < len(rows) * 0.8:
            break
        pages.add(p)
        if len(pages) >= limit:
            break
    return pages


def _next_page(p):
    """쪽 번호의 다음 값. book.json 은 쪽을 문자열로 담기도 한다."""
    try:
        return type(p)(int(p) + 1)
    except (TypeError, ValueError):
        return None


def harvest_printed_toc(book_blocks):
    """인쇄된 목차를 정답지로 거둔다 — `(최상위 열쇠, 하위 열쇠, 목차 쪽)`.

    독자가 목차를 볼 때 쓰는 근거를 그대로 쓴다. 판독기는 쪽마다 따로 읽으므로
    같은 종류의 제목이 쪽에 따라 다른 레벨을 받지만, **책이 스스로 적어 둔
    목차**는 한 곳에 모여 있고 계층이 이미 정해져 있다."""
    pages = toc_pages(book_blocks)
    if not pages:
        return set(), set(), pages
    top, sub, numbered = set(), set(), 0
    for b in book_blocks:
        if b.get("page") not in pages:
            continue
        src = b.get("src", "")
        if not _looks_like_toc_entry(src):
            continue
        key = toc_key(src)
        if len(key) < 3 or key in _TOC_TITLES:
            continue
        if _toc_entry_is_numbered(src):
            numbered += 1
        (top if _toc_entry_is_top(src) else sub).add(key)
    # 번호가 거의 없는 목차는 **평평하다** — 계층이 없는 것이지, 항목이 죄다
    # 하위인 것이 아니다. 그런 책에서 번호로 위아래를 가르면 정확히 거꾸로
    # 뒤집힌다(실측: beyond_weird 는 장 20개가 전부 번호 없는 문장형 제목이라
    # 하위로 몰리고, Notes·Index 넷만 최상위가 되어 책에 장이 사라졌다).
    if numbered < 3:
        return top | sub, set(), pages
    return top, sub - top, pages


def demote_printed_toc(book_blocks) -> int:
    """인쇄된 목차 페이지의 항목을 본문으로 내린다.

    비전·chunks 판독은 목차 페이지의 항목 하나하나를 제목으로 읽는다. 그대로
    두면 앱 목차에 같은 목차가 두 벌 실린다 — 목차 페이지 판과 본문 제목 판.
    Contents 표제가 선 쪽부터, 제목 블록이 3개 이상 몰린 연속 쪽까지를 목차로
    보고(여러 쪽에 걸친 목차) 그 안의 제목을 전부 본문으로 내린다. 목차 쪽에는
    목차 항목 말고 다른 제목이 없다. 글 자체는 남는다 — 지우면 쪽 대조가 깨진다.

    표제 자체는 제목으로 남긴다. 목차도 책의 한 부분이라 앱 목차에서 그리로
    갈 수 있어야 한다."""
    pages = toc_pages(book_blocks)
    if not pages:
        return 0
    changed = 0
    seen_head = False
    for b in book_blocks:
        if b.get("page") not in pages:
            continue
        t = re.sub(r"\s+", " ", b.get("src", "")).strip()
        if not seen_head and t.lower().strip(" .:·—–-") in _TOC_TITLES:
            seen_head = True
            continue
        if seen_head and str(b.get("type", "")).startswith("h"):
            b["type"] = "p"
            changed += 1
    return changed


_BULLET_RE = re.compile(r"(?<!^)(?<![\n])\s*(?=[•▪◦‣]\s)")
# 「… 앞 항목. 2. 다음 항목」 — 문장이 끝난 뒤에 오는 번호만 본다.
_ORDERED_RE = re.compile(
    r"(?:(?<=[.!?:”\"'\)])|(?<=[.!?:]\s))\s+(\d{1,2})[.)]\s+(?=[A-Z“\"'가-힣])")


def split_inline_lists(text: str) -> str:
    """한 문단에 뭉쳐 온 목록 항목 사이에 줄바꿈을 넣는다.

    판독기는 불릿 목록을 문단 하나로 접어 준다 — 「• 첫째 … • 둘째 … • 셋째」가
    한 블록에 붙어 오고, 리더는 줄바꿈이 없으니 통짜 문단으로 그린다(실측: 정본
    여덟 권에서 불릿 180블록, 번호 목록 64블록).

    **항목을 블록으로 쪼개지는 않는다.** 대역 리더는 블록끼리 원문·번역을
    짝짓는데 번역이 항목 수를 그대로 지킨다는 보장이 없다(개조식은 특히 합치는
    쪽으로 기운다). 한 블록에 담긴 채로 줄만 나누는 것이 짝맞춤을 지킨다.

    번호 목록은 **번호가 연달아 이어질 때만** 나눈다. 그러지 않으면 「… 1929년.
    2. 차례로」처럼 본문 속 숫자를 목록으로 오인한다."""
    if not text:
        return text
    nums = [int(m.group(1)) for m in _ORDERED_RE.finditer(text)]
    if len(nums) >= 2 and nums == list(range(nums[0], nums[0] + len(nums))):
        text = _ORDERED_RE.sub(lambda m: "\n" + m.group(1) + ". ", text)
    if len(re.findall(r"[•▪◦‣]\s", text)) >= 2:
        text = _BULLET_RE.sub("\n", text)
    return re.sub(r"\n{2,}", "\n", text).strip()


def split_lists_in_blocks(book_blocks, field: str = "src") -> int:
    """`split_inline_lists` 를 본문 블록에 먹인다. 바꾼 블록 수를 돌려준다."""
    changed = 0
    for b in book_blocks:
        if str(b.get("type", "")) not in ("p", "quote"):
            continue
        v = b.get(field)
        if not v:
            continue
        nv = split_inline_lists(v)
        if nv != v:
            b[field] = nv
            changed += 1
    return changed


_FIGURE_TYPES = {"figure", "image", "picture", "figcaption"}


def _demote_figure_titles(book_blocks, toc_keys) -> int:
    """그림 **안에** 인쇄된 제목을 본문으로 내린다.

    도판 위에 큼직하게 얹힌 제목을 판독기가 절 제목으로 올린다(실측: 양자역학
    책 33쪽의 「Complex Numbers」는 그림 1.6 의 그림틀 안에 든 글자였고, 그
    바로 아래가 「Figure 1.6: Two Common Ways to Represent Complex Numbers」
    였다). 그대로 두면 목차에 있지도 않은 절이 생긴다.

    조건을 넷 다 만족할 때만 내린다 — 바로 다음이 **설명이 달린** 그림이고,
    번호가 없고, **인쇄된 목차에 없다**. 목차를 못 찾았으면 아무것도 하지 않는다:
    근거 없이 내리면 진짜 절 제목을 잃는다.

    설명(figcaption)까지 요구하는 것이 핵심이다. 「바로 다음이 그림」만으로는
    도판을 여는 진짜 절 제목까지 걷어낸다(실측: rewired 의 「SECTION ONE …」이
    그림을 데리고 있어 본문으로 내려갔다). 틀 안에 제목을 인쇄하는 도판은
    거의 예외 없이 아래에 「Figure 1.6: …」 같은 설명을 단다."""
    if len(toc_keys) < 5:
        return 0
    changed = 0
    for i, b in enumerate(book_blocks[:-2]):
        if not str(b.get("type", "")).startswith("h"):
            continue
        nxt = str(book_blocks[i + 1].get("type", ""))
        if nxt not in _FIGURE_TYPES or nxt == "figcaption":
            continue
        if str(book_blocks[i + 2].get("type", "")) != "figcaption":
            continue
        text = re.sub(r"\s+", " ", b.get("src", "")).strip()
        if _DOTTED_RE.match(text) or CHAPTER_MARK_RE.match(text):
            continue
        if re.match(r"^\d{1,3}\s*[:.]?\s+\S", text):
            continue
        key = toc_key(text)
        if key and key not in toc_keys:
            b["type"] = "p"
            changed += 1
    return changed


LABEL_SEP = " · "
_MARK_WORD = r"(?:chapter|part|book|section|lecture|appendix)"
_MARK_KO = r"(?:제\s*\d{1,3}\s*[장부편]|\d{1,3}\s*[장부편]|(?:챕터|파트|섹션)\s*\d{1,3})"
_NUM_TOKENS = (r"\d{1,3}", r"[ivxlcdm]{1,7}", _WORD_NUM)


def _label_splits(text: str):
    """「CHAPTER 2THE LAST…」에서 (수사, 제목) 후보를 길이 순으로 내놓는다.

    수사 길이를 하나로 못 정한다 — 로마자는 제목 첫 글자를 삼킨다
    (「PART IIDIFFERENT…」의 D 도 로마자라 탐욕 매칭이 「IIDI」+「FFERENT」로
    끊는다). 후보를 다 내놓고 **인쇄 목차와 맞는 것**을 고르게 한다."""
    # 번호 없는 맨 낱말 수사 — 「INTRODUCTIONTHE PERFECT AI …」. 가를 근거는
    # 인쇄 목차뿐이라(글자만으로는 어디까지가 수사인지 모른다) 후보만 내놓고
    # 목차와 맞을 때만 채택된다.
    for w in TOP_LEVEL_TITLES:
        # **붙어 있을 때만**이다. 「PREFACE: THE LAST GENERATION」처럼 이미
        # 갈려 있는 것은 읽는 데 지장이 없고, 손대면 「FOREWORD BY MARSHALL
        # GOLDSMITH」가 「FOREWORD · BY MARSHALL GOLDSMITH」가 된다 — 뒤가
        # 제목이 아니라 딸린 말인 경우를 가려낼 방법이 없다.
        if (len(text) > len(w) and text[:len(w)].lower() == w
                and text[len(w)].isalnum()):
            yield text[:len(w)], text[len(w):], True   # 목차가 맞장구쳐야 채택

    m = re.match(_MARK_WORD + r"\s+", text, re.I)
    if not m:
        return
    head, rest = text[:m.end()].rstrip(), text[m.end():]
    for pat in _NUM_TOKENS:
        mm = re.match(pat, rest, re.I)
        if not mm:
            continue
        full = mm.group(0)
        # 긴 후보부터 — 「IV」가 「I」보다 먼저 시험된다
        for n in range(len(full), 0, -1):
            tail = rest[n:].lstrip(" \t:.—–-")
            if tail:
                yield f"{head} {rest[:n]}", tail, False


def canonical_label_headings(book_blocks) -> int:
    """수사가 붙은 제목을 「수사 · 제목」 한 꼴로 맞춘다.

    원본 조판은 제각각이다 — 「CHAPTER 2THE LAST GENERATION」(붙음),
    「Chapter 1: Meet the Interpreter…」(콜론), 「Part I — Foundational…」(줄표),
    「SECTION ONECreating the Transformation Roadmap」(붙음). 목차에서도 본문에서도
    같은 꼴로 보이는 편이 낫고, 붙어 있으면 아예 장으로 읽히지도 않는다.

    **가르는 자리는 인쇄 목차가 정한다.** 로마자·영문 서수는 제목 첫 글자를
    삼켜서 글자만 보고는 못 가른다. 목차에 맞는 후보가 없으면 원래 띄어쓰기가
    있던 자리로 물러선다 — 근거 없이 자르지는 않는다.

    번역문에도 같은 꼴을 먹인다(「제2장 마지막 세대」 → 「제2장 · 마지막 세대」)."""
    top, sub, pages = harvest_printed_toc(book_blocks)
    entry_keys = top | sub
    # 목차 항목이 「INTRODUCTION: The Perfect AI …」처럼 맨 낱말 수사를 달고
    # 있으면 그 수사를 뗀 열쇠도 만들어 둔다. 본문 쪽은 「INTRODUCTIONTHE
    # PERFECT AI …」로 붙어 오므로 뗀 것끼리 맞대야 자리가 잡힌다.
    for b in book_blocks:
        if b.get("page") not in pages:
            continue
        t = re.sub(r"\s+", " ", b.get("src") or "").strip()
        for w in TOP_LEVEL_TITLES:
            if len(t) > len(w) and t[:len(w)].lower() == w:
                k = toc_key(t[len(w):].lstrip(" \t:.—–-"))
                if len(k) >= 3:
                    entry_keys.add(k)
    changed = 0
    for b in book_blocks:
        if not re.fullmatch(r"h[1-6]", str(b.get("type", ""))):
            continue
        src = re.sub(r"\s+", " ", b.get("src") or "").strip()
        if not src or LABEL_SEP in src:
            continue
        best = None
        for label, title, needs_toc in _label_splits(src):
            # 목차와 맞으면 곧바로 채택, 아니면 원래 띄어쓰기 자리로 물러선다
            if entry_keys and toc_key(title) in entry_keys:
                best = (label, title)
                break
            if needs_toc:
                continue        # 번호 없는 맨 낱말은 목차 말고 근거가 없다
            if best is None and re.match(re.escape(label) + r"[\s:.—–-]", src):
                best = (label, title)
        if not best:
            continue
        new = best[0] + LABEL_SEP + best[1]
        if new != src:
            b["src"] = new
            changed += 1
        # 번역은 **원문이 갈렸을 때만** 손댄다. 따로 보면 원문에 수사가 없는데도
        # 번역에만 생긴 것을 가른다(실측: signals 의 「Note」가 「2장 주석」으로
        # 옮겨져 있어 「2장 · 주석」이 됐다 — 원문에는 장 번호가 없다).
        ko = re.sub(r"\s+", " ", b.get("ko") or "").strip()
        if ko and LABEL_SEP not in ko:
            km = re.match(_MARK_KO + r"[\s:.—–-]*", ko)
            if km and ko[km.end():].strip():
                b["ko"] = km.group(0).rstrip(" :.—–-") + LABEL_SEP + ko[km.end():].strip()
                changed += 1
    return changed


_PART_MARK_RE = re.compile(r"^(part|book|section)\s+\S", re.I)
_CHAP_MARK_RE = re.compile(r"^(?:(?:chapter|lecture)\s+\S|\d{1,3}[\s:.])", re.I)


def part_and_chapter_keys(book_blocks):
    """인쇄 목차에서 **부(部) 계열**과 **장(章) 계열**의 열쇠를 갈라 낸다.

    나란히 두 계열이 돌면 그것은 두 단이라는 뜻이다 — 「PART I…IV」와
    「CHAPTER 1…19」가 함께 있으면 장은 부 아래다(실측: 여덟 권 중 네 권이
    그렇다). 목차의 들여쓰기 좌표는 이 단계에 없지만, **번호 체계가 둘이라는
    사실 자체가 증거**다. 추측이 아니라 책이 스스로 매긴 것이다.

    **판정은 목차 항목으로 한다. 본문 글로 하면 안 된다** — 본문은 번호를 떼고
    제목만 찍는 일이 흔하다(the_mind_is_flat 의 목차는 「1 The Power of
    Invention」인데 본문 제목은 「The Power of Invention」이다). 본문 글만 보면
    장으로 안 읽혀 앞부속과 같은 단에 서고, 앞부속은 거꾸로 장 취급을 받는다."""
    pages = toc_pages(book_blocks)
    parts, chaps = set(), set()
    for b in book_blocks:
        if b.get("page") not in pages:
            continue
        t = re.sub(r"\s+", " ", b.get("src") or "").strip()
        if not _looks_like_toc_entry(t):
            continue
        # 부는 **꼴로만** 센다. 「PART ONE」은 수사를 떼면 열쇠가 비어 길이
        # 필터에 걸려 사라진다 — 그러면 두 단인 책을 한 단으로 본다.
        if _PART_MARK_RE.match(t):
            parts.add(re.sub(r"\s+", "", t.lower()))
            continue
        k = toc_key(t)
        if len(k) >= 3 and _CHAP_MARK_RE.match(t):
            chaps.add(k)
    if len(parts) < 2 or len(chaps) < 2:
        return set(), set()
    return parts, chaps


def demote_front_cover(book_blocks) -> int:
    """인쇄 목차보다 **앞쪽** 쪽의 제목을 본문으로 내린다.

    표지·속표지·판권에 적힌 큰 글자를 판독기가 제목으로 올린다 — 실측: 양자역학은
    「QUANTUM MECHANICS」가 p1·p3·p5 에 셋, no_self 는 「NO SELF NO PROBLEM」이
    둘, the_meaning_of_your_life 는 표지 넉 줄이 전부 h1 이었다. 목차 맨 위가
    같은 말의 되풀이로 채워진다.

    목차 앞에 진짜 본문이 오는 일은 없다 — 서문도 목차 뒤다. 글은 남기고 유형만
    내리므로 표지 글자는 본문 첫 쪽에 그대로 보인다."""
    pages = toc_pages(book_blocks)
    if not pages:
        return 0
    first = min(pages)
    if not isinstance(first, int):
        return 0
    changed = 0
    for b in book_blocks:
        if (re.fullmatch(r"h[1-6]", str(b.get("type", "")))
                and isinstance(b.get("page"), int) and b["page"] < first):
            b["type"] = "p"
            changed += 1
    return changed


_BACK_MATTER_RE = re.compile(
    r"^(notes?|notes and references|references|bibliography|endnotes|"
    r"further reading|index|주석|참고문헌|미주|찾아보기)$", re.I)


def demote_back_matter(book_blocks) -> int:
    """책 맨 뒤 주석·참고문헌·색인은 **표제만** 목차에 남긴다.

    그 안의 세부 항목이 전부 제목으로 올라와 목차를 뒤덮는다 — 실측:
    no_self 는 「Notes and References」 아래 「Chapter 1 · Meet the Interpreter…」
    처럼 **장 제목이 통째로 다시** 열한 개 서고, signals 는 「Notes to Chapter N」
    열여덟 개, rewired 는 색인 항목(「Agentic systems, 337–339」)이 열두 개다.

    글은 남기고 유형만 본문으로 내린다 — 주석 내용은 읽을 수 있어야 한다.

    **뒤쪽에 있는 것만, 그것도 본문을 삼키지 않는 자리부터 본다.** 장마다
    「Note」를 다는 책이 있어서(rewired 는 p45·p59·p68… 에 널려 있다) 이름만 보고
    지우면 본문 한복판을 헤집는다. 쪽 위치만으로도 모자란다 — rewired 는 80%
    지점 뒤에도 장별 「Notes」가 있어 그것을 시작점으로 잡으면 **35~39장이 통째로
    쓸려 나갔다**(실측 90블록).

    그래서 후보를 **뒤에서부터** 훑으며, 그 구간이 「처음 나오는 목차 항목」을
    삼키면 물러선다. 뒷부속에 되풀이되는 장 제목(no_self 의 주석 항목)은 앞에서
    이미 본 것이라 걸리지 않고, 진짜 본문 장은 처음 나오는 것이라 걸린다."""
    pages = [b["page"] for b in book_blocks if isinstance(b.get("page"), int)]
    if not pages:
        return 0
    cutoff = max(pages) * 0.8
    top_keys, _, _ = harvest_printed_toc(book_blocks)
    heads = [(i, b) for i, b in enumerate(book_blocks)
             if re.fullmatch(r"h[1-6]", str(b.get("type", ""))) and not b.get("dropped")]
    is_back = lambda b: bool(_BACK_MATTER_RE.match(
        re.sub(r"\s+", " ", b.get("src") or "").strip(" .:·—–-")))
    seen: set = set()
    ok_before: dict = {}
    for i, b in heads:                       # 이 자리까지 이미 나온 제목 열쇠
        ok_before[i] = set(seen)
        seen.add(toc_key(b.get("src") or ""))
    start = None
    for i, b in reversed(heads):
        if not (is_back(b) and isinstance(b.get("page"), int) and b["page"] >= cutoff):
            continue
        swallowed = [x for j, x in heads if j > i and not is_back(x)
                     and toc_key(x.get("src") or "") in top_keys
                     and toc_key(x.get("src") or "") not in ok_before[i]]
        if swallowed:
            break                            # 처음 나오는 본문 제목을 삼킨다
        start = i
    if start is None:
        return 0
    changed = 0
    for i, b in heads:
        if i > start and not is_back(b):
            b["type"] = "p"
            changed += 1
    return changed


def merge_label_subtitles(book_blocks) -> int:
    """맨 수사 제목과 **바로 뒤** 부제를 한 제목으로 합친다.

    본문은 「INTRODUCTION」을 큼직하게 얹고 부제를 다음 줄에 두는데, 인쇄
    목차에는 「Introduction: Your guide to Rewired」한 줄로 실린다. 그대로 두면
    목차에 뜻 없는 「INTRODUCTION」만 서고 부제는 절처럼 보인다.

    **예전에는 일부러 안 했다.** 뒤따르는 것이 부제인지 첫 절인지 글자만으로는
    구분이 안 됐기 때문이다(`shared/headings.ts` 의 `isNumberedLabel` 주석).
    이제 **인쇄 목차가 판정한다** — 목차에 「수사: 그 글」로 실려 있을 때만 합친다.

    합친 뒤 부제 블록은 `dropped` 로 감춘다. 글은 제목 안으로 들어갔으니 두면
    같은 말이 두 번 보인다. 지우지 않으므로 되돌릴 수 있다."""
    top, sub, pages = harvest_printed_toc(book_blocks)
    if not pages:
        return 0
    # 「수사 → 그 수사가 목차에서 데리고 있는 부제들」
    tails: dict = {}
    for b in book_blocks:
        if b.get("page") not in pages:
            continue
        t = re.sub(r"\s+", " ", b.get("src") or "").strip()
        for w in TOP_LEVEL_TITLES:
            if len(t) > len(w) and t[:len(w)].lower() == w:
                k = toc_key(t[len(w):].lstrip(" \t:.—–-"))
                if len(k) >= 3:
                    tails.setdefault(w, set()).add(k)
    if not tails:
        return 0
    heads = [b for b in book_blocks
             if re.fullmatch(r"h[1-6]", str(b.get("type", "")))
             and not b.get("dropped") and b.get("page") not in pages]
    changed = 0
    for i, b in enumerate(heads[:-1]):
        word = re.sub(r"\s+", " ", b.get("src") or "").strip().lower().strip(" .:·—–-")
        nxt = heads[i + 1]
        if word not in tails or LABEL_SEP in (b.get("src") or ""):
            continue
        if nxt.get("page") != b.get("page"):
            continue
        title = re.sub(r"\s+", " ", nxt.get("src") or "").strip()
        if toc_key(title) not in tails[word]:
            continue
        b["src"] = re.sub(r"\s+", " ", b["src"]).strip() + LABEL_SEP + title
        ko_a = re.sub(r"\s+", " ", b.get("ko") or "").strip()
        ko_b = re.sub(r"\s+", " ", nxt.get("ko") or "").strip()
        if ko_a and ko_b:
            b["ko"] = ko_a.rstrip(" :.—–-") + LABEL_SEP + ko_b
        nxt["dropped"] = True
        changed += 1
    return changed


def drop_printed_toc(book_blocks) -> int:
    """인쇄된 목차 쪽을 본문에서 뺀다. 목차는 왼쪽 패널이 전담한다.

    앱에는 목차가 이미 왼쪽에 있다. 본문에까지 목차가 실리면 같은 것을 두 벌
    읽게 되고, 대역 리더에서는 그 목차까지 번역돼 돈이 나간다(rewired 는
    p2–p17, **373블록 열여섯 쪽**이 통째로 목차와 도판 목록이다).

    **지우지 않고 `dropped` 만 세운다.** 블록은 `book.json` 에도 `.parallax`
    에도 남고 쪽 대조가 깨지지 않는다 — `DROPPED` 플래그가 목차·본문·번역·
    내보내기에서 이미 걸러 준다. 되돌리려면 플래그만 내리면 된다.

    **마지막 줄은 예외다.** 다음 쪽 첫 글이 목차 마지막 항목에 눌어붙는 일이
    잦다(실측: no_self 는 「Notes and References」에 제사가, 양자역학은
    「Appendix」에 헌사가 붙어 왔다 — 지우면 그 글이 사라진다). 그 쪽의 항목
    길이 중앙값의 2.5배를 넘으면 본문이 섞인 것으로 보고 남긴다."""
    pages = toc_pages(book_blocks)
    if not pages:
        return 0
    on = [b for b in book_blocks
          if b.get("page") in pages and (b.get("src") or "").strip()]
    if not on:
        return 0
    plain = [len(re.sub(r"\s+", " ", b["src"]).strip()) for b in on]
    med = sorted(plain)[len(plain) // 2] or 1
    keep_last = plain[-1] > max(80, med * 2.5)
    changed = 0
    for i, b in enumerate(on):
        if keep_last and i == len(on) - 1:
            continue
        if not b.get("dropped"):
            b["dropped"] = True
            changed += 1
    return changed


def normalize_headings(book_blocks) -> int:
    """제목 레벨을 문서 전체에서 일관되게 만든다.

    레벨이 어긋나는 데에는 하류에서 고칠 수 없는 이유가 있다. extract 는 폰트
    크기로 레벨을 추론하는데 같은 장 제목이라도 쪽마다 조판이 조금씩 다르고,
    `pagecheck --trust vision` 은 한 페이지씩 따로 읽으므로 같은 종류의 제목이
    어느 쪽에 실렸느냐에 따라 다른 레벨을 받는다. 실제로 한 책에서 CHAPTER 1 이
    h3, CHAPTER 2 가 h2, CHAPTER 3 이 h3 로 나왔다. 이 레벨로 목차를 만들면 장이
    그 장에 속한 절보다 아래에 놓인다.

    **책이 스스로 적어 둔 목차를 정답지로 삼는다.** 거의 모든 단행본은 앞머리에
    Contents 를 싣고, 거기엔 판독기가 알 수 없는 것 두 가지가 들어 있다 — 어느
    제목이 장이고 어느 것이 그 아래인지, 그리고 **무엇이 애초에 제목인지**.
    「Systems and Experiments」는 수사가 앞 블록(「Lecture 1」)에 떨어져 있어
    번호가 안 보이지만 목차엔 「1 Systems and Experiments」로 실려 있다.

    목차가 없으면 예전 규칙으로 물러선다 — 두 단계면 충분하다. 더 잘게 나누려면
    추측해야 하는데, 틀린 추측은 평평한 목록보다 나쁘다.

    바꾼 블록 수를 돌려준다."""
    top_keys, sub_keys, _ = harvest_printed_toc(book_blocks)
    part_keys, chap_keys = part_and_chapter_keys(book_blocks)
    shift = 1 if chap_keys else 0
    # 목차가 넉넉히 거둬졌을 때만 3단을 쓴다. 부실한 정답지로 「목차에 없으니
    # 절」이라 우기면 멀쩡한 장이 두 단 아래로 떨어진다.
    deep = len(top_keys) >= 5
    changed = demote_printed_toc(book_blocks)
    changed += _demote_figure_titles(book_blocks, top_keys | sub_keys)
    changed += demote_back_matter(book_blocks)
    changed += demote_front_cover(book_blocks)
    prev = None
    for b in book_blocks:
        if not str(b.get("type", "")).startswith("h"):
            prev = b
            continue
        text = re.sub(r"\s+", " ", b.get("src", "")).strip()
        for fld in ("src", "ko", "ko_raw"):        # 원문·번역 양쪽이 붙는다
            v = b.get(fld)
            if v and unglue_label(v) != v:
                b[fld] = unglue_label(v)
                changed += 1
        text = re.sub(r"\s+", " ", b.get("src", "")).strip()
        # 도판 번호표뿐인 제목은 절 제목이 아니라 캡션이다(실측: rewired 에
        # 「EXHIBIT 2.1」 꼴 74개가 목차에 실려 있었다). 지우지 않고 캡션으로
        # 내린다 — 도판을 가리키는 글이라 본문에는 남아 있어야 한다.
        if len(text) <= 30 and _FIG_LABEL_HEAD_RE.match(text):
            b["type"] = "figcaption"
            changed += 1
            prev = b
            continue
        # 번호 목록 항목이 제목으로 읽힌 것 — 자기평가 문항처럼 굵은 번호로
        # 시작하는 문장을 비전이 쪽마다 다르게 제목으로 올린다(실제로 문항
        # 1~4는 본문, 같은 목록의 5~8만 h2 가 됐다). 번호로 시작하면서 문장
        # 길이면 제목이 아니다. "1. Introduction" 같은 짧은 번호 제목은 남는다.
        if re.match(r"^\d+[.)] ", text) and len(text) >= 60:
            b["type"] = "p"
            changed += 1
            prev = b
            continue
        low = text.lower().strip(" .:·—-")
        key = toc_key(text)
        dotted = _DOTTED_RE.match(text)
        # 부(部)와 장(章)이 따로 번호를 매기는 책에서는 장부터 한 단 내려간다.
        # 부는 그대로 h1 이라 장이 그 아래로 들어간다.
        # 부는 그대로 h1, 장부터 한 단 내려가 그 아래로 들어간다. 앞뒤 부속
        # (Preface·Prologue·Introduction)은 부와 같은 단에 남는다.
        top_is_part = key in part_keys or bool(_PART_MARK_RE.match(text))
        d = 0 if top_is_part else shift
        if dotted:
            # 「1.1」은 두 단, 「1.9.1」은 세 단. 목차보다 잘게 나뉘어 있어
            # Contents 에는 실리지 않지만 번호가 깊이를 그대로 알려 준다.
            want = "h%d" % min(6, 1 + dotted.group(2).count(".") + d)
        elif _BARE_NUM_RE.match(text):
            want = "h%d" % (1 + d)
        elif key and key in top_keys:
            # 목차 최상위라도 장 계열만 내려간다 — 앞뒤 부속은 부와 나란히
            want = "h%d" % (1 + (shift if key in chap_keys else 0))
        elif key and key in sub_keys:
            want = "h%d" % (2 + d)
        elif CHAPTER_MARK_RE.match(text) or low in TOP_LEVEL_TITLES:
            want = "h%d" % (1 + (0 if low in TOP_LEVEL_TITLES else d))
        elif deep:
            # 목차에 실리지 않은 제목은 **목차보다 잔 것**이다. 책이 스스로
            # 「장」이라 부른 것만 목차에 오르므로, 빠진 것은 그 아래 절이다
            # (실측: signals 의 「Who This Is For」, the_mind_is_flat 의
            # 「THE ILLUSION OF EXPLANATORY DEPTH」— 둘 다 장 안의 소제목).
            want = "h%d" % (3 + d)
        else:
            want = "h%d" % (2 + d)
        # "PART ONE" 바로 다음 블록이 같은 쪽의 제목이면 그 부(部)의 부제다
        # ("PART ONE" / "The Illusion of Mental Depth"). h2 로 두면 장처럼 보인다.
        if (prev is not None
                and re.fullmatch(r"h[1-6]", str(prev.get("type", "")))
                and int(prev["type"][1]) < int(want[1])
                and prev.get("page") == b.get("page")
                and CHAPTER_MARK_RE.match(
                    re.sub(r"\s+", " ", prev.get("src", "")).strip())
                and not CHAPTER_MARK_RE.match(text)):
            want = prev["type"]
        if b["type"] != want:
            b["type"] = want
            changed += 1
        prev = b
    return changed + _compact_levels(book_blocks)


def _compact_levels(book_blocks) -> int:
    """건너뛴 제목 단을 메운다 — 앞 제목보다 두 단 넘게 깊어지지 못한다.

    단이 비는 것은 흔하다. 인쇄 목차에 절이 안 실린 책은 「목차에 있음(h1)」과
    「목차에 없음(h3)」 둘로만 갈려 가운데가 빈다. 그대로 두면 목차 트리가 까닭
    없이 한 칸 더 들어간다 — 깊이는 상대적인 것이라 당겨도 잃는 것이 없다.

    책 전체에서 쓰인 단을 모아 한꺼번에 재배치하지 않는다. 그러면 외톨이 하나가
    책 전체를 붙든다(실측: signals 는 h2 가 「Meet the Experts」 딱 하나인데,
    그 하나 때문에 나머지 266개가 h3 에 남아 까닭 없이 두 칸씩 들어갔다).
    앞에서부터 훑으며 열려 있는 조상만 쌓아 두고, 깊이를 그 높이로 매긴다.
    형제는 반드시 같은 깊이를 받는다 — 「앞 제목보다 한 단만」처럼 이웃만 보고
    당기면 같은 줄의 형제가 갈린다(실측: no_self 는 장 아래 절 51개가 첫 하나만
    h2 로 올라오고 나머지 40개가 h3 에 남아 목록이 톱니처럼 됐다)."""
    changed = 0
    stack: list = []
    for b in book_blocks:
        t = str(b.get("type", ""))
        if not re.fullmatch(r"h[1-6]", t):
            continue
        raw = int(t[1])
        while stack and stack[-1] >= raw:
            stack.pop()
        stack.append(raw)
        want = "h%d" % min(6, len(stack))
        if want != t:
            b["type"] = want
            changed += 1
    return changed


def merge_paragraphs(lines, body_size, body_x0, line_gap, args):
    """Merge lines into blocks. Returns [{text,size,bold,italic,x0,gap_before}]."""
    blocks = []
    cur = None
    prev_bottom = None

    for l in lines:
        gap = (l["top"] - prev_bottom) if prev_bottom is not None else 0
        prev_bottom = l["bottom"]

        indented = l["x0"] > body_x0 + body_size * 0.6
        big_gap = gap > line_gap * args.para_gap
        style_shift = cur is not None and (
            abs(l["size"] - cur["size"]) > 0.6 or l["bold"] != cur["bold"])
        ends_sentence = cur is not None and re.search(r'[.!?…"\'\u201d\u2019]\s*$', cur["text"])
        short_last = cur is not None and cur["last_x1"] < body_x0 + (l["x1"] - body_x0) * 0.82

        start_new = (
            cur is None
            or big_gap
            or style_shift
            or (indented and ends_sentence)
            or (short_last and ends_sentence and indented)
        )

        if start_new:
            if cur:
                blocks.append(cur)
            cur = {"text": l["text"].strip(), "size": l["size"], "bold": l["bold"],
                   "italic": l["italic"], "x0": l["x0"], "last_x1": l["x1"],
                   "gap_before": gap, "top": l["top"]}
        else:
            joined = dehyphenate(cur["text"], l["text"].strip())
            cur["text"] = joined if joined else cur["text"] + " " + l["text"].strip()
            cur["last_x1"] = l["x1"]
    if cur:
        blocks.append(cur)
    return blocks


# ---------- classification ----------

def classify(b, body_size, body_x0, outline_titles, args):
    text = b["text"].strip()
    norm = re.sub(r"\s+", " ", text).lower()

    if norm in outline_titles:
        return "h1"
    if FIGCAP_RE.match(text):
        return "figcaption"
    if b["size"] < body_size * 0.92 and re.match(r"^[\d*†‡]{1,3}[.\s)]", text):
        return "footnote"

    ratio = b["size"] / body_size
    score = 0
    if ratio >= args.heading_ratio:
        score += 2
    if b["bold"] and ratio > 0.98:
        score += 1
    if len(text) < 80:
        score += 1
    if not re.search(r"[.!?]\s*$", text):
        score += 1
    if CHAPTER_RE.match(text):
        score += 2
    if text.isupper() and len(text) < 60:
        score += 1

    if score >= 4:
        if ratio >= args.heading_ratio * 1.25:
            return "h1"
        return "h2" if ratio >= args.heading_ratio else "h3"

    if b["x0"] > body_x0 + body_size * 1.4 or (b["italic"] and len(text) < 400):
        return "quote"
    return "p"


# ---------- 도판 부스러기 ----------
#
# 스캔본의 텍스트 레이어는 그림 안에 인쇄된 글자까지 본문과 똑같이 뱉는다 —
# 축 눈금, 범례, 지도 지명, 화살표 옆 낱말. 자리를 잃으면 읽을 수 없는 조각인데
# 블록으로는 멀쩡해 보여서 번역까지 흘러간다. 여기서 걸러 두면 비전 호출 없이
# 돌린 판본에서도 나오지 않는다. pagecheck 의 `figure`·`garbled` 판정이 같은
# 규칙을 쓴다 — 한쪽을 고치면 다른 쪽도.

VOWEL_RE = re.compile(r"[aeiouy]", re.I)
FIGURE_LABEL_RE = re.compile(
    r"\(?\s*(?:figure|fig\.?|table|plate|chart|exhibit|그림|표|도표)\s*"
    r"[\divxlcIVXLC]{0,6}\s*[.):]?\s*", re.I)
PANEL_LETTER_RE = re.compile(r"\(\s*[a-zA-Z]\s*\)")


def is_figure_label(text: str) -> bool:
    """`Figure 4` · `Fig. 2` · `Table 3` · `그림 1` · `(b)` — 그림에 붙은 번호표만.
    번호 뒤로 문장이 이어지는 진짜 캡션은 길이에서 걸러진다."""
    t = text.strip()
    return len(t) <= 20 and bool(
        FIGURE_LABEL_RE.fullmatch(t) or PANEL_LETTER_RE.fullmatch(t))


def _wordlike(tok: str) -> bool:
    """낱말로 읽히는 토막인가. 눈금값·기호·판독 잔해는 여기서 떨어진다."""
    core = re.sub(r"[^A-Za-z]", "", tok)
    return (len(core) >= 2
            and bool(VOWEL_RE.search(core))
            and not re.search(r"(.{2,4})\1{2,}", core)      # ZINZINZIN
            and not re.search(r"[a-z][A-Z]", core))         # sveriGe


def _is_junk(tok: str) -> bool:
    """낱말이 아닌 정도가 아니라, 글자가 깨졌다는 적극적 증거인 토막.

    숫자와 이름 이니셜(`P.`, `3(2):`)은 여기 들지 않는다 — 참고문헌 한 줄이
    통째로 판독 오류로 몰리던 원인이 그것이었다."""
    core = re.sub(r"[^A-Za-z]", "", tok)
    if not core:
        return not any(c.isdigit() for c in tok)            # ™ ] | — 숫자도 없는 기호
    return bool(re.search(r"(.{2,4})\1{2,}", core)
                or re.search(r"[a-z][A-Z]", core))


def looks_garbled(text: str) -> bool:
    """판독기가 도판이나 활자를 잘못 읽어 낸 글자 뭉치인가.

    두 가지를 함께 요구한다 — 낱말로 읽히는 토막이 절반에 못 미칠 것, 그리고
    글자가 깨졌다는 적극적 증거가 적어도 하나 있을 것. 앞의 조건만으로는
    `5 P. Johansson, L. Hall, B. Tarning …` 같은 참고문헌 줄이 걸린다.

    본문이 걸리는 일이 없어야 하므로 짧은 것만 보고 기준도 느슨하게 잡는다.
    `SVERIGE 75`, `| receptor densi` 처럼 낱말 모양은 갖췄는데 자리를 잃은 조각은
    여기서 못 걸러진다 — 그건 쪽 이미지를 본 비전 모델의 몫이다."""
    t = text.strip()
    if not t or len(t) > 80:
        return False
    if URL_RE.search(t):
        # 주소는 낱말이 아니지만 판독 실패도 아니다. 주소만으로 이루어진 주석
        # (`4 http://www.webexhibits.org/causesofcolor/1G.html.`)이 통째로 걸려
        # 사라지던 자리다 — 슬래시와 점이 많다는 것이 곧 깨졌다는 뜻은 아니다.
        return False
    toks = t.split()
    if not toks:
        return False
    return (sum(_wordlike(w) for w in toks) * 2 < len(toks)
            and any(_is_junk(w) for w in toks))


def should_translate(block_type, text, section_flag):
    if section_flag:
        return False
    if is_figure_label(text) or looks_garbled(text):
        return False
    if block_type == "footnote":
        return True
    if re.fullmatch(r"[\d\s.,:;\-–—/()]+", text):
        return False
    return True


# ---------- main ----------

# ---------- OCR layer for scan-only PDFs ----------

def find_tesseract_cli() -> str | None:
    """PATH 에 없어도 표준 설치 위치를 뒤진다 — Windows 설치기는 PATH 를 안 건드린다."""
    hit = shutil.which("tesseract")
    if hit:
        return hit
    for c in (r"C:\Program Files\Tesseract-OCR\tesseract.exe",
              r"C:\Program Files (x86)\Tesseract-OCR\tesseract.exe"):
        if Path(c).exists():
            return c
    return None


def ensure_text_layer(pdf_path: str, work: Path, lang: str, dpi: int = 300) -> str:
    """텍스트 레이어가 없는 순수 스캔 PDF 에 Tesseract 로 레이어를 입힌 사본을 만든다.

    파이프라인은 텍스트 레이어를 닻으로 쓴다 — 블록 ID·페이지 대응·pagecheck 의
    삽입 기준이 전부 레이어 블록에 걸린다. 레이어가 아예 없으면 비전이 읽은
    텍스트도 붙일 곳이 없어 조용히 버려진다. 글자 품질은 중요하지 않다.
    `--trust vision` 이 어차피 이미지에서 다시 받아쓴다.

    ocrmypdf 가 아니라 Tesseract 를 직접 부른다 — ocrmypdf 는 Ghostscript 가
    필수인데 Windows 에서 그 설치가 가장 큰 장벽이다. Tesseract 의 pdf 출력을
    쪽마다 만들어 PyMuPDF 로 합치면 같은 결과(검색 가능한 PDF)가 나온다.

    레이어가 이미 있으면(쪽당 100자 이상) 원본 경로를 그대로 돌려준다."""
    doc = fitz.open(pdf_path)
    if sum(len(p.get_text()) for p in doc) / max(len(doc), 1) >= 100:
        doc.close()
        return pdf_path

    tess = find_tesseract_cli()
    if not tess:
        sys.exit(f"Scanned PDF with no text layer, and no Tesseract to build one.\n"
                 f"  install:  winget install UB-Mannheim.TesseractOCR\n"
                 f"  or:       extract.py --allow-scanned  (placeholders only)")

    print(f"no text layer — building one with tesseract ({lang}, {dpi}dpi, {len(doc)} pages)",
          flush=True)
    tmp = work / "ocr-layer"
    tmp.mkdir(parents=True, exist_ok=True)
    merged = fitz.open()
    for i, page in enumerate(doc):
        png = tmp / f"p{i:04d}.png"
        base = tmp / f"p{i:04d}"
        page.get_pixmap(dpi=dpi).save(png)
        r = subprocess.run([tess, str(png), str(base), "-l", lang, "--dpi", str(dpi), "pdf"],
                           capture_output=True, text=True)
        if r.returncode != 0:
            sys.exit(f"tesseract failed on page {i+1}: {r.stderr.strip()[:300]}")
        with fitz.open(str(base) + ".pdf") as pg:
            merged.insert_pdf(pg)
        png.unlink()
        Path(str(base) + ".pdf").unlink()
        if (i + 1) % 10 == 0 or i + 1 == len(doc):
            print(f"[{i+1}/{len(doc)}] {int(100*(i+1)/len(doc))}% ocr layer", flush=True)
    doc.close()
    out = work / (Path(pdf_path).stem + ".ocr.pdf")
    merged.save(str(out), garbage=3, deflate=True)
    merged.close()
    tmp.rmdir()
    print(f"-> {out}", flush=True)
    return str(out)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("pdf")
    ap.add_argument("--out", default="work/book.json")
    ap.add_argument("--heading-ratio", type=float, default=1.15,
                    help="font-size multiple over body text that suggests a heading")
    ap.add_argument("--para-gap", type=float, default=1.5,
                    help="line-gap multiple that breaks a paragraph")
    ap.add_argument("--repair-ocr", choices=["auto", "on", "off"], default="auto",
                    help="undo Hangul-for-Latin OCR substitutions in the text layer")
    ap.add_argument("--allow-scanned", action="store_true",
                    help="continue with an empty/thin text layer; pagecheck.py rebuilds it")
    ap.add_argument("--ocr-lang", default="eng",
                    help="tesseract language(s) for the auto-built text layer, e.g. eng+kor")
    ap.add_argument("--translate-all", action="store_true",
                    help="also translate index / bibliography / copyright")
    ap.add_argument("--keep-heading-levels", action="store_true",
                    help="leave h1/h2/h3 as inferred; by default they are flattened to "
                         "h1 (chapter openers) and h2 (everything else) so the table of "
                         "contents is not ordered by whichever page a heading landed on")
    args = ap.parse_args()

    # 순수 스캔이면 Tesseract 로 레이어를 입힌 사본으로 바꿔 탄다. 사본은
    # book.json 옆(작업 폴더)에 남는다 — pagecheck 는 원본 PDF 로 불러도 된다.
    # 쪽 이미지가 같으므로 어느 쪽이든 무방하다.
    orig_pdf = args.pdf   # meta.source 는 사용자가 가진 원본 이름이어야 한다
    if not args.allow_scanned:
        work_dir = Path(args.out).parent
        work_dir.mkdir(parents=True, exist_ok=True)
        args.pdf = ensure_text_layer(args.pdf, work_dir, args.ocr_lang)

    doc = fitz.open(args.pdf)

    outline_titles = {re.sub(r"\s+", " ", t[1]).strip().lower()
                      for t in doc.get_toc(simple=True)}
    print(f"outline entries: {len(outline_titles)}")

    density = cjk_density(doc)
    scanned = scan_backed(doc)
    ocr_layer = density > 0.002 or scanned >= 0.6
    repair = args.repair_ocr == "on" or (args.repair_ocr == "auto" and density > 0.002)
    if density > 0.002:
        print(f"! Hangul/CJK glyphs in {density:.1%} of words — this text layer was OCR'd "
              f"with a Korean language pack")
    if scanned >= 0.6:
        print(f"! {scanned:.0%} of sampled pages are a full-page image with text over it — "
              f"the text layer is OCR output, not the document's own characters")
    if repair:
        print("  repairing Latin letters written as Hangul (판/폰/은 -> e, 나/니 -> u …)")

    pages = [order_lines(page_lines(p), p.rect.width) for p in doc]
    dropped = strip_running_heads(pages, outline_titles)
    if dropped:
        top = " · ".join(f"{t[:40]!r}×{c}" for t, c in dropped.most_common(3))
        print(f"running heads/folios removed: {sum(dropped.values())} lines  ({top})")

    all_lines = [l for p in pages for l in p]
    if not all_lines:
        if not args.allow_scanned:
            sys.exit("no text extracted")
        print("! empty text layer — writing page placeholders for pagecheck.py")
    body_size = (Counter(round(l["size"], 1) for l in all_lines).most_common(1)[0][0]
                 if all_lines else 10.0)
    body_x0 = statistics.median(l["x0"] for l in all_lines) if all_lines else 0.0
    gaps = [b["top"] - a["bottom"] for p in pages for a, b in zip(p, p[1:])
            if 0 < b["top"] - a["bottom"] < 40]
    line_gap = statistics.median(gaps) if gaps else 4.0
    print(f"body size {body_size}pt · x0 {body_x0:.0f} · line gap {line_gap:.1f}")

    raw_blocks, section_flag = [], False
    for pno, lines in enumerate(pages, 1):
        for raw in merge_paragraphs(lines, body_size, body_x0, line_gap, args):
            text = re.sub(r"\s+", " ", raw["text"]).strip()
            if repair:
                text = re.sub(r"\s+", " ", repair_ocr_layer(text)).strip()
            text = repair_soft_hyphens(text)
            if not text:
                continue
            btype = classify(raw, body_size, body_x0, outline_titles, args)
            if btype.startswith("h"):
                low = text.lower().strip()
                section_flag = any(low.startswith(h) for h in SKIP_HINTS)
            raw_blocks.append({
                "type": btype,
                "page": pno,
                "src": text,
                "ko": None,
                "translate": args.translate_all or should_translate(btype, text, section_flag),
            })

    # Stitch before numbering, so IDs stay contiguous and the "IDs are immutable
    # after pagecheck" contract starts from a settled block list.
    # 번호 문항 강등은 stitch 보다 먼저 — footnote 로 오분류된 문항은 본문
    # 유형이 아니라서 쪼개진 반쪽이 이어지지 못한다.
    demote_numbered_items(raw_blocks)
    raw_blocks, stitched = stitch_blocks(raw_blocks)
    # 수사를 먼저 떼어 놓아야 레벨이 그것을 장으로 읽는다
    merged_sub = merge_label_subtitles(raw_blocks)
    labelled = canonical_label_headings(raw_blocks)
    leveled = 0 if args.keep_heading_levels else normalize_headings(raw_blocks)
    listed = split_lists_in_blocks(raw_blocks)
    toc_hidden = drop_printed_toc(raw_blocks)
    blocks = [{"id": f"b{i:04d}", **b} for i, b in enumerate(raw_blocks, 1)]

    book = {
        "meta": {
            "source": Path(orig_pdf).name,
            "title": doc.metadata.get("title") or Path(orig_pdf).stem,
            "author": doc.metadata.get("author") or "",
            "pages": len(doc),
            "register": None,
            # 텍스트 레이어 자체가 OCR 산출물인가. pagecheck 의 --trust 를 무엇으로
            # 둘지는 이 한 가지에 달려 있는데, 지금까지는 화면에 찍고 버려서
            # 사람이 로그를 읽어야만 알 수 있었다. 앱이 물어보려면 값이 필요하다.
            "ocr_layer": ocr_layer,
        },
        "blocks": blocks,
    }

    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(book, ensure_ascii=False, indent=1), encoding="utf-8")

    preview = out.parent / "blocks.txt"
    with preview.open("w", encoding="utf-8") as f:
        for b in blocks:
            mark = " " if b["translate"] else "-"
            f.write(f"{mark}[{b['id']}] ({b['type']:10}) p{b['page']:>3}  {b['src'][:120]}\n")

    kinds = Counter(b["type"] for b in blocks)
    unfinished = sum(1 for b in blocks
                     if b["type"] == "p" and not TERMINAL_RE.search(b["src"]))
    print(f"\n{len(blocks)} blocks -> {out}")
    print("  " + " · ".join(f"{k} {v}" for k, v in kinds.most_common()))
    print(f"  skipped from translation: {sum(1 for b in blocks if not b['translate'])}")
    print(f"  paragraphs stitched back together: {stitched}")
    print(f"  heading levels normalised: {leveled}")
    print(f"  inline lists split:        {listed}")
    print(f"  label subtitles merged:    {merged_sub}")
    print(f"  label headings unified:    {labelled}")
    print(f"  printed TOC hidden:        {toc_hidden}")
    print(f"  still ending mid-sentence: {unfinished}"
          f"{'  (check blocks.txt — the split may be real)' if unfinished else ''}")
    print(f"\n>> Next: pagecheck.py cross-checks every page with OCR and repairs structure.")
    print(f"   Read {preview} after that — it is rewritten with the repairs applied.")


if __name__ == "__main__":
    main()
