#!/usr/bin/env python3
"""Per-page cross-check. Reads every page as an image and compares it against what
extract.py pulled from the PDF text layer — then repairs the structure.

Three engines:

  --engine vision     (default) a cheap vision model reads every page.
                      ~$0.0075/page on Haiku, so ~$2.3 for a 300-page book.
                      No local binary needed. Sees structure, not just characters.
  --engine datalab    the Datalab API (datalab.to — the hosted, improved Chandra
                      OCR model) retypes every page. Needs DATALAB_API_KEY (env or
                      .env), pays per page in Datalab credits, no GPU needed.
                      Always behaves like --trust vision: the page is rebuilt from
                      the API's reading and the text layer goes to `superseded`.
  --engine tesseract  local OCR on every page, vision only on flagged pages.
                      Free and offline, but it only detects problems — it cannot fix them.

    python scripts/pagecheck.py work/book.json --pdf book.pdf
    python scripts/pagecheck.py work/book.json --pdf book.pdf --pages 1-40   # cost probe
    python scripts/pagecheck.py work/book.json --pdf book.pdf --engine datalab
    python scripts/pagecheck.py work/book.json --pdf book.pdf --engine tesseract

WHO WINS WHAT
  The text layer is character-exact but structurally blind. A vision model is
  structurally smart but not character-exact — it quietly normalizes archaic spelling,
  fixes typos the author meant, and writes fluent text over a line it skipped. So:
  characters come from the text layer, structure comes from vision. Page text read by
  the model is used only to measure coverage and to recover text the layer never had.

IDs are immutable from this point on. Blocks inserted here get suffixed IDs (b0042a)
so existing translation caches stay valid.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import time
from collections import Counter, defaultdict
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

import _llm as L
from extract import (BODY, HYPHENS, TERMINAL_RE, continues_sentence, is_bare_label,
                     is_figure_label, is_page_progress, join_src, looks_garbled,
                     merged_type, normalize_headings, starts_note)

try:
    import fitz
except ImportError:
    sys.exit("PyMuPDF required:  pip install pymupdf")

WORD_RE = re.compile(r"[a-z0-9']+")

VISION_SYS = """You read one page of a book and proof a machine extraction of it.

You get the page image and the blocks extraction pulled from the PDF text layer.

Do two things.

1. TRANSCRIBE the page body exactly as printed. Body text is the author's running
   prose. Skip everything that is not:
   - the running head/foot — usually the book or chapter title repeated at the very
     top or bottom. It is NOT a heading, even in a large or bold face, and it is NOT
     part of whatever list or paragraph happens to sit next to it. Skip it entirely.
   - the page number and any reader-app progress line ("Page 26 of 201 · 9%",
     "26 of 201", a bare percentage).
   - anything printed INSIDE a figure, chart, diagram, map or photograph: axis labels
     and tick values, legend entries, data labels, arrows and callouts, units, scale
     bars, words drawn on the artwork itself. These belong to the picture, not to the
     text. They arrive as scrambled fragments and are unreadable out of place.
   - the figure's own number label — "Figure 4", "Fig. 2", "Table 3", "Plate II",
     "그림 1", and a bare "(a)" / "(b)" panel letter.
   Do not correct spelling, do not modernize archaic forms, do not fix what looks
   like a typo — an author's deliberate misspelling is not an error. If a line is
   illegible, write [?] rather than guessing.

2. REPORT what the extraction got wrong. Only what is wrong.
   - reading order, especially multi-column pages where extraction interleaves columns
   - block types: h1/h2/h3 (headings), p (body), quote (block quotation or epigraph),
     figcaption, footnote, table_raw
   - author's prose visible on the page that appears in NO block — the text layer drops
     drop caps, sidebars and rotated pull-quotes. Do NOT report text that lives inside
     a figure as missing; it is not missing, it is not text.
   - blocks that should be dropped. `reason` must be exactly one of these three
     words — no other value is read, and a free-text reason is discarded:
       "furniture" — the running head, running foot, or page number
       "figure"    — text lifted out of a figure, chart, diagram or map, and the
                     figure's own number label alone ("Figure 4", "Table 3", "(b)")
       "garbled"   — the reader misread the artwork or the type and produced letter
                     salad: "ZINZINZINZ", "sveriGeE 5O", "| receptor densi",
                     "™ Cou - ] . =5". If you cannot read it as words on the page,
                     it is garbled.
     Judge by what you SEE on the page image, not by how the block reads. A block of
     ordinary sentences is never "figure" or "garbled", however odd it looks.

     **Never drop a block for being incomplete.** A block that stops mid-sentence or
     mid-word, duplicates its neighbour's tail, or continues onto the next page is
     the normal shape of an extraction — the pipeline rejoins those afterwards and
     dropping them deletes the author's text. Truncation, duplication and bad splits
     are not drop reasons. Say nothing about them.

     **Never drop a caption.** `figure` means the words printed INSIDE the artwork.
     A caption set as a sentence below the figure ("Figure 22. The Kuleshov effect.
     The interpretation of an ambiguous expression is changed by…") is the author's
     text: keep it, and give it type `figcaption` if the extraction got that wrong.
     Only a bare number label with no sentence after it is droppable.

Copy missing text verbatim. Never invent text you cannot read.

REBUILD is the last resort. Use it only when the blocks are damaged in a way that
reordering and retyping cannot repair — most often two columns interleaved INSIDE a
single block, so one block holds alternating lines from both columns. Then return the
whole page as a fresh block list in correct reading order. Do not use rebuild for a
page that merely needs reordering or a type fix; rebuilt text comes from your reading,
which is less reliable than the PDF's own text layer.

Output JSON only, no prose, no code fence:
{"text": "full page transcription",
 "columns": 1,
 "order": ["b0012","b0013"],
 "types": {"b0014":"h2"},
 "missing": [{"after":"b0015","type":"p","text":"..."}],
 "drop": [{"id":"b0019","reason":"figure"}],
 "rebuild": [{"type":"h2","text":"..."},{"type":"p","text":"..."}],
 "notes": "one short line, or empty"}

Omit every key you have no correction for."""


# `--trust vision`. The prompt above defends the text layer because in a normal PDF
# the layer is character-exact and a vision model is not: it modernises archaic
# spelling, silently corrects an author's deliberate misspelling, and skips a line
# while producing a sentence that still reads smoothly. Trusting it there loses more
# than it gains.
#
# That argument collapses when the layer is itself an OCR artifact — a scan, or a
# screen capture of an ebook reader run through an OCR engine. Then the layer is not
# character-exact either, and it is wrong in ways nothing downstream can repair:
# `bom` for `born`, `beSeattle` for `be Seattle`, `1temporarily` for `I temporarily`,
# a line-break hyphen written as `¬`. Against that, a vision transcription is simply
# better. This prompt flips the authority for those documents only.
VISION_SYS_TRUST = """You read one page of a book and transcribe it.

You also get the blocks a machine pulled from the PDF's text layer. That layer is NOT
reliable for this document — it was produced by OCR and is corrupted: letters swapped
for lookalikes, spaces dropped between words, line-break hyphens written as stray
glyphs. Use it only as a hint about layout and about words you cannot read. When your
reading and the layer disagree, YOUR READING WINS.

Transcribe the page body as printed, in reading order, split into blocks.

- Skip the page furniture: the running head/foot (usually the book or chapter title
  repeated at the very top or bottom — NOT a heading, even in a large face, and NOT
  part of the list or paragraph next to it), the page number, and any reader-app
  progress line ("Page 26 of 201 · 9%", "26 of 201", a bare percentage).
- Skip everything printed INSIDE a figure, chart, diagram, map or photograph: axis
  labels and tick values, legend entries, data labels, arrows and callouts, units,
  scale bars, words drawn on the artwork itself. Skip the figure's own number label
  too — "Figure 4", "Fig. 2", "Table 3", "Plate II", "(a)" / "(b)". These belong to
  the picture; lifted out of it they are unreadable fragments. The layer blocks are
  full of them and you will be tempted to tidy them up — leave them out instead.
  A caption printed as a sentence BELOW the figure is different: emit it as
  `figcaption`, with the bare number label stripped from the front.
- Skip letter salad. Where the layer shows `ZINZINZINZ`, `sveriGeE 5O`,
  `| receptor densi` or `™ Cou - ] . =5`, an engine misread artwork or type. Read
  the page yourself: if there is no printed sentence there, emit nothing.
- Rejoin a word broken across a line break: `am-` + `bitious` is one word, `ambitious`.
- Rejoin a paragraph broken across a line break into one block. A block is a whole
  paragraph, not a line.
- If a paragraph starts on this page and does not finish, still emit what is here —
  the pipeline stitches page-crossing paragraphs afterwards.
- Do not correct spelling, do not modernise archaic forms, do not fix what looks like
  an author's deliberate misspelling. Fix only what is plainly OCR damage.
- If a passage is genuinely illegible write [?] rather than guessing.
- A title page or half-title is not a stack of headings. Emit the title as one block.

Block types: h1/h2/h3 (headings), p (body), quote (block quotation or epigraph),
figcaption, footnote, table_raw.

Output JSON only, no prose, no code fence:
{"text": "full page transcription",
 "columns": 1,
 "rebuild": [{"type":"h2","text":"..."},{"type":"p","text":"..."}],
 "notes": "one short line, or empty"}

`rebuild` is the page. Always return it, even when the layer looks fine."""


# ---------- local OCR ----------

def find_tesseract():
    try:
        import pytesseract  # noqa: F401
        return "pytesseract"
    except ImportError:
        pass
    return "cli" if shutil.which("tesseract") else None


def ocr_page(png: Path, backend: str, lang: str):
    """Return (text, [(x_center, y_top, word)])."""
    if backend == "pytesseract":
        import pytesseract
        from PIL import Image
        d = pytesseract.image_to_data(Image.open(png), lang=lang,
                                      output_type=pytesseract.Output.DICT)
        words, boxes = [], []
        for i, w in enumerate(d["text"]):
            w = w.strip()
            if not w or int(d["conf"][i]) < 40:
                continue
            words.append(w)
            boxes.append((d["left"][i] + d["width"][i] / 2, d["top"][i], w))
        return " ".join(words), boxes

    with tempfile.TemporaryDirectory() as td:
        base = Path(td) / "o"
        subprocess.run(["tesseract", str(png), str(base), "-l", lang, "tsv"],
                       check=True, capture_output=True)
        words, boxes = [], []
        for r in base.with_suffix(".tsv").read_text(encoding="utf-8").splitlines()[1:]:
            f = r.split("\t")
            if len(f) < 12 or not f[11].strip():
                continue
            try:
                if float(f[10]) < 40:
                    continue
            except ValueError:
                continue
            words.append(f[11].strip())
            boxes.append((int(f[6]) + int(f[8]) / 2, int(f[7]), f[11].strip()))
        return " ".join(words), boxes


def ocr_columns(boxes, page_width: float) -> int:
    if len(boxes) < 60:
        return 1
    xs = [b[0] for b in boxes]
    mid = page_width / 2
    left = sum(1 for x in xs if x < mid * 0.92)
    right = sum(1 for x in xs if x > mid * 1.08)
    gutter = sum(1 for x in xs if mid * 0.92 <= x <= mid * 1.08)
    if left > len(xs) * .3 and right > len(xs) * .3 and gutter < len(xs) * .08:
        return 2
    return 1


def order_looks_ok(boxes, page_width: float, layer_text: str) -> bool:
    if ocr_columns(boxes, page_width) != 2:
        return True
    mid = page_width / 2
    left = [w for x, y, w in sorted(boxes, key=lambda b: b[1]) if x < mid][:8]
    if len(left) < 6:
        return True
    return left[0].lower() in WORD_RE.findall(layer_text.lower())[:400]


# ---------- datalab ----------
#
# https://www.datalab.to — Chandra OCR(datalab-to/chandra)을 만든 Datalab 의 호스팅
# API. 공개 웨이트보다 정확도가 높은 개선판 Chandra 가 돌아간다(README 벤치마크
# 86.7% vs 85.8%). vision 엔진의 「전 쪽 재판독」과 같은 일을 하되 모델이 다르다 —
# GPU 없이 쓰고, Datalab 크레딧으로 쪽당 과금된다(실측 accurate 모드 쪽당 1¢).
# 출력이 우리 블록 ID 를 모르는 통짜 판독이라 layer 신뢰 모드는 성립하지 않는다 —
# 항상 rebuild 로 갈아끼우고, 밀려난 텍스트 레이어는 --trust vision 과 똑같이
# superseded 에 보관된다.
#
# 와이어는 convert 엔드포인트 하나다: multipart 로 쪽 PNG 를 올리고
# request_check_url 을 폴링한다. 인증은 X-API-Key 헤더, 키는 $DATALAB_API_KEY —
# 없으면 .env(현재 폴더 → 스킬 폴더 → 그 부모)를 읽는다.
#
# output_format 은 chunks 다, markdown 이 아니라. markdown 은 블록 유형을 잃는다 —
# 실측에서 표지 그림의 설명문("A large, embossed circular design…")이 h1 과 본문
# 단락으로 새어 들어왔고, 러닝 헤더도 우리 휴리스틱으로 다시 걸러야 했다. chunks
# 는 같은 내용이 유형 붙은 평면 목록(PageHeader/SectionHeader/Text/Picture/
# PageFooter/Caption/Footnote/Table…)으로 오므로 결정론적으로 버리고 대응시킨다.

# ---------- Datalab ----------
#
# 판독 계층은 **vlmparse** 로 떼어 냈다(별도 저장소, 이 저장소에는 git subtree 로
# `vendor/vlmparse` 에 들어 있고 스킬 zip 에는 `scripts/vlmparse/` 로 실린다).
#
# 여기 있던 250줄 — 429 백오프·폴링·과금 집계·그림 수확·chunks 대응 — 이 통째로
# 그리로 갔다. 옮기면서 고친 것 하나: **수식을 지우지 않는다.** 옛 `html_clean` 은
# `<math>` 태그를 걷어내 안쪽 LaTeX 를 맨몸으로 흘려보냈고, 그래서 양자역학 책
# 본문에 `\Delta e \times \Delta d` 가 산문처럼 박혔다. vlmparse 는 인라인을
# `$…$`, 별행(`Equation` 유형)을 `$$…$$` 로 남긴다.
try:
    from vlmparse.backends import datalab as DL
except ImportError:  # 개발 중인 저장소에서는 subtree 원본을 직접 본다
    sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "vendor/vlmparse/src"))
    from vlmparse.backends import datalab as DL

DATALAB_PLACEHOLDER = DL.PLACEHOLDER
_DL_SPEND = DL.Spend()


def datalab_key() -> str | None:
    return DL.find_key()


def datalab_read_page(img: Path, key: str, mode: str) -> list[dict]:
    return DL.read_page(img, key, mode, _DL_SPEND)


def chunk_items(chunks: list[dict]) -> tuple[list[dict], dict]:
    return DL.chunks_to_blocks(chunks)


# ---------- shared ----------

def tokens(text: str) -> Counter:
    return Counter(WORD_RE.findall(text.lower()))


def coverage(page_text: str, layer_text: str) -> tuple[float, int]:
    pt, lt = tokens(page_text), tokens(layer_text)
    total = sum(pt.values())
    if not total:
        return 1.0, 0
    return sum(min(c, lt[w]) for w, c in pt.items()) / total, total


SYS_FINGERPRINT = hashlib.sha1(
    (VISION_SYS + VISION_SYS_TRUST).encode("utf-8")).hexdigest()[:8]


def norm_words(text: str) -> str:
    """구두점·띄어쓰기를 걷어낸 낱말열. 두 텍스트를 비교할 때는 양쪽 다 이걸 거친다."""
    return " ".join(WORD_RE.findall(text.lower()))


# 머리글로 몰기에는 너무 긴 블록. 러닝 헤드는 짧고, 무엇보다 여러 쪽에 되풀이된다.
FURNITURE_MAX = 60
FURNITURE_PAGES = 3


# 기능어. 도판의 축 이름·범례·데이터 라벨에는 거의 나오지 않고, 저자가 쓴 문장에는
# 반드시 나온다. 잘려서 문장으로 끝나지 않는 본문을 가려내는 데 이것이 결정적이다.
FUNCTION_WORDS = frozenset("""
a an the of to in on at by for with from into onto over under about
and or but so yet nor if then than that this these those which who whom whose
is are was were be been being am do does did have has had will would can could
should may might must not no we our us you your they their them he she it its
""".split())


def function_word_count(text: str) -> int:
    return sum(1 for w in WORD_RE.findall(text.lower()) if w in FUNCTION_WORDS)


def reads_as_prose(text: str) -> bool:
    """완결된 문장으로 읽히는가.

    도판 조각·판독 쓰레기라는 모델의 판정을 받아들이기 전 마지막 방어선이다.
    본문 단락은 아무리 이상해 보여도 문장으로 끝난다."""
    t = text.strip()
    return len(WORD_RE.findall(t.lower())) >= 15 and bool(
        re.search(r"[.!?][\"'’”)\]]*$", t))


def droppable(text: str, repeats: int, btype: str = "p") -> bool:
    """모델이 지목한 블록을 실제로 버려도 되는가.

    비전 모델은 절 제목과 그 첫 줄을 러닝 헤드로 자주 오인한다. 한 책에서 341개를
    버렸는데 그중 123개가 200자 넘는 본문 단락이었고, 버려진 단락의 뒷부분만 번역돼
    문장 중간부터 시작하는 한국어가 남았다. 오판의 대가가 한쪽으로만 크다 — 잘못
    버리면 본문이 사라지고, 잘못 남기면 부스러기 한 줄이 번역될 뿐이다.

    그래서 되풀이를 요구한다. 진짜 머리글은 여러 쪽에 같은 글자로 다시 나온다.
    제목은 길이와 무관하게 그 조건을 건다 — 짧은 것이 제목의 성질이라, 길이로는
    러닝 헤드와 절 제목을 가를 수 없다(`TRUE BELIEVERS IN THE INNER ORACLE` 은
    33자짜리 진짜 제목인데 머리글로 몰려 버려졌다)."""
    if repeats >= FURNITURE_PAGES:
        return True
    if btype.startswith("h"):
        return False
    return len(text.strip()) <= FURNITURE_MAX


def suffix_id(base: str, used: set[str]) -> str:
    for c in "abcdefghijklmnop":
        if base + c not in used:
            return base + c
    raise RuntimeError(f"too many insertions after {base}")


def rebuild_page(book: dict, page_blocks: list[dict], items: list[dict],
                 stats: Counter, page: int | None = None) -> bool:
    """Replace a page's blocks wholesale. Only for pages the model reports as
    unrepairable — interleaved columns inside a block, mainly.

    The replacement text comes from the model's reading, so the displaced text-layer
    text is archived under book["superseded"] rather than discarded: it is the only
    character-exact record of the page, and the reader-facing drawer needs to be able
    to say that this particular source text is a reading, not the original."""
    clean = [(i.get("type", "p"), re.sub(r"\s+", " ", (i.get("text") or "")).strip())
             for i in items]
    clean = [(t, x) for t, x in clean if len(x) >= 3 and "[?]" not in x]
    if not clean:
        return False

    if not page_blocks:
        # 글자 레이어가 아예 없는 쪽(순수 스캔) — 이 쪽의 첫 블록을 여기서 만든다.
        # 기존 경로는 삽입 위치와 ID 를 밀려나는 블록에서 얻는데, 빈 쪽에는 그것이
        # 없어 261쪽짜리 스캔본이 통째로 무시됐다(재구성 0). 위치는 뒤 쪽 첫 블록
        # 앞이고, ID 는 책 전체 최대 번호를 이어 새로 딴다 — 쪽을 번호 순서로
        # 직렬 처리하므로 ID 순서와 책 순서가 같이 간다.
        if page is None:
            return False
        first = len(book["blocks"])
        for i, b in enumerate(book["blocks"]):
            if (b.get("page") or 0) > page:
                first = i
                break
        base = max((int(m.group(1)) for b in book["blocks"]
                    for m in [re.match(r"^b(\d+)", str(b.get("id", "")))] if m),
                   default=0)
        fresh = [{"id": f"b{base + k + 1:04d}", "type": t, "page": page, "src": x,
                  "ko": None, "translate": True, "from_ocr": True, "rebuilt": True}
                 for k, (t, x) in enumerate(clean)]
        for b in fresh:
            # figure 의 src 는 asset id, equation 의 src 는 LaTeX 다 — 둘 다
            # 번역할 것도, 판독 텍스트라 할 것도 아니다.
            if b["type"] in ("figure", "equation"):
                b["translate"] = False
                del b["from_ocr"], b["rebuilt"]
        book["blocks"][first:first] = fresh
        stats["rebuilt"] += 1
        return True

    old_ids = [b["id"] for b in page_blocks]
    page = page_blocks[0]["page"]
    first = next(i for i, b in enumerate(book["blocks"]) if b["id"] == old_ids[0])

    # archive before deleting — nothing character-exact gets thrown away
    book.setdefault("superseded", {})[str(page)] = [
        {"id": b["id"], "type": b["type"], "src": b["src"]} for b in page_blocks]

    keep = set(old_ids)
    book["blocks"] = [b for b in book["blocks"] if b["id"] not in keep]

    used = {b["id"] for b in book["blocks"]}
    ids = []
    for k in range(len(clean)):
        if k < len(old_ids) and old_ids[k] not in used:
            ids.append(old_ids[k])
        else:
            ids.append(suffix_id(ids[-1] if ids else old_ids[0], used))
        used.add(ids[-1])

    fresh = [{"id": bid, "type": t, "page": page, "src": x, "ko": None,
              "translate": True, "from_ocr": True, "rebuilt": True}
             for bid, (t, x) in zip(ids, clean)]
    for b in fresh:
        # figure 의 src 는 asset id, equation 의 src 는 LaTeX 다 — 둘 다 번역할
        # 것도, 판독 텍스트라 할 것도 아니다.
        if b["type"] in ("figure", "equation"):
            b["translate"] = False
            del b["from_ocr"], b["rebuilt"]
    book["blocks"][first:first] = fresh
    stats["rebuilt"] += 1
    return True


def continues_hyphen(book: dict, bid: str) -> bool:
    """앞의 읽는 블록이 분철 하이픈으로 끝나는가 — 즉 이 블록이 낱말의 나머지인가.

    `Journal of Nervous and Mental Dis-` 다음의 `ease, 131(2): 135-48.` 이 뷰어
    부속물로 지워졌다. 짧고 숫자가 많아 부속물처럼 보이지만, 앞이 하이픈으로
    끊겼다는 사실 하나가 그것이 본문임을 못 박는다. 같은 사고로 `46.`·`80.` 도
    사라졌다 — 어느 것이든 **지운 자리가 문장 한가운데**라는 점이 증거다."""
    blocks = book.get("blocks") or []
    prev = None
    for b in blocks:
        if b.get("id") == bid:
            break
        if b.get("translate", True):
            prev = b
    else:
        return False
    return bool(prev) and prev.get("src", "").rstrip()[-1:] in HYPHENS


def repeat_counts(book: dict) -> Counter:
    """블록 글자 → 그 글자가 나타난 쪽 수. 머리글 판별의 근거다."""
    seen: set[tuple[str, int]] = set()
    out: Counter = Counter()
    for b in book["blocks"]:
        key = norm_words(b.get("src", ""))[:80]
        if not key or (key, b.get("page")) in seen:
            continue
        seen.add((key, b.get("page")))
        out[key] += 1
    return out


def apply_fix(book: dict, page_blocks: list[dict], fix: dict, stats: Counter,
              repeats: Counter | None = None, page: int | None = None) -> None:
    if fix.get("rebuild") and rebuild_page(book, page_blocks, fix["rebuild"], stats,
                                           page=page):
        return

    by_id = {b["id"]: b for b in book["blocks"]}
    used = {b["id"] for b in book["blocks"]}
    ids = [b["id"] for b in page_blocks]
    known = set(ids)

    for bid, newtype in (fix.get("types") or {}).items():
        if bid in known and newtype in ("h1", "h2", "h3", "p", "quote",
                                        "figcaption", "footnote", "table_raw"):
            if by_id[bid]["type"] != newtype:
                by_id[bid]["type"] = newtype
                stats["types"] += 1

    for item in (fix.get("drop") or []):
        # 예전 형식은 ID 문자열만 보냈다. 사유가 붙어 오면 그 사유에 맞는 잣대를 쓴다.
        bid = item if isinstance(item, str) else (item or {}).get("id")
        reason = "furniture" if isinstance(item, str) else (item or {}).get("reason", "furniture")
        if bid not in known:
            continue
        src = by_id[bid].get("src", "")
        if reason in ("figure", "garbled"):
            # 도판 안 글자인지 판독 쓰레기인지는 쪽 이미지를 본 모델이 우리보다 잘 안다.
            # 되풀이·길이 잣대는 머리글을 지키자고 만든 것이라 여기 대면 멀쩡한 판정을
            # 막는다. 대신 세 가지로만 되돌린다.
            #
            # `reads_as_prose` 하나로는 부족했다 — 잘려서 문장으로 끝나지 않는 본문이
            # 그 검사를 빠져나간다(244쪽 실측에서 508자짜리 본문 단락이 그렇게 지워졌다).
            # 기능어가 세 개 이상이면 저자가 쓴 문장이지 축 이름이 아니다.
            #
            # 캡션은 따로 지킨다. `figure` 는 도판 **안** 글자를 뜻하는데 모델이 그림
            # 아래 캡션까지 같은 사유로 묶어 보냈다(진짜 캡션 다섯 개가 지워졌다).
            btype = by_id[bid].get("type", "p")
            ok = not (reads_as_prose(src)
                      or function_word_count(src) >= 3
                      or (btype == "figcaption" and len(src.strip()) > 25))
        else:
            ok = droppable(src, (repeats or Counter()).get(norm_words(src)[:80], 0),
                           by_id[bid].get("type", "p"))
        if ok and continues_hyphen(book, bid):
            ok = False               # 분철된 낱말의 나머지는 부속물일 수 없다
        if not ok:
            stats["drop refused"] += 1
            continue
        by_id[bid]["translate"] = False
        by_id[bid]["dropped"] = True
        stats["dropped"] += 1

    order = [i for i in (fix.get("order") or []) if i in known]
    if order and len(order) == len(ids) and order != ids:
        pos = {b["id"]: i for i, b in enumerate(book["blocks"])}
        for slot, bid in zip(sorted(pos[i] for i in ids), order):
            book["blocks"][slot] = by_id[bid]
        stats["reordered"] += 1

    for item in (fix.get("missing") or []):
        text = re.sub(r"\s+", " ", (item.get("text") or "")).strip()
        if len(text) < 12 or "[?]" in text:
            continue
        # 이미 뽑혀 있는 텍스트인가. 블록 전체가 이 쪽에 들어 있을 때만 버린다.
        #
        # 예전에는 첫 여섯 낱말로 판단했는데 두 가지가 어긋나 있었다. 하나는
        # 비교 방식 — probe 는 구두점을 뗀 낱말열인데 비교 대상은 원문 그대로여서,
        # 첫 여섯 낱말 안에 쉼표 하나만 있으면 검사가 무조건 빗나갔다. 246쪽
        # 스캔본에서 삽입 122개 중 93개가 옆 블록의 복제본이었고, 읽을 때는 단락이
        # 끝난 자리에 그 꼬리가 조각으로 되풀이돼 보였다.
        #
        # 다른 하나는 앞머리만 보는 것 자체다. 모델은 이미 있는 문장으로 시작해
        # 레이어가 놓친 부분까지 이어서 적어 오는 일이 잦다 — 앞이 겹친다고 버리면
        # 뒤에 붙은 새 본문을 함께 버린다(실측으로 1,720자 중 6할이 새 텍스트인
        # 블록이 이 경우였다). 낱말 단위로 얼마나 담겨 있는지를 재는 쪽이 맞다.
        cov, total = coverage(text, " ".join(b["src"] for b in page_blocks))
        if total and cov >= 0.8:
            continue
        after = item.get("after")
        idx = next((i for i, b in enumerate(book["blocks"]) if b["id"] == after), None)
        if idx is None:
            idx = max((i for i, b in enumerate(book["blocks"]) if b["id"] in known),
                      default=None)
            if idx is None:
                continue
        new_id = suffix_id(book["blocks"][idx]["id"], used)
        used.add(new_id)
        book["blocks"].insert(idx + 1, {
            "id": new_id, "type": item.get("type", "p"),
            "page": book["blocks"][idx]["page"], "src": text,
            "ko": None, "translate": True, "from_ocr": True,
        })
        stats["inserted"] += 1


# ---------- page images ----------

# 업로드 시간이 병목이다. 토큰 값은 픽셀 치수만 따르므로 같은 1568px 이면 PNG 든
# JPEG 든 값이 같다 — 줄어드는 건 올려보내는 바이트다. 191쪽 스캔본 실측으로 쪽당
# PNG 561KB, JPEG q75 208KB, 회색조로 한 번 더 줄여 202KB. 8워커로 246쪽이면
# 올려보낼 양이 135MB 에서 49MB 로 준다.
#
# 본문 스캔은 회색조로 떨어뜨려도 판독이 나빠지지 않는다 — 글자는 명암이지 색이
# 아니다. 컬러 도판의 색이 판단에 필요한 문서라면 `--no-gray`.
def media_type_of(path: Path) -> str:
    return "image/jpeg" if path.suffix.lower() in (".jpg", ".jpeg") else "image/png"


def render_page(page, dest: Path, dpi: int, long_edge: int,
                quality: int = 75, gray: bool = True) -> None:
    """한 쪽을 dest 로 래스터라이즈한다. dest 가 JPEG 면 압축해서 쓴다."""
    zoom = dpi / 72
    long_px = max(page.rect.width, page.rect.height) * zoom
    if long_px > long_edge:
        zoom *= long_edge / long_px
    pm = page.get_pixmap(matrix=fitz.Matrix(zoom, zoom),
                         colorspace=fitz.csGRAY if gray else fitz.csRGB)
    if media_type_of(dest) != "image/jpeg":
        pm.save(dest)
        return
    try:
        pm.save(dest, jpg_quality=quality)
    except (TypeError, ValueError, RuntimeError):
        # 오래된 PyMuPDF 는 jpg 를 직접 못 쓴다. Pillow 는 tesseract 백엔드가
        # 이미 쓰고 있으니 새 의존이 아니다.
        from PIL import Image
        Image.frombytes("L" if gray else "RGB", (pm.width, pm.height), pm.samples) \
             .save(dest, "JPEG", quality=quality, optimize=True)


def read_with_vision(png: Path, pno: int, total: int, blocks: list[dict],
                     cache: L.Cache, model: str, trust: str = "layer") -> dict:
    listing = "\n".join(f"[{b['id']}] ({b['type']}) {b['src'][:400]}"
                        for b in blocks) or "(no blocks — the text layer is empty here)"
    # trust belongs in the key: the two modes ask different questions of the same page.
    # 프롬프트 지문도 넣는다 — 프롬프트를 고쳤는데 캐시가 그대로면 낡은 답이 재생되고,
    # 고친 줄 알고 넘어가게 된다. 실제로 그럴 뻔했다.
    key = cache.key(listing, pno, model, "v2", trust, SYS_FINGERPRINT)
    hit = cache.get(key)
    if hit is not None:
        return hit
    try:
        raw = L.call_vision(VISION_SYS_TRUST if trust == "vision" else VISION_SYS,
                            f"Page {pno} of {total}.\n\nExtracted blocks:\n{listing}",
                            png, max_tokens=4000, model=model,
                            media_type=media_type_of(png))
    except L.VisionUnavailable as e:
        # 이 쪽은 비전 없이 간다. 텍스트 레이어가 그대로 남으므로 번역은 진행되고,
        # 구조 교정만 못 받는다. 결과에 남겨 리포트에서 셀 수 있게 한다.
        fix = {"notes": f"vision unavailable: {e}", "vision_unavailable": True}
        cache.put(key, fix)
        return fix
    try:
        fix = json.loads(L.strip_fence(raw))
    except json.JSONDecodeError:
        fix = {"notes": "unparseable response"}
    cache.put(key, fix)
    return fix


def stitch_pages(book: dict, stats: Counter) -> None:
    """Merge paragraphs broken by a page break, or left broken inside one page.

    Per-page repair cannot see across the seam, and a paragraph running over a page
    boundary is the single most common structural break in a book. The rule is
    deterministic and conservative: the earlier block must end mid-sentence and the
    later one starts the next page. The earlier block ending with no terminal
    punctuation at all is the load-bearing signal — requiring the continuation to
    start lowercase would miss every paragraph that breaks before a proper noun
    ("...a position at Harvard" / "University. My intention...").

    Body and quote are both accepted, because the type classifier is the least
    reliable thing in the extractor: a document whose last line on every page gets
    read as a quotation would otherwise lose every cross-page paragraph. A real
    block quotation almost never ends mid-sentence at a page break with body text
    resuming it, so the risk runs the other way. When the two disagree, body wins —
    a quote that flows into a paragraph was a paragraph all along.

    Same-page seams have to be retried here, not only in `extract.stitch_blocks`.
    Everything above this line moves blocks after that ran: a type correction turns a
    misread footnote back into body text, a duplicate insertion is refused, a block is
    dropped. In one 246-page book pagecheck corrected 141 block types — and every
    paragraph they belonged to stayed in two pieces, because nothing looked at a
    same-page seam again. Inside a page the evidence bar is the extractor's: a hyphen
    at the break, or a continuation that reads as one sentence.

    `figcaption` joins the list for the same reason as in `extract.stitch_blocks` — a
    caption the layer broke mid-sentence is still a caption, and a merge that renamed
    it `p` would drop it into the reading flow as body text."""
    blocks = book["blocks"]
    out: list[dict] = []
    prev = None                       # 마지막으로 **읽는 글**인 블록
    for b in blocks:
        # 버린 블록은 이음매를 끊지 않는다. drop 은 지우지 않고 표시만 하므로(ID 불변)
        # 예전에는 그것이 그대로 `prev` 가 됐다 — 문장 한가운데 `Page 60 of 252 · 3%`
        # 가 끼면 두 반쪽이 영영 이웃이 되지 못한다. 244쪽 책 본문에서 여섯 곳이
        # 이것이었고, 전부 뷰어 부속물이거나 도판 부스러기였다.
        if not b.get("translate", True):
            out.append(b)
            continue
        if (prev and prev["type"] in BODY and b["type"] in BODY
                and not starts_note(b["src"])
                and not prev.get("ko") and not b.get("ko")
                and not TERMINAL_RE.search(prev["src"])):
            across = b["page"] == prev["page"] + 1
            same = b["page"] == prev["page"] and (
                prev["src"].rstrip().endswith("-") or continues_sentence(b["src"]))
            if across or same:
                prev["src"] = join_src(prev["src"], b["src"])
                if prev["type"] != b["type"]:
                    prev["type"] = merged_type(prev["type"], b["type"])
                prev["stitched"] = True
                stats["stitched"] += 1
                continue
        out.append(b)
        prev = b
    book["blocks"] = out


def flag(cov: float, total: int, blocks: list, cols: int, threshold: float) -> list[str]:
    out = []
    if total >= 25 and cov < threshold:
        out.append(f"본문 누락 의심 (일치율 {cov:.0%})")
    if total >= 25 and not blocks:
        out.append("텍스트 레이어 없음 (이미지 페이지)")
    if cols > 1:
        out.append(f"{cols}단 조판")
    # 구조 파손 신호 — 일치율은 낱말 수준이라 블록이 뒤엉켜도 높게 나온다.
    # 실제로 문항 여덟 개가 쪼개지고 제목이 단락에 파묻힌 쪽이 일치율만 보고
    # 수리 대상에서 빠졌다. 분철 기호가 남았거나 낱말 중간에 대문자가 박힌
    # (`diffiQuestions`) 텍스트는 그 자체로 수리가 필요하다는 증거다.
    joined = " ".join(b.get("src", "") for b in blocks)
    if "¬" in joined:
        out.append("분철 기호(¬) 잔존")
    if re.search(r"[a-z]{3}[A-Z][a-z]{3}", joined):
        out.append("낱말 중간 대문자 — 블록 융합 의심")
    return out


# ---------- main ----------

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("book")
    ap.add_argument("--pdf", required=True)
    ap.add_argument("--engine", choices=["vision", "datalab", "tesseract"], default="vision")
    ap.add_argument("--datalab-mode", choices=["fast", "balanced", "accurate"],
                    default=os.environ.get("PKT_DATALAB_MODE", "accurate"),
                    help="datalab convert 모드. 재판독이 목적이므로 기본은 accurate "
                         "($PKT_DATALAB_MODE)")
    ap.add_argument("--trust", choices=["layer", "vision"], default="layer",
                    help="who wins when the page image and the text layer disagree. "
                         "'layer' (default) keeps the PDF's own characters and takes "
                         "only structure from vision. 'vision' retypes every page from "
                         "the image — for documents whose text layer is itself OCR")
    ap.add_argument("--model", default=None,
                    help="vision model (default claude-haiku-4-5; $PKT_VISION_MODEL)")
    ap.add_argument("--workers", type=int, default=8, help="concurrent page reads")
    ap.add_argument("--dpi", type=int, default=150)
    ap.add_argument("--long-edge", type=int, default=1568,
                    help="max image edge sent to the model; beyond this you pay for pixels "
                         "that get downscaled away")
    ap.add_argument("--image-format", choices=["jpeg", "png"], default="jpeg",
                    help="page image format sent to the model (default jpeg — identical "
                         "token cost, roughly a third of the bytes to upload)")
    ap.add_argument("--jpeg-quality", type=int, default=75,
                    help="jpeg quality; below ~60 the small type starts to smear")
    ap.add_argument("--no-gray", action="store_true",
                    help="send colour pages; by default pages go up as grayscale, which "
                         "costs nothing in accuracy for body text")
    ap.add_argument("--lang", default="eng", help="tesseract language (eng, eng+kor …)")
    ap.add_argument("--coverage", type=float, default=0.90,
                    help="page tokens that must appear in the text layer")
    ap.add_argument("--pages", help="limit to a range, e.g. 1-40")
    ap.add_argument("--max-vision", type=int, default=0,
                    help="tesseract engine: cap on follow-up vision calls (0 = no cap)")
    ap.add_argument("--keep-images", action="store_true")
    ap.add_argument("--keep-heading-levels", action="store_true",
                    help="leave h1/h2/h3 as read; by default they are flattened to h1 "
                         "(chapter openers) and h2 (everything else). Reading pages one "
                         "at a time gives the same kind of heading a different level "
                         "depending on the page, and the table of contents inherits it")
    args = ap.parse_args()

    book = L.load_book(args.book)
    work = L.work_dir(args.book)
    pages_dir = work / "pages"
    pages_dir.mkdir(exist_ok=True)
    cache = L.Cache(work, "pagecheck")
    model = args.model or L.VISION_MODEL

    doc = fitz.open(args.pdf)
    lo, hi = 1, len(doc)
    if args.pages:
        lo, hi = (int(x) for x in args.pages.split("-"))
        hi = min(hi, len(doc))
    page_nos = list(range(lo, hi + 1))

    by_page: dict[int, list[dict]] = defaultdict(list)
    for b in book["blocks"]:
        by_page[b["page"]].append(b)

    ext = ".png" if args.image_format == "png" else ".jpg"

    def page_img(pno: int) -> Path:
        """쪽 이미지 경로. 앞선 실행이 다른 형식으로 받아 뒀으면 그것을 그대로 쓴다 —
        형식을 바꿨다고 이미 끝난 래스터라이즈를 다시 하지는 않는다."""
        p = pages_dir / f"p{pno:04d}{ext}"
        if p.exists():
            return p
        for other in (".jpg", ".jpeg", ".png"):
            q = pages_dir / f"p{pno:04d}{other}"
            if q.exists():
                return q
        return p

    detail = f"{ext.lstrip('.')}" + (f" q{args.jpeg_quality}" if ext != ".png" else "")
    detail += "" if args.no_gray else " gray"
    print(f"rasterizing pages {lo}-{hi} at {args.dpi} dpi -> {detail}")
    for pno in page_nos:
        dest = page_img(pno)
        if dest.exists():
            continue
        render_page(doc[pno - 1], dest, args.dpi, args.long_edge,
                    args.jpeg_quality, not args.no_gray)

    findings: dict[int, dict] = {}
    stats = Counter()
    # 머리글은 여러 쪽에 되풀이된다 — drop 요청을 받아들일지 가르는 근거다.
    # 블록이 바뀌기 전에 한 번만 센다.
    repeats = repeat_counts(book)

    if args.engine == "vision":
        print(f"vision pass · {model} · {len(page_nos)} pages · {args.workers} workers · "
              f"trust={args.trust} · rough cost ${len(page_nos) * 0.0075:.2f}")
        if args.trust == "vision":
            print("  every page is retyped from the image; the text layer is archived "
                  "under superseded")

        def job(pno):
            return pno, read_with_vision(page_img(pno), pno, len(doc),
                                         by_page.get(pno, []), cache, model, args.trust)

        # 쪽마다, 끝나는 순서대로 찍는다. pool.map 을 순서대로 소비하며 20쪽마다
        # 찍던 때는 앱의 진행 표시가 몇 분씩 침묵했다 — 진행은 완료 순서를 따라야
        # 하고, 쪽당 한 줄은 191쪽짜리 책에서도 부담이 아니다.
        results = {}
        with ThreadPoolExecutor(max_workers=args.workers) as pool:
            futs = [pool.submit(job, pno) for pno in page_nos]
            for i, fut in enumerate(as_completed(futs)):
                pno, fix = fut.result()
                results[pno] = fix
                L.progress(i, len(page_nos), "pages read")

        for pno in page_nos:  # serial: block mutation must stay ordered
            fix = results[pno]
            blocks = by_page.get(pno, [])
            if fix.get("vision_unavailable"):
                # 판독이 없으니 일치율을 잴 수가 없다. 0% 로 적으면 본문이 사라진
                # 것처럼 보이고, 100% 로 적으면 대조한 적 없는 쪽을 검증된 것처럼
                # 보이게 한다. 재지 않았다고 적는다.
                stats["vision unavailable"] += 1
                findings[pno] = {"page": pno, "coverage": None, "columns": 1,
                                 "blocks": len(blocks),
                                 "reasons": ["vision unavailable — layer text kept"],
                                 "notes": fix.get("notes", "")}
                continue
            cov, total = coverage(fix.get("text", ""), " ".join(b["src"] for b in blocks))
            cols = fix.get("columns") or 1
            findings[pno] = {"page": pno, "coverage": cov, "columns": cols,
                             "blocks": len(blocks),
                             "reasons": flag(cov, total, blocks, cols, args.coverage),
                             "notes": fix.get("notes", "")}
            apply_fix(book, blocks, fix, stats, repeats, page=pno)
        L.save_book(args.book, book)

    elif args.engine == "datalab":
        key = datalab_key()
        if not key:
            sys.exit("DATALAB_API_KEY 가 없습니다. 환경변수로 넣거나 프로젝트 루트의 "
                     ".env 에 적으세요 (https://www.datalab.to 에서 발급).")
        print(f"datalab pass · mode={args.datalab_mode} · {len(page_nos)} pages · "
              f"{args.workers} workers · Datalab 크레딧으로 쪽당 과금")
        print("  every page is retyped from the image; the text layer is archived "
              "under superseded")
        if args.trust == "layer":
            print("  (datalab 은 페이지 전체를 다시 받아쓰는 엔진이라 --trust layer 가 "
                  "적용되지 않는다)")

        def dl_job(pno):
            # 캐시 키는 쪽 번호 + 모드 + dpi. 캐시는 이 책의 작업 폴더 안에
            # 있으므로 쪽 번호로 충분하고, 재실행이 공짜가 된다.
            k = cache.key(f"datalab:{pno}", args.datalab_mode, args.dpi, "v2")
            hit = cache.get(k)
            if hit is not None:
                return pno, hit
            try:
                chunks = datalab_read_page(page_img(pno), key,
                                           args.datalab_mode)
                fix = {"chunks": chunks}
                cache.put(k, fix)
            except Exception as e:
                print(f"  ! page {pno}: {e}", file=sys.stderr)
                fix = {"error": str(e)}
            return pno, fix

        results = {}
        with ThreadPoolExecutor(max_workers=args.workers) as pool:
            futs = [pool.submit(dl_job, pno) for pno in page_nos]
            for i, fut in enumerate(as_completed(futs)):
                pno, fix = fut.result()
                results[pno] = fix
                L.progress(i, len(page_nos), "pages read")

        for pno in page_nos:  # serial: block mutation must stay ordered
            fix = results[pno]
            blocks = by_page.get(pno, [])
            items, page_assets = chunk_items(fix.get("chunks") or [])
            book.setdefault("assets", {}).update(page_assets)
            # figure 의 text 는 asset id — 일치율 계산에 넣으면 낱말이 아닌
            # 해시가 분모를 오염시킨다
            text = " ".join(i["text"] for i in items if i["type"] != "figure")
            cov, total = coverage(text, " ".join(b["src"] for b in blocks))
            if fix.get("error"):
                # 판독이 실패한 쪽은 일치율이 「빈 것 대 빈 것」이라 100% 로 찍힌다.
                # 그대로 두면 통째로 비어 버린 쪽이 리포트에서 가장 멀쩡해 보인다.
                cov = None
                stats["datalab 판독 실패"] += 1
            findings[pno] = {"page": pno, "coverage": cov, "columns": 1,
                             "blocks": len(blocks),
                             "reasons": flag(cov, total, blocks, 1, args.coverage),
                             "notes": f"datalab 판독 실패: {fix['error'][:80]}"
                                      if fix.get("error") else ""}
            if items:
                apply_fix(book, blocks, {"rebuild": items}, stats, page=pno)
        L.save_book(args.book, book)

    else:
        backend = find_tesseract()
        if backend is None:
            sys.exit("no tesseract.  pip install pytesseract pillow  + the binary,\n"
                     "  or use the default --engine vision (no local install needed)")
        print(f"tesseract pass · {backend} ({args.lang})")
        flagged = []
        for i, pno in enumerate(page_nos):
            blocks = by_page.get(pno, [])
            layer_text = " ".join(b["src"] for b in blocks)
            try:
                otext, boxes = ocr_page(page_img(pno), backend, args.lang)
            except Exception as e:
                otext, boxes = "", []
                print(f"  ! page {pno} OCR failed: {type(e).__name__}", file=sys.stderr)
            cov, total = coverage(otext, layer_text)
            width = doc[pno - 1].rect.width * (args.dpi / 72)
            cols = ocr_columns(boxes, width)
            reasons = flag(cov, total, blocks, cols, args.coverage)
            if cols == 2 and not order_looks_ok(boxes, width, layer_text):
                reasons.append("단 읽기 순서 뒤바뀜")
            findings[pno] = {"page": pno, "coverage": cov, "columns": cols,
                             "blocks": len(blocks), "reasons": reasons, "notes": ""}
            if reasons:
                flagged.append(pno)
            if (i + 1) % 25 == 0 or i + 1 == len(page_nos):
                L.progress(i, len(page_nos), "pages scanned")

        print(f"\nflagged {len(flagged)}/{len(page_nos)} pages")
        rank = sorted(flagged, key=lambda p: findings[p]["coverage"])
        if args.max_vision:
            rank = rank[:args.max_vision]
        rank.sort()
        if rank:
            print(f"vision repair on {len(rank)} page(s) · {model}")
            for i, pno in enumerate(rank):
                fix = read_with_vision(page_img(pno), pno, len(doc),
                                       by_page.get(pno, []), cache, model)
                findings[pno]["notes"] = fix.get("notes", "")
                apply_fix(book, by_page.get(pno, []), fix, stats, repeats, page=pno)
                L.progress(i, len(rank), f"page {pno}")
            L.save_book(args.book, book)

    # 프롬프트가 놓친 쪽 표시("26 of 201 «9%")의 결정적 뒷그물 — extract 와 같은
    # 규칙을 재판독·삽입 블록에도 적용한다. 지우지 않고 drop 표시만 한다(ID 불변).
    for b in book["blocks"]:
        if not b.get("translate", True):
            continue
        src = b.get("src", "")
        # 판독 쓰레기와 그림 번호표도 같은 뒷그물로 걷는다. 프롬프트가 놓친 것을
        # 결정적으로 잡되, 지우지 않고 표시만 한다(ID 불변).
        if (is_page_progress(src) or looks_garbled(src) or is_figure_label(src)
                or is_bare_label(src)):
            if continues_hyphen(book, b.get("id")):
                stats["drop refused"] += 1
                continue
            b["translate"] = False
            b["dropped"] = True
            stats["dropped"] += 1

    stitch_pages(book, stats)
    # 재구성으로 레벨이 다시 흩어지므로 마지막에 한 번 더 고른다
    if not args.keep_heading_levels:
        stats["heading_levels"] = normalize_headings(book["blocks"])

    # rebuild 가 실패한 쪽의 그림은 블록 없이 남는다 — 참조되는 asset 만 남긴다
    if book.get("assets"):
        used = {b["src"] for b in book["blocks"] if b["type"] == "figure"}
        book["assets"] = {k: v for k, v in book["assets"].items() if k in used}
        stats["figures"] = len(book["assets"])
        if not book["assets"]:
            del book["assets"]

    # 판정을 book.json 에도 남긴다. 리포트 md 는 임시 폴더와 함께 지워지므로,
    # 여기 없으면 앱과 .parallax 에서 쪽당 비전 호출로 산 판정 근거를 다시 볼 수
    # 없다. export.py 와 앱이 page_check 테이블로 옮긴다 (요약은 page=0 행).
    engine_label = (f"vision ({model})" if args.engine == "vision"
                    else f"datalab ({args.datalab_mode})" if args.engine == "datalab"
                    else args.engine)
    # **부분 실행은 이전 판정을 덮지 않는다.** `--pages 163-163` 처럼 실패한 몇 쪽만
    # 다시 태우는 것은 흔한 일인데, 통째로 갈아 끼우면 전권 실행이 남긴 175쪽짜리
    # 판정이 한 쪽짜리로 줄어든다(2026-08-08 실측: 176행 → 2행). 리포트 md 는
    # 지워지는 파일이라 이것이 유일한 사본이고, 줄어든 것은 아무 데도 안 찍힌다.
    kept = {f["page"]: f for f in ((book.get("page_check") or {}).get("pages") or [])}
    kept.update(findings)
    book["page_check"] = {
        "summary": f"엔진 {engine_label}"
                   + f" · 일치율 기준 {args.coverage:.0%}"
                   + f" · 유형 수정 {stats['types']} · 순서 교정 {stats['reordered']}"
                   f" · 누락 삽입 {stats['inserted']} · 제외 {stats['dropped']}"
                   f"(거부 {stats['drop refused']})"
                   f" · 페이지 재구성 {stats['rebuilt']} · 단락 병합 {stats['stitched']}"
                   f" · 제목 레벨 정규화 {stats['heading_levels']}",
        "pages": [kept[p] for p in sorted(kept)],
    }
    L.save_book(args.book, book)

    (work / "blocks.txt").write_text(
        "".join(f"{' ' if b['translate'] else '-'}[{b['id']}] ({b['type']:10}) "
                f"p{b['page']:>3}  {b['src'][:120]}\n" for b in book["blocks"]),
        encoding="utf-8")

    low = [f for f in findings.values()
           if f["coverage"] is not None and f["coverage"] < args.coverage and f["blocks"]]
    lines = ["# 페이지 검증 리포트", "",
             f"페이지 {len(page_nos)} · 블록 {len(book['blocks'])} · 엔진 `{engine_label}`",
             f"유형 수정 {stats['types']} · 순서 교정 {stats['reordered']} · "
             f"누락 삽입 {stats['inserted']} · 제외 {stats['dropped']} "
             f"(본문으로 보여 거부한 것 {stats['drop refused']}) · "
             f"페이지 재구성 {stats['rebuilt']} · 단락 병합 {stats['stitched']} · "
             f"제목 레벨 정규화 {stats['heading_levels']}", ""]
    if _DL_SPEND.pages:
        lines += [f"datalab 지출(이번 실행): {_DL_SPEND.pages}쪽 실호출 ≈ "
                  f"${_DL_SPEND.usd:.2f} — 캐시 적중은 0원, 정확한 잔액은 "
                  f"datalab.to 대시보드.", ""]
    lines += [
             "삽입 블록은 `from_ocr: true`, ID는 접미사(b0042a) 형태다. "
             "판독 텍스트는 대조용으로만 쓰이며 기존 블록 내용을 덮어쓰지 않는다.", "",
             "## 이상 페이지", "",
             "| 쪽 | 일치율 | 단 | 블록 | 사유 | 판독 메모 |",
             "|---|---|---|---|---|---|"]
    rows = 0
    for pno in page_nos:
        f = findings.get(pno)
        if not f or (not f["reasons"] and not f["notes"]):
            continue
        rows += 1
        cov = "—" if f["coverage"] is None else f"{f['coverage']:.0%}"
        lines.append(f"| {f['page']} | {cov} | {f['columns']} | {f['blocks']} "
                     f"| {'; '.join(f['reasons']) or '-'} | {f['notes'] or '-'} |")
    if not rows:
        lines.append("| — | — | — | — | 이상 없음 | — |")

    lines += ["", "## 판단", "",
              f"- 일치율 {args.coverage:.0%} 미만 페이지: {len(low)}",
              "- 일치율이 전 페이지에서 고르게 낮으면 개별 페이지 문제가 아니라 텍스트 레이어가 "
              "부실한 것이다. `ocrmypdf --redo-ocr` 로 다시 만들고 extract부터 다시 돌려라.",
              "- 삽입 블록(`from_ocr: true`)은 판독 텍스트라 원본보다 부정확하다. blocks.txt에서 "
              "따로 확인하라.",
              "- 방언·의도적 오기가 있는 소설이라면 삽입 블록을 특히 의심하라. 판독 모델은 그런 "
              "표기를 조용히 표준형으로 고친다.",
              "- 재구성된 페이지는 전 블록이 판독 텍스트다(`rebuilt: true`). 2단이 블록 내부에서 "
              "뒤섞여 블록 단위 교정으로는 못 고치는 경우에만 발생한다. 수가 많으면 extract의 단 "
              "판별이 실패한 것이므로 `--para-gap` 조정 후 extract부터 다시 돌리는 쪽이 낫다.",
              "- 밀려난 텍스트 레이어 원문은 `book.json`의 `superseded`에 페이지별로 보관된다. "
              "지워지지 않으니 필요하면 대조하라."]

    (work / "pagecheck-report.md").write_text("\n".join(lines), encoding="utf-8")

    if not args.keep_images:
        for p in (*pages_dir.glob("*.png"), *pages_dir.glob("*.jpg"),
                  *pages_dir.glob("*.jpeg")):
            p.unlink()
        if not any(pages_dir.iterdir()):
            pages_dir.rmdir()

    print(f"\n유형 {stats['types']} · 순서 {stats['reordered']} · "
          f"삽입 {stats['inserted']} · 제외 {stats['dropped']}"
          f"(거부 {stats['drop refused']}) · 재구성 {stats['rebuilt']} · "
          f"단락 병합 {stats['stitched']} · 제목 레벨 {stats['heading_levels']}")
    if _DL_SPEND.pages:
        print(f"datalab 지출(이번 실행): {_DL_SPEND.pages}쪽 실호출 ≈ "
              f"${_DL_SPEND.usd:.2f} (캐시 적중 {len(page_nos) - _DL_SPEND.pages}쪽 0원)")
    print(f"-> {work/'pagecheck-report.md'}")
    print(">> 구조를 고칠 수 있는 마지막 단계다. ID는 이제부터 불변이다.")


if __name__ == "__main__":
    main()
