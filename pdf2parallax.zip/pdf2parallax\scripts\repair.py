#!/usr/bin/env python3
"""이미 만들어진 `.parallax` 에서 pagecheck 가 낸 구조 손상을 되돌린다.

    python scripts/repair.py book.parallax           # 무엇을 고칠지 보기만 한다
    python scripts/repair.py book.parallax --apply   # 실제로 고친다 (.bak 를 남긴다)

pagecheck 의 세 가지 결함을 같은 규칙으로 사후에 되돌린다. 파이프라인 쪽은 이미
고쳤지만, 그 전에 만든 책은 번역이 이미 들어 있어 다시 돌리면 번역값을 통째로
다시 사야 한다. 여기서는 블록만 손보고 번역은 살린다.

  1. 중복 삽입 지우기 — `missing` 삽입의 중복 검사가 구두점 때문에 빗나가,
     이미 뽑혀 있던 단락이 조각으로 한 번 더 들어왔다. 246쪽 책에서 삽입 122개
     중 93개가 옆 블록의 복제본이었다.
  2. 잘못된 제외 되돌리기 — 비전 모델이 절 제목과 본문 단락을 러닝 헤드로 오인해
     버렸다. 같은 책에서 341개를 버렸고 그중 123개가 200자 넘는 본문이었다.
     제외된 블록은 번역 큐에 들어가지 않으므로 한국어 칸이 영영 비어 있다.
  3. 쪽 안에서 갈린 단락 잇기 — 유형 수정·삽입이 extract 의 봉합 뒤에 일어나
     같은 쪽 안의 이음매는 다시 보지 않았다.

3번은 두 블록을 합치므로 번역을 버린다(합친 블록은 다시 번역해야 한다). 그래서
양쪽 다 번역이 있는 이음매는 `--stitch-translated` 없이는 건드리지 않는다.
"""
from __future__ import annotations

import argparse
import shutil
import sqlite3
import sys
import time
from collections import Counter
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

import _parallax as PX
from extract import (BODY, TERMINAL_RE, continues_sentence, is_bare_label,
                     is_figure_label, is_page_progress, join_src, looks_garbled,
                     merged_type, starts_note)
from pagecheck import (WORD_RE, droppable, function_word_count, norm_words,
                       reads_as_prose)



def coverage(text: str, layer: str) -> tuple[float, int]:
    """layer 가 text 의 낱말을 얼마나 담고 있는가. pagecheck 와 같은 계산이다."""
    pt = Counter(WORD_RE.findall(text.lower()))
    lt = Counter(WORD_RE.findall(layer.lower()))
    total = sum(pt.values())
    if not total:
        return 1.0, 0
    return sum(min(c, lt[w]) for w, c in pt.items()) / total, total


def load(con) -> list[dict]:
    return [dict(r) for r in con.execute(
        "SELECT id,ord,page,type,src,ko,ko_raw,state,flags FROM block ORDER BY ord")]


def repeat_counts(blocks: list[dict]) -> Counter:
    seen: set[tuple[str, int]] = set()
    out: Counter = Counter()
    for b in blocks:
        key = norm_words(b["src"] or "")[:80]
        if not key or (key, b["page"]) in seen:
            continue
        seen.add((key, b["page"]))
        out[key] += 1
    return out


DUPE_COVERAGE = 0.8
PARTIAL_COVERAGE = 0.35


def split_insertions(blocks: list[dict]) -> tuple[list[dict], list[dict]]:
    """판독 삽입 블록을 (통째로 중복 → 지움, 앞부분만 겹침 → 사람이 볼 것) 으로 가른다.

    앞머리만 보고 판단하면 안 된다. 모델은 이미 있는 문장으로 시작해 레이어가
    놓친 대목까지 이어 적어 오는 일이 잦아서, 겹친다고 지우면 뒤에 붙은 새 본문을
    함께 잃는다. 낱말이 거의 다 이미 있을 때만 지운다."""
    by_page: dict[int, list[dict]] = {}
    for b in blocks:
        by_page.setdefault(b["page"], []).append(b)

    dupes, partial = [], []
    for b in blocks:
        if not (b["flags"] & PX.FROM_OCR):
            continue
        layer = " ".join(x["src"] for x in by_page[b["page"]]
                         if x["id"] != b["id"] and not (x["flags"] & PX.FROM_OCR))
        if not layer:
            continue
        cov, total = coverage(b["src"], layer)
        if not total:
            continue
        if cov >= DUPE_COVERAGE:
            dupes.append(b)
        elif cov >= PARTIAL_COVERAGE:
            partial.append(b)
    return dupes, partial


def is_junk(src: str) -> bool:
    """결정적 규칙만으로 부속물이라고 말할 수 있는가."""
    return (is_page_progress(src) or is_figure_label(src)
            or is_bare_label(src) or looks_garbled(src))


def find_wrong_drops(blocks: list[dict], repeats: Counter) -> list[dict]:
    """머리글로 보기에는 너무 길고, 되풀이되지도 않는데 제외된 블록.

    `droppable` 은 머리글을 지키자고 만든 잣대라 도판 안 글자에는 맞지 않는다 —
    `SVERIGE 75`·`NIZINZINIZIN` 같은 축 이름을 「길고 안 되풀이되니 본문」이라며
    되살렸다. 쪽 이미지를 본 모델이 버린 것을 글자만 보고 뒤집으려면 **산문이라는
    적극적 증거**가 있어야 한다 — pagecheck 가 도판 사유의 drop 을 거부할 때 쓰는
    잣대와 같은 것이다."""
    return [b for b in blocks
            if (b["flags"] & PX.DROPPED)
            and not is_junk(b["src"])
            and (reads_as_prose(b["src"]) or function_word_count(b["src"]) >= 3)
            and not droppable(b["src"], repeats.get(norm_words(b["src"])[:80], 0),
                              b["type"])]


def find_seams(blocks: list[dict], stitch_translated: bool) -> list[tuple[dict, dict]]:
    """이어붙일 수 있는 이음매. 앞 블록이 문장 중간에서 끊겨 있어야 한다."""
    out = []
    prev = None
    for b in blocks:
        # 버린 블록은 이음매를 끊지 않는다. 파이프라인과 같은 실수가 여기에도 있었다 —
        # `Page 60 of 252 · 3%` 가 문장 한가운데 끼면 그것이 `prev` 가 되어 두 반쪽이
        # 영영 이웃이 되지 못했다. 244쪽 책 본문의 여섯 곳이 전부 이 모양이었다.
        if b["flags"] & PX.DROPPED:
            continue
        if prev is None:
            prev = b
            continue
        # 번역하지 않는 구간(주석·참고문헌)도 잇는다. 잃을 번역이 없고, 갈린 채
        # 두면 읽기와 낭독이 문장 중간에서 끊긴다 — 이 책은 손상 52곳 중 46곳이
        # 주석부였다. 다만 번역하는 쪽과 안 하는 쪽을 섞지는 않는다.
        untranslated_pair = bool(prev["flags"] & PX.NO_TRANSLATE) == bool(b["flags"] & PX.NO_TRANSLATE)
        # 색인은 이어붙일 단락이 아니라 목록이다. 항목이 소문자로 시작하고 종결부호도
        # 없어 이음매 규칙에 그대로 걸리는데, 실제로 이으면 색인 전체가 한 덩어리가
        # 된다(`absence epilepsy, 135 abstract ideas, 142 adrenaline, 95-6, 98 …`).
        # 항목이 쪽 번호로 끝난다는 것이 목록이라는 증거다 — 분철 하이픈은 예외.
        prev_tail = prev["src"].rstrip()
        index_like = ((prev_tail[-1:].isdigit() and not prev_tail.endswith("-"))
                      # 이어지는 조각에 기능어가 하나도 없으면 문장이 아니라 목록이다
                      or (not prev_tail.endswith("-") and function_word_count(b["src"]) == 0))
        joinable = (
            prev["type"] in BODY and b["type"] in BODY
            and untranslated_pair and not index_like
            and not starts_note(b["src"])
            and not TERMINAL_RE.search(prev["src"])
            and (b["page"] == prev["page"] + 1
                 or (b["page"] == prev["page"]
                     and (prev["src"].rstrip().endswith("-")
                          or continues_sentence(b["src"]))))
        )
        if joinable and not stitch_translated and (prev["ko"] or b["ko"]):
            joinable = False
        if joinable:
            out.append((prev, b))
            prev["src"] = join_src(prev["src"], b["src"])   # 연쇄 이음매도 이어진다
            if prev["type"] != b["type"]:
                prev["type"] = merged_type(prev["type"], b["type"])
            continue
        prev = b
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("parallax")
    ap.add_argument("--apply", action="store_true", help="실제로 고친다 (기본은 미리보기)")
    ap.add_argument("--stitch-translated", action="store_true",
                    help="양쪽에 번역이 있는 이음매도 잇는다 — 합친 블록은 다시 번역한다")
    ap.add_argument("--no-stitch", action="store_true", help="이음매는 건드리지 않는다")
    args = ap.parse_args()

    path = Path(args.parallax)
    if not path.exists():
        sys.exit(f"없는 파일: {path}")

    con = sqlite3.connect(path)
    con.row_factory = sqlite3.Row
    blocks = load(con)
    con.close()
    print(f"{path.name} — 블록 {len(blocks)}개\n")

    # 1. 중복 삽입
    dupes, partial = split_insertions(blocks)
    print(f"1. 중복 삽입 블록: {len(dupes)}개 지움")
    for b in dupes[:3]:
        print(f"     [{b['id']}] p{b['page']}  {b['src'][:76]}…")
    if partial:
        print(f"   앞부분만 겹치는 삽입 {len(partial)}개는 남긴다 — 뒤에 새 본문이 붙어 있다. "
              f"눈으로 볼 쪽: {', '.join(str(b['page']) for b in partial[:12])}"
              + (" …" if len(partial) > 12 else ""))

    gone = {b["id"] for b in dupes}
    live = [b for b in blocks if b["id"] not in gone]

    # 2. 잘못된 제외
    repeats = repeat_counts(live)
    wrong = find_wrong_drops(live, repeats)
    with_ko = sum(1 for b in wrong if b["ko"])
    print(f"\n2. 잘못 제외된 블록: {len(wrong)}개 되돌림 "
          f"(번역이 이미 있는 것 {with_ko} · 새로 번역해야 하는 것 {len(wrong) - with_ko})")
    for b in wrong[:3]:
        print(f"     [{b['id']}] p{b['page']} {b['type']}  {b['src'][:76]}…")

    for b in wrong:                      # 이음매 판정은 되돌린 상태를 봐야 한다
        b["flags"] &= ~(PX.DROPPED | PX.NO_TRANSLATE)

    # 3. 이음매
    seams = [] if args.no_stitch else find_seams(live, args.stitch_translated)
    retranslate = sum(1 for a, b in seams if a["ko"] or b["ko"])
    print(f"\n3. 이어붙일 단락: {len(seams)}쌍 (그중 번역을 버리고 다시 받을 것 {retranslate})")
    for a, b in seams[:3]:
        print(f"     p{a['page']} [{a['id']}] + [{b['id']}]")
        print(f"       → {a['src'][:110]}…")
    if not args.stitch_translated and not args.no_stitch:
        print("     양쪽에 번역이 있는 이음매는 두었다 — 함께 이으려면 --stitch-translated")

    if not args.apply:
        print("\n미리보기다. 실제로 고치려면 --apply")
        return

    bak = path.with_suffix(path.suffix + ".bak")
    shutil.copy2(path, bak)
    print(f"\n원본 사본: {bak.name}")

    now = int(time.time())
    con = sqlite3.connect(path)
    try:
        with con:
            for b in dupes:
                con.execute("DELETE FROM block WHERE id=?", (b["id"],))
            for b in wrong:
                # 번역이 이미 있으면 그대로 살린다. 없으면 큐로 되돌린다.
                state = b["state"] if b["ko"] else PX.UNTRANSLATED
                con.execute(
                    "UPDATE block SET flags=?, state=?, height_px=NULL, updated_at=? "
                    "WHERE id=?", (b["flags"], state, now, b["id"]))
            for a, b in seams:
                con.execute(
                    "UPDATE block SET src=?, type=?, ko=NULL, ko_raw=NULL, state=?, "
                    "flags=?, height_px=NULL, updated_at=? WHERE id=?",
                    (a["src"], "p" if a["type"] != b["type"] else a["type"],
                     PX.UNTRANSLATED, a["flags"] | PX.STITCHED, now, a["id"]))
                con.execute("DELETE FROM block WHERE id=?", (b["id"],))
            con.execute("UPDATE doc SET updated_at=?", (now,))
    finally:
        con.close()

    con = sqlite3.connect(path)
    n = con.execute("SELECT count(*) FROM block").fetchone()[0]
    todo = con.execute(
        "SELECT count(*) FROM block WHERE state=0 AND (flags & ?)=0 AND (flags & ?)=0",
        (PX.NO_TRANSLATE, PX.DROPPED)).fetchone()[0]
    con.close()
    print(f"\n블록 {len(blocks)} → {n} · 번역 대기 {todo}개")
    print(">> 앱에서 열면 대기 블록부터 번역이 이어진다.")


if __name__ == "__main__":
    main()
