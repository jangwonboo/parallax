#!/usr/bin/env python3
"""Translate blocks EN -> KO under a fixed register. Chunked, cached, resumable.

    python scripts/translate.py work/book.json --register essay
    python scripts/translate.py work/book.json --register fiction --limit 30   # style probe
"""
from __future__ import annotations

import argparse
import json
import re
from pathlib import Path

import _llm as L

REGISTERS = {
    "literal": {
        "label": "직역",
        "axes": [
            "종결어미: -다 평서형",
            "문장 분할: 원문 유지 — 영어 문장 하나에 한국어 문장 하나. 세미콜론·콜론 구조도 최대한 살려라.",
            "어휘: 원어 근접. 학술 용어는 관용역이 있어도 원어를 괄호 병기하라.",
            "대명사: 명시. he/she/it/they를 생략하지 마라.",
            "고유명사: 음차하고 첫 등장 시 원문을 괄호 병기하라 — 에이해브(Ahab)",
        ],
        "extra": ["원문의 어순과 구조를 최대한 보존하라. 읽는 맛보다 대응 관계가 우선이다."],
    },
    "fiction": {
        "label": "소설",
        "axes": [
            "종결어미: -다 평서형 (서술). 대사는 인물관계표를 따른다.",
            "문장 분할: 적극 — 관계절·분사구문이 겹친 영어 장문은 반드시 끊어라. "
            "한국어 문장이 60자를 넘으면 끊을 자리를 찾아라.",
            "어휘: 고유어 우선. 한자어보다 순우리말 동사·형용사를 골라라.",
            "대명사: 대폭 생략 — 문맥으로 주어가 복원되면 쓰지 마라. "
            "인물이 명확하면 he said는 '말했다'로 충분하다.",
            "고유명사: 음차, 원문 병기 없음. 지명은 관용역 우선.",
        ],
        "extra": [
            "대사는 인물의 말투를 유지하라. 교육 수준·나이·시대·관계가 말투에 드러나야 하고 챕터가 바뀌어도 같아야 한다.",
            "he said / she replied 같은 지시문은 한국어에서 반복이 거슬린다. 필요할 때만 남겨라.",
            "원문 문단의 첫 문장이 짧고 강하면 한국어도 짧고 강하게. 리듬은 의미의 일부다.",
        ],
    },
    "essay": {
        "label": "에세이",
        "axes": [
            "종결어미: -다 평서형",
            "문장 분할: 중간 — 장문은 끊되 논리 연결이 끊기면 유지하라.",
            "어휘: 균형. 개념어는 한자어, 서술은 고유어.",
            "대명사: 생략. 단 지시 대상이 모호해지면 명시하라.",
            "고유명사: 음차. 인명은 첫 등장 시 원문 괄호 병기.",
        ],
        "extra": [
            "저자의 1인칭은 필요할 때만 쓴다. I argue that은 주어 없이 '~라고 본다'가 자연스럽다.",
            "수사적 질문·도치·삽입구 같은 저자의 문체 장치는 살려라.",
        ],
    },
    "newneek": {
        "label": "뉴닉",
        "axes": [
            "종결어미: -요 해요체. 평서(-어요/-예요)와 물음(-까요?/-거든요)을 섞어 쓴다. "
            "-다 평서형과 -습니다 경어체는 쓰지 마라.",
            "문장 분할: 최대 — 한국어 문장이 40자를 넘으면 무조건 끊어라. "
            "쉼표로 이어 붙이지 말고 마침표로 끊고 접속사로 다시 시작하라.",
            "어휘: 일상어. 학술어·한자어는 아는 사람만 아는 말이라고 보고 쉬운 말로 바꾸되, "
            "그 분야의 이름값이 있는 용어는 쉬운 말 뒤에 괄호로 남겨라 — 오목한 부분(중심와).",
            "대명사: 생략. 대신 '우리'로 독자를 끌어들여라. 저자의 I는 '우리'나 무주어로 옮긴다.",
            "고유명사: 음차 + 첫 등장 시 원문 괄호 병기.",
        ],
        "extra": [
            "접속사를 문장 맨 앞에 둔다 — 근데, 그래서, 그러니까, 그러니, 일단. 문어체 접속사"
            "(따라서, 그러므로, 하지만)보다 입말을 골라라.",
            "어려운 대목은 바로 뒤에 한 마디로 풀어 준다. 단 **원문에 있는 내용으로만** 푼다. "
            "원문에 없는 사실·비유·예시를 지어내는 것은 문체가 아니라 오역이다.",
            "이모지·해시태그·느낌표 남발·'~읽어드릴게요' 같은 뉴스레터 상투구는 쓰지 마라. "
            "말투만 뉴닉이고, 내용은 원문 그대로다.",
            "원문의 수사적 질문은 물음표로 살려라. 없는 질문을 새로 만들지는 마라.",
            "원문의 냉소·유머는 살리되 원문에 없는 농담을 얹지 마라.",
        ],
    },
    # 개조식. business/직역 바탕에 명사형 종결을 얹었다. 보고서·요약본을 읽는
    # 눈에 맞춘 문체이고, 소설에는 쓸 수 없다(대사가 전부 무너진다).
    #
    # **종결 규칙은 반드시 축 하나에 모아 둘 것.** 실측에서 이 규칙을 계사문·청유형
    # 처리까지 별도 축으로 쪼개고 BASE 에 절대규칙까지 더했더니, 같은 36블록에서
    # `-다` 누출이 1건 → 54건으로 늘었다(시스템 프롬프트 29.4k→33.3k tok).
    # 규칙을 여러 자리에 흩으면 강조가 아니라 희석이 된다.
    "nominal": {
        "label": "개조식(명사형 종결)",
        "axes": [
            "종결어미: **명사형 종결(개조식)**. 문장을 '-다/-이다/-습니다/-요/-하자/-보자'로 끝내지 마라. "
            "① 문장 끝은 한자어 동사성 명사가 기본형이다 — 정의, 실행, 연구, 관찰, 제시, 도출, 검증, 구성, 시도, 필요. "
            "② 끝의 '함·됨·임'은 없어도 뜻이 통하면 뗀다 — 발명함→발명, 도출됨→도출, 구성됨→구성, "
            "제시함→제시, 시도일 것임→시도일 것. "
            "③ 끝맺는 명사 앞의 조사도 뗀다 — '설명을 제시'→'설명 제시', '폐기가 필요함'→'폐기 필요', "
            "'제거하는 시도를 함'→'제거 시도', '두 부분으로 구성됨'→'두 부분으로 구성'. "
            "④ 마땅한 한자어가 없을 때만 고유어 동사의 명사형으로 끝낸다 — 함, 됨, 있음, 없음, 같음, 보임, 아님. "
            "⑤ 한자어 어간에 '했음/되었음/할 것임/고 있음'을 붙이는 것은 시제·상(相)을 실어야 할 때만 허용한다 — "
            "탐구해왔음, 제시되었음, 검증할 것임. 현재·무시제 진술은 ①②③ 대로 명사로 끊는다. "
            "예외는 원문의 물음표 문장뿐이며, 그때도 '-일까?/-인가?'로 끝낸다.",
            "문장 분할: 원문 순서 유지. 영어 문장을 임의로 쪼개지 마라. "
            "다만 **한 단락 안에서** 짧은 문장을 하나로 축약하거나 중복된 수식을 덜어내는 것은 허용한다. "
            "축약은 단락 경계를 넘지 못한다.",
            "어휘: 한자어 우선. 개념어는 학계 표준 역어를 쓰되, 원어가 이미 표준이면 억지로 번역하지 마라.",
            "대명사: 생략. he/she/it/they 는 지시 대상이 모호해질 때만 명시.",
            "고유명사: 인명·지명은 음차하고 첫 등장 시 원문 괄호 병기 — 니컬러스 험프리(Nicholas Humphrey). "
            "기업명·제품명·학술지명은 원문 그대로 두고 음차하지 마라.",
        ],
        "extra": [
            "계사문(A is B)을 체언 하나로 뚝 끊지 마라 — '동기는 공백.' 대신 '동기는 공백에 해당.' "
            "또는 '~로 규정됨.' 부정이면 '~이 아님.' ('해당한다/규정된다'로 쓰지 마라 — 끝은 명사다.)",
            "Suppose·Imagine·Let us consider 같은 청유·명령형 도입부는 '~해 보자'가 아니라 "
            "'~라고 가정할 경우', '~라고 상정할 경우'처럼 조건절로 바꾸고 문장은 명사로 끝낸다.",
            "문장 **중간**의 조사와 연결어미는 정상 문어체 그대로 둔다. 끝맺음만 개조식이다.",
            "원문의 어순과 논리 구조를 보존하라. 결론이 뒤에 와도 앞으로 끌어오지 마라.",
            "수치·단위·연도·통화·퍼센트는 절대 손대지 마라.",
            "불릿·번호 목록은 병렬 구조를 살리고 항목 끝을 명사형으로 통일하라.",
            "저자의 1인칭 I/we 는 무주어로 옮기는 것이 기본이다. 필요하면 '저자'.",
            "원문에 없는 설명·비유·예시를 지어내지 마라. 축약은 덜어내는 것이지 보태는 것이 아니다.",
            "출력 전 마지막 점검: 모든 문장의 끝 글자가 명사인가. '-다'로 끝난 문장이 하나라도 있으면 고쳐 쓴다.",
        ],
    },
    "business": {
        "label": "비즈니스",
        "axes": [
            "종결어미: -다 평서형",
            "문장 분할: 적극 — 한 문장 한 메시지.",
            "어휘: 한자어 우선. 업계 표준 용어를 쓰되, 원어가 이미 표준이면(프레임워크, 레버리지) 억지로 번역하지 마라.",
            "대명사: 생략",
            "고유명사: 기업명·제품명·지수명은 원문 그대로 두고 음차하지 마라.",
        ],
        "extra": [
            "불릿·번호 목록은 병렬 구조를 살리고 항목 끝을 통일하라(전부 명사형 또는 전부 서술형).",
            "수치·단위·연도는 절대 손대지 마라.",
            "원문이 결론을 뒤에 두더라도 문장 순서를 바꾸지 마라. 구조 재배열은 번역이 아니다.",
        ],
    },
}

BASE = """당신은 영한 문학·비문헌 번역자다. 아래 블록들을 한국어로 옮긴다.

[절대 규칙]
1. 출력은 입력과 같은 블록 수, 같은 ID, 같은 순서다. 블록을 합치거나 나누거나 빠뜨리지 마라.
2. 각 줄은 정확히 `[ID] 번역문` 형식이다. 다른 말은 한 글자도 쓰지 마라.
3. 한 블록의 번역은 반드시 한 줄이다. 블록 안에서 문장을 몇 개로 나누든 자유지만 줄바꿈은 넣지 마라.
4. 숫자·연도·단위·통화·퍼센트는 원문 그대로.
5. [^3] 각주 마커, **강조**, *이탤릭* 마크업은 위치를 지켜라.
6. 원문에 없는 설명·부연·역주를 만들지 마라. 모르면 음차하고 넘어가라.
7. 용어집의 역어를 어기지 마라.
"""


# ── 개조식 종결 후처리 ────────────────────────────────────────────────────────
#
# 문체 사양만으로는 새는 자리가 남는다. 실측(프롤로그 36블록·171문장)에서 `-다`
# 누출이 8.8% 였고, 전부 **긴 블록의 가운데**에 몰렸다 — 1,200자 12문장짜리 단락은
# 앞뒤가 명사형인데 중간 여섯 문장이 서술형으로 풀린다. 청크를 줄이는 것보다
# 새는 블록만 골라 다시 보내는 쪽이 싸다(전체의 10% 안팎만 나간다).
#
# 이 단계는 재번역이 아니다. 종결부만 갈아 끼운다.
NOMINAL_REGISTERS = {"nominal"}

_SENT_SPLIT = re.compile(r"(?<=[.?!…])\s+")
# 종결 후보. `필요`·`중요`·`개요` 가 걸리지 않도록 `요` 단독은 보지 않고
# 어미 형태(-어요/-예요/-세요/-지요/-네요/-군요/-까요)만 본다.
_LEAK = re.compile(r"(다|하자|보자|어요|에요|예요|세요|지요|네요|군요|까요)$")
# 인용부호 안은 인물이 실제로 한 말이라 개조식으로 바꾸지 않는다(사양의 예외).
# 마스킹하지 않으면 대사의 `-습니다`가 누출로 잡히고, 교정자는 규칙대로 손대지
# 않으므로 그 블록이 영원히 "아직 누출"로 남는다. 문장 분할에도 도움이 된다 —
# 대사 안의 마침표가 블록을 엉뚱한 자리에서 자르지 않는다.
_QUOTED = re.compile(r"[\"“'‘][^\"“”'‘’]{0,600}[\"”'’]")


_BOLD_RE = re.compile(r"(?<!\*)\*\*(?!\s)(.+?)(?<!\s)\*\*(?!\*)", re.S)
_UNDER_RE = re.compile(r"(?<!_)__(?!\s)(.+?)(?<!\s)__(?!_)", re.S)


def strip_invented_bold(ko: str, src: str) -> str:
    """번역이 지어낸 마크다운 굵게 표시를 걷어낸다.

    모델은 원문에 없는 강조를 곧잘 얹는다(실측: 정본 여덟 권에서 110블록,
    **원문에 `**` 가 든 것은 한 블록도 없었다**). 리더는 마크다운을 해석하지
    않으므로 별표가 글자 그대로 화면에 박힌다.

    원문에 그 표시가 있으면 손대지 않는다 — 그때는 지어낸 것이 아니라 옮긴
    것이고, 수식 안의 별표를 건드릴 위험도 그 경우에만 있다."""
    if "**" not in src:
        ko = _BOLD_RE.sub(r"\1", ko)
    if "__" not in src:
        ko = _UNDER_RE.sub(r"\1", ko)
    return ko


def leaky_sentences(ko: str) -> list[str]:
    """명사형으로 끝나지 않은 문장들. 물음표 문장과 인용문은 사양상 예외다."""
    out = []
    for s in _SENT_SPLIT.split(_QUOTED.sub(" ", ko or "")):
        s = s.strip()
        if not s or s.endswith("?"):
            continue
        if _LEAK.search(s.rstrip(".!…)】]")):
            out.append(s)
    return out


FIX_SYS = """당신은 한국어 문장의 **종결부만** 개조식(명사형)으로 갈아 끼우는 교정자다.
번역자가 아니다. 다시 번역하지 마라.

[입력·출력]
각 줄은 `[ID] 한국어` 형식이다. 같은 ID·같은 수·같은 순서로 `[ID] 고친 한국어`만 출력한다.
한 블록은 반드시 한 줄이다. 다른 말은 한 글자도 쓰지 마라.

[하는 일 — 이것만]
'-다/-이다/-습니다/-어요/-보자/-하자'로 끝난 문장을 명사로 끝나게 바꾼다.
- 한자어 동사성 명사로 끝내는 것이 기본형이다 — 정의, 실행, 연구, 관찰, 제시, 도출,
  검증, 구성, 시도, 필요, 전환, 유지, 선택.
  '역사의 문제로 전환된다' → '역사의 문제로 전환'
  '경쟁적 해석을 제시하고 논쟁할 것이다' → '경쟁적 해석을 제시하고 논쟁할 것'
- 끝의 '함·됨·임'은 없어도 뜻이 통하면 뗀다. '도출됨' → '도출', '구성됨' → '구성'.
- 끝맺는 명사 앞의 조사도 뗀다. '설명을 제시' → '설명 제시', '폐기가 필요함' → '폐기 필요'.
- 마땅한 한자어가 없을 때만 고유어 명사형으로 끝낸다 — 있음, 없음, 같음, 보임, 아님, 함, 됨.
  '가능성이 높다' → '가능성이 높음', '이유는 없다' → '이유는 없음'
- 시제·상을 살려야 하면 '했음/되었음/할 것임/고 있음'을 쓴다. '탐구해왔다' → '탐구해왔음'.
- 계사문을 체언 하나로 뚝 끊지 마라. '동기는 공백.' 이 아니라 '동기는 공백에 해당.'

[절대 하지 않는 일]
1. 낱말을 바꾸지 마라. 어휘·어순·수식 관계는 그대로 둔다. 종결부만 손댄다.
2. 문장을 합치거나 나누지 마라. 문장 수를 바꾸지 마라.
3. 숫자·연도·단위·고유명사·인용 내용·각주 마커([^3])·강조 마크업은 100% 보존한다.
4. 원문의 물음표 문장은 물음표 그대로 둔다.
5. 인용부호 안의 대사는 건드리지 마라 — 인물이 실제로 한 말이다.
6. 이미 명사로 끝난 문장은 한 글자도 고치지 말고 그대로 출력한다."""


def fix_nominal_endings(book_path: str, book: dict, work: Path, blocks: list[dict],
                        chunk_chars: int, force: bool) -> tuple[int, int]:
    """종결부가 샌 블록만 다시 보낸다. (고친 블록 수, 남은 누출 블록 수)"""
    by_id = {b["id"]: b for b in book["blocks"]}
    leaky = [b for b in blocks if leaky_sentences(by_id[b["id"]].get("ko") or "")]
    if not leaky:
        print("종결 점검: 누출 없음")
        return 0, 0

    n_sent = sum(len(leaky_sentences(by_id[b["id"]]["ko"])) for b in leaky)
    print(f"\n종결 점검: {len(leaky)}/{len(blocks)} 블록 · {n_sent}문장 누출 — 재요청")

    cache = L.Cache(work, "fixend")
    chunks = L.chunk_blocks(leaky, chunk_chars)
    fixed = 0

    for i, chunk in enumerate(chunks):
        wire = "\n".join(f"[{b['id']}] {by_id[b['id']]['ko']}" for b in chunk)
        key = cache.key(wire, L.MODEL, "v1")
        hit = None if force else cache.get(key)
        if hit is None:
            got = L.call_preserving_ids(FIX_SYS, wire, [b["id"] for b in chunk],
                                        max_tokens=min(16000, len(wire) * 2 + 2000))
            cache.put(key, got)
        else:
            got = hit

        for b in chunk:
            new = (got.get(b["id"]) or "").strip()
            if new and new != by_id[b["id"]]["ko"]:
                by_id[b["id"]]["ko"] = new
                fixed += 1
        L.progress(i, len(chunks), "cached" if hit else "fixed")
        L.save_book(book_path, book)

    still = [b["id"] for b in leaky if leaky_sentences(by_id[b["id"]]["ko"])]
    print(f"종결 교정 {fixed}블록" + (f" · 아직 {len(still)}블록에 누출: {still[:8]}" if still else " · 누출 0"))
    return fixed, len(still)


def build_system(register: str, glossary: dict, polite: bool) -> str:
    r = REGISTERS[register]
    axes = list(r["axes"])
    if polite and register == "business":
        axes[0] = "종결어미: -습니다 경어체"

    parts = [BASE, f"\n[문체 사양 — {r['label']}]", *(f"- {a}" for a in axes)]
    if r["extra"]:
        parts += ["\n[추가 지시]", *(f"- {e}" for e in r["extra"])]

    terms = glossary.get("terms") or {}
    if terms:
        parts.append("\n[용어집 — 반드시 이 역어를 쓴다]")
        parts.append(" · ".join(f"{k} → {v}" for k, v in list(terms.items())[:250]))
    keep = glossary.get("keep_original") or []
    if keep:
        parts.append("\n[원문 유지 — 번역하지 않는다]")
        parts.append(" · ".join(keep))

    chars = glossary.get("characters") or []
    if chars and register == "fiction":
        parts.append("\n[인물관계표 — 대사의 존대·말투는 여기가 정답이다]")
        for c in chars:
            addr = ", ".join(f"{k}에게 {v}" for k, v in (c.get("addresses") or {}).items())
            parts.append(f"- {c.get('en')} = {c.get('ko')} ({c.get('role','')}) "
                         f"| 말투: {c.get('speech','')}" + (f" | {addr}" if addr else ""))

    parts.append("\n[블록 타입]\nh1/h2/h3 = 제목 · p = 단락 · quote = 인용 · "
                 "figcaption = 그림 설명 · footnote = 각주. 제목은 짧고 명사형으로.")
    return "\n".join(parts)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("book")
    ap.add_argument("--register", required=True, choices=list(REGISTERS))
    ap.add_argument("--polite", action="store_true", help="business register: -습니다")
    ap.add_argument("--chunk-chars", type=int, default=6000)
    ap.add_argument("--limit", type=int, help="translate only the first N blocks (style probe)")
    ap.add_argument("--range", help="block id range, e.g. b0120-b0240")
    ap.add_argument("--force", action="store_true", help="ignore cache and existing translations")
    ap.add_argument("--no-fix-endings", action="store_true",
                    help="nominal register: skip the sentence-ending repair pass")
    ap.add_argument("--fix-endings-only", action="store_true",
                    help="run only the ending repair pass over blocks that already have ko")
    args = ap.parse_args()

    book = L.load_book(args.book)
    work = L.work_dir(args.book)

    if args.fix_endings_only:
        scope = [b for b in L.translatable(book) if (b.get("ko") or "").strip()]
        if args.range:
            lo, hi = args.range.split("-")
            scope = [b for b in scope if lo <= b["id"] <= hi]
        fix_nominal_endings(args.book, book, work, scope, args.chunk_chars, args.force)
        L.save_book(args.book, book)
        return

    gpath = work / "glossary.json"
    if not gpath.exists():
        print("! no glossary.json — run glossary.py first for consistent names/terms")
        glossary = {}
    else:
        glossary = json.loads(gpath.read_text(encoding="utf-8"))
        if args.register == "fiction" and not glossary.get("characters"):
            raise SystemExit("fiction register needs a character sheet: "
                             "python scripts/glossary.py work/book.json --fiction")

    blocks = L.translatable(book)
    # 아직 비어 있는 블록만 청크로 묶는다.
    #
    # 예전에는 번역 대상 전체를 묶고, 청크 안이 전부 채워져 있을 때만 건너뛰었다.
    # 그래서 청크 하나에 빈 블록이 하나만 섞여 있어도 그 청크가 통째로 다시
    # 나갔고, 이미 deslop 까지 마친 번역이 새 번역으로 덮여 ko_raw 만 남은
    # 반쪽짜리 상태가 됐다. 246쪽 책에서 빈 곳 208개를 채우려고 청크 138개 중
    # 64개(원문 25만 자)를 다시 보내던 것이, 빈 것만 묶으면 15개(7.6만 자)로 준다.
    if not args.force:
        blocks = [b for b in blocks if not (b.get("ko") or "").strip()]
    if args.range:
        lo, hi = args.range.split("-")
        blocks = [b for b in blocks if lo <= b["id"] <= hi]
    if args.limit:
        blocks = blocks[:args.limit]

    system = build_system(args.register, glossary, args.polite)
    (work / "translate-system.txt").write_text(system, encoding="utf-8")

    cache = L.Cache(work, "translate")
    chunks = L.chunk_blocks(blocks, args.chunk_chars)
    print(f"{len(blocks)} blocks · {len(chunks)} chunks · register={args.register}")

    by_id = {b["id"]: b for b in book["blocks"]}
    order = {b["id"]: i for i, b in enumerate(book["blocks"])}
    done = 0

    def context_for(chunk) -> str:
        """청크 바로 앞의, 이미 번역된 블록 두 개. 문맥은 책 순서를 따라야 한다 —
        빈 곳만 모아 청크를 만들면 앞 청크의 마지막 블록이 책에서 이웃이 아니다."""
        out = []
        for b in reversed(book["blocks"][:order[chunk[0]["id"]]]):
            if b.get("translate", True) and (b.get("ko") or "").strip():
                out.append(f"{b['src']}\n→ {b['ko']}")
                if len(out) == 2:
                    break
        return "\n".join(reversed(out))

    for i, chunk in enumerate(chunks):
        wire = L.to_wire(chunk, "src")
        key = cache.key(wire, args.register, args.polite, L.MODEL, "v1")
        hit = None if args.force else cache.get(key)

        if hit is None and not args.force and all(by_id[b["id"]].get("ko") for b in chunk):
            L.progress(i, len(chunks), "already translated")
            continue

        if hit is None:
            user = wire
            prev_tail = context_for(chunk)
            if prev_tail:
                user = ("[직전 문맥 — 참고만 하고 번역하지 마라]\n" + prev_tail +
                        "\n\n[번역 대상]\n" + wire)
            got = L.call_preserving_ids(system, user, [b["id"] for b in chunk],
                                        max_tokens=min(16000, len(wire) * 2 + 2000))
            cache.put(key, got)
        else:
            got = hit

        for b in chunk:
            if got.get(b["id"]):
                ko = got[b["id"]]
                # 시스템 프롬프트의 블록 타입 설명을 보고 모델이 이따금 타입
                # 토큰을 번역 앞에 흘린다. 자기 블록의 타입과 일치할 때만 벗긴다.
                tok = str(b.get("type", "")) + " "
                if len(tok) > 1 and ko.startswith(tok):
                    ko = ko[len(tok):].strip()
                by_id[b["id"]]["ko"] = strip_invented_bold(ko, b.get("src", ""))
                # 새 번역이 들어오면 이전 deslop 기록은 무효다. 남겨 두면 ko 는
                # 새 register 인데 ko_raw 는 옛 register 인 짝이 어긋난 상태가 되고,
                # deslop 은 "이미 손봤다"고 보고 이 블록을 건너뛴다.
                by_id[b["id"]].pop("ko_raw", None)
                done += 1

        L.progress(i, len(chunks), "cached" if hit else "translated")
        L.save_book(args.book, book)  # save every chunk so a crash loses nothing

    book["meta"]["register"] = args.register
    L.save_book(args.book, book)

    missing = [b["id"] for b in blocks if not by_id[b["id"]].get("ko")]
    print(f"\ntranslated {done} blocks")
    if missing:
        print(f"! {len(missing)} still empty: {missing[:12]}{' …' if len(missing) > 12 else ''}")

    if args.register in NOMINAL_REGISTERS and not args.no_fix_endings:
        filled = [b for b in blocks if (by_id[b["id"]].get("ko") or "").strip()]
        fix_nominal_endings(args.book, book, work, filled, args.chunk_chars, args.force)
        L.save_book(args.book, book)
        print(">> nominal register: deslop 은 건너뛴다. 바로 verify.py 로 갈 것.")
    else:
        print(">> Read a few paragraphs before running deslop. "
              "Wrong register is cheapest to fix now.")


if __name__ == "__main__":
    main()
